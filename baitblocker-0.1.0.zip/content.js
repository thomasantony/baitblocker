"use strict";
(() => {
  // src/parser.ts
  var IMAGE_SIZE = "360x360";
  var MAX_IMAGES = 2;
  function scoringImageUrl(url) {
    const m = /^https:\/\/pbs\.twimg\.com\/media\/([A-Za-z0-9_-]+)/.exec(url);
    return m ? `https://pbs.twimg.com/media/${m[1]}?format=jpg&name=${IMAGE_SIZE}` : void 0;
  }

  // config/questions.json
  var questions_default = {
    version: 7,
    questions: [
      {
        id: "us_politics",
        text: "Is this post (including any text in attached images) about United States politics, economics, or culture war, written as if the author lives in the US? Examples: Democrats or Republicans, US politicians, the minimum wage or prices in dollars, rent or wages in US cities, US healthcare or insurance, taxes, student loans, guns, immigration, or 'in this country' complaints about America. Answer no for posts that are not about the US, and for neutral news reports."
      },
      {
        id: "ideology_bait",
        text: 'Is this post (including any text in attached images) a sweeping, low-effort take designed to farm replies on a divisive theme, such as capitalism vs socialism, billionaires or the rich, the working class, or rejecting modern technology ("nobody wants self-driving cars", AI, smartphones, cashless payments), stated as a slogan or bold claim rather than a specific argument? Answer no for specific, substantive arguments, news, or personal anecdotes without a provocative generalization.'
      }
    ],
    combine: {
      max_of: [
        "us_politics",
        "ideology_bait"
      ],
      weighted: {}
    },
    thresholds: {
      hide: 0.8,
      blur: 0.5
    },
    stance: {
      id: "endorses_quote",
      text: "A reply-quote: the author wrote the first part, quoting the post after [Quoted post]. Does the author side with the quoted post, wanting readers to agree with it? Answer no if the author is mocking it, arguing against it, correcting it, warning people about it, or commenting on something else.",
      threshold: 0.8
    }
  };

  // src/settings.ts
  var QUESTIONS = questions_default;
  var DEFAULT_SETTINGS = {
    apiKey: "",
    model: "d1.1",
    thresholds: { ...QUESTIONS.thresholds },
    enabled: { pending: true, hide: true, blur: true, flag: true },
    dailyTokenBudget: 1e6,
    captureFixtures: false,
    allowedCountries: ["United States", "North America"],
    scoreImages: true
  };
  async function loadSettings() {
    const { settings: settings2 } = await chrome.storage.local.get("settings");
    const s = settings2 ?? {};
    const saved = s.thresholdsFor === QUESTIONS.version ? s.thresholds : void 0;
    return {
      ...DEFAULT_SETTINGS,
      ...s,
      thresholds: { ...DEFAULT_SETTINGS.thresholds, ...saved },
      enabled: { ...DEFAULT_SETTINGS.enabled, ...s.enabled }
    };
  }

  // src/types.ts
  var MSG_NS = "baitblocker:v1";

  // src/content.ts
  var posts = /* @__PURE__ */ new Map();
  var verdicts = /* @__PURE__ */ new Map();
  var requested = /* @__PURE__ */ new Set();
  var revealed = /* @__PURE__ */ new Set();
  var fallbackTimers = /* @__PURE__ */ new Map();
  var settings;
  var FALLBACK_DELAY_MS = 400;
  var NAMED = {
    us_politics: "US-politics bait",
    ideology_bait: "ideology bait",
    endorses_quote: "endorses quoted bait"
  };
  var countryWaiters = /* @__PURE__ */ new Map();
  function requestVerdict(post) {
    if (requested.has(post.id)) return;
    requested.add(post.id);
    chrome.runtime.sendMessage({ type: "score", post }).then((v) => {
      if (v?.needsCountry) return awaitCountry(post.id, v.needsCountry);
      verdicts.set(post.id, v ?? { postId: post.id, decision: "unscored", reason: "error" });
      reaskQuoters(post.id);
      schedule();
    }).catch(() => {
      verdicts.set(post.id, { postId: post.id, decision: "unscored", reason: "error" });
      schedule();
    });
  }
  function reaskQuoters(quotedId) {
    for (const p of posts.values()) {
      if (p.quotedId !== quotedId || !verdicts.has(p.id)) continue;
      requested.delete(p.id);
      requestVerdict(p);
    }
  }
  function awaitCountry(postId, handle) {
    let waiting = countryWaiters.get(handle);
    if (!waiting) {
      countryWaiters.set(handle, waiting = /* @__PURE__ */ new Set());
      window.postMessage({ ns: MSG_NS, type: "lookupCountry", handle }, location.origin);
    }
    waiting.add(postId);
  }
  async function onCountryResult(handle, result) {
    const waiting = countryWaiters.get(handle) ?? /* @__PURE__ */ new Set();
    countryWaiters.delete(handle);
    if (result.ok) {
      await chrome.runtime.sendMessage({ type: "country", handle, info: result.info }).catch(() => {
      });
      for (const id of waiting) {
        requested.delete(id);
        const p = posts.get(id);
        if (p) requestVerdict(p);
      }
    } else {
      console.debug("[baitblocker] country lookup failed", handle, result.error);
      if (result.error === "stale_query") console.info(`[baitblocker] Open any profile's "About this account" page once so the extension can learn X's new query id.`);
      for (const id of waiting) verdicts.set(id, { postId: id, decision: "unscored", reason: "error" });
    }
    schedule();
  }
  function sendLabel(postId, label, source) {
    chrome.runtime.sendMessage({ type: "label", label: { postId, label, source } }).catch(() => {
    });
  }
  window.addEventListener("message", (e) => {
    if (e.source !== window || e.data?.ns !== MSG_NS) return;
    if (e.data.type === "posts") {
      for (const p of e.data.posts) {
        if (!posts.has(p.id)) posts.set(p.id, p);
        requestVerdict(p);
      }
      schedule();
    } else if (e.data.type === "countryResult" && typeof e.data.handle === "string") {
      onCountryResult(e.data.handle, e.data.result);
    } else if (e.data.type === "capture") {
      chrome.runtime.sendMessage({ type: "capture", url: e.data.url, body: e.data.body }).catch(() => {
      });
    }
  });
  async function refreshSettings() {
    settings = await loadSettings();
    window.postMessage({ ns: MSG_NS, type: "config", capture: settings.captureFixtures }, location.origin);
  }
  chrome.storage.onChanged.addListener((changes) => {
    if (!changes.settings) return;
    refreshSettings().then(() => {
      verdicts.clear();
      requested.clear();
      countryWaiters.clear();
      for (const p of posts.values()) requestVerdict(p);
      schedule();
    });
  });
  function postIdOf(article) {
    const link = article.querySelector('a[href*="/status/"] time')?.closest("a") ?? article.querySelector('a[href*="/status/"]');
    return /\/status\/(\d+)/.exec(link?.getAttribute("href") ?? "")?.[1];
  }
  function scrapePost(article, id) {
    const texts = article.querySelectorAll('[data-testid="tweetText"]');
    const handles = [...article.querySelectorAll('[data-testid="User-Name"] a[href^="/"]')].map((a) => /^\/([A-Za-z0-9_]+)$/.exec(a.getAttribute("href") ?? "")?.[1]).filter((h) => !!h);
    const text = texts[0]?.innerText ?? "";
    const images = [...article.querySelectorAll('[data-testid="tweetPhoto"] img')].map((i) => scoringImageUrl(i.src)).filter((u) => !!u);
    if (!text && !handles.length && !images.length) return void 0;
    return {
      id,
      text,
      author: handles[0],
      quotedText: texts[1]?.innerText,
      quotedAuthor: handles[1],
      imageUrls: images.length ? [...new Set(images)].slice(0, MAX_IMAGES) : void 0,
      isReply: false,
      source: "dom"
    };
  }
  function ensurePost(article, id) {
    if (posts.has(id) || requested.has(id) || fallbackTimers.has(id)) return;
    fallbackTimers.set(
      id,
      setTimeout(() => {
        fallbackTimers.delete(id);
        if (posts.has(id) || requested.has(id) || !article.isConnected || postIdOf(article) !== id) return;
        const p = scrapePost(article, id);
        if (!p) return;
        posts.set(id, p);
        requestVerdict(p);
      }, FALLBACK_DELAY_MS)
    );
  }
  var rendered = /* @__PURE__ */ new WeakMap();
  function stateFor(id) {
    const v = verdicts.get(id);
    const en = settings?.enabled;
    if (!v) return { state: en?.pending === false ? "show" : "pending" };
    if (revealed.has(id) || v.decision === "unscored") return { state: "show", v };
    let d = v.decision;
    if (d === "hide" && en?.hide === false) d = "blur";
    if (d === "blur" && en?.blur === false) d = "show";
    return { state: d, v };
  }
  function clear(article) {
    article.classList.remove("bb-pending", "bb-hide", "bb-blur", "bb-show");
    article.querySelectorAll(":scope > .bb-ui, .bb-qbar").forEach((n) => n.remove());
    article.querySelectorAll(".bb-qblur, .bb-qpending").forEach((n) => n.classList.remove("bb-qblur", "bb-qpending"));
  }
  function quoteBox(article) {
    const box = article.querySelectorAll('[data-testid="User-Name"]')[1]?.closest('div[role="link"]');
    return box && article.contains(box) ? box : void 0;
  }
  function el(tag, cls, text) {
    const n = document.createElement(tag);
    n.className = cls;
    if (text) n.textContent = text;
    return n;
  }
  function button(text, onClick) {
    const b = el("button", "bb-btn", text);
    b.type = "button";
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      onClick();
    });
    return b;
  }
  function swallow(n) {
    n.addEventListener("click", (e) => {
      e.stopPropagation();
    });
    return n;
  }
  function reasonName(v) {
    if (v.topQuestion === "seeded_author") return "seeded account";
    if (v.topQuestion && NAMED[v.topQuestion]) return NAMED[v.topQuestion];
    return "ragebait";
  }
  function metaText(v) {
    const parts = [`${reasonName(v)} ${(v.score ?? 0).toFixed(2)}`];
    if (v.author) parts.push(`@${v.author}`);
    if (v.country) parts.push(`based in ${v.country}`);
    return parts.join(" \xB7 ");
  }
  function reveal(id) {
    revealed.add(id);
    schedule();
  }
  function blurBar(id, v, title) {
    const bar = swallow(el("div", "bb-ui bb-bar bb-blurbar"));
    bar.append(el("span", "bb-meta", `${title} \xB7 ${metaText(v)}`));
    for (const label of ["ragebait", "fine"]) {
      bar.append(
        button(label === "ragebait" ? "bait" : label, () => {
          sendLabel(id, label, "user_button");
          reveal(id);
        })
      );
    }
    const show = button("show", () => reveal(id));
    show.classList.add("bb-link");
    bar.append(show);
    return bar;
  }
  function quoteStateFor(qid) {
    const { state, v } = stateFor(qid);
    if (state === "hide" || state === "blur") return { state: "qblur", v };
    return { state: state === "pending" ? "qpending" : "none", v };
  }
  function renderQuote(article, qid, state, v) {
    const box = quoteBox(article);
    if (!box || state === "none") return;
    if (state === "qpending") return box.classList.add("bb-qpending");
    box.classList.add("bb-qblur");
    const bar = blurBar(qid, v, "Quoted post blurred");
    bar.classList.add("bb-qbar");
    box.before(bar);
  }
  function render(article, id, state, v) {
    clear(article);
    article.classList.add(`bb-${state}`);
    if (state === "hide" && v) {
      const bar = swallow(el("div", "bb-ui bb-bar"));
      bar.append(el("span", "bb-meta", `Hidden \xB7 ${metaText(v)}`));
      bar.append(
        button("show", () => {
          sendLabel(id, "fine", "show_click");
          reveal(id);
        })
      );
      article.prepend(bar);
    } else if (state === "blur" && v) {
      article.prepend(blurBar(id, v, "Blurred"));
    } else if (state === "show" && settings?.enabled.flag !== false) {
      const flag = swallow(el("div", "bb-ui bb-flag"));
      const toggle = button("\u2691", () => flag.classList.toggle("bb-open"));
      toggle.title = "Label this post";
      const menu = el("div", "bb-menu");
      for (const label of ["ragebait"]) {
        menu.append(
          button("bait", () => {
            sendLabel(id, label, "user_button");
            flag.classList.remove("bb-open");
            flag.classList.add("bb-done");
            toggle.textContent = "\u2713";
          })
        );
      }
      flag.append(toggle, menu);
      article.prepend(flag);
    }
  }
  function pass() {
    for (const article of document.querySelectorAll('article[data-testid="tweet"]')) {
      const id = postIdOf(article);
      if (!id) {
        if (rendered.has(article)) {
          clear(article);
          rendered.delete(article);
        }
        continue;
      }
      if (!verdicts.has(id)) ensurePost(article, id);
      const { state, v } = stateFor(id);
      const qid = state === "show" ? posts.get(id)?.quotedId : void 0;
      const q = qid ? quoteStateFor(qid) : void 0;
      const key = `${id}:${state}:${q?.state ?? ""}`;
      const needsUi = state === "hide" || state === "blur" || state === "show" && settings?.enabled.flag !== false;
      const quoteOk = q?.state !== "qblur" || !!article.querySelector(".bb-qbar") || !quoteBox(article);
      if (rendered.get(article) === key && (!needsUi || article.querySelector(":scope > .bb-ui")) && quoteOk) continue;
      render(article, id, state, v);
      if (qid && q) renderQuote(article, qid, q.state, q.v);
      rendered.set(article, key);
    }
  }
  var scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      scheduled = false;
      pass();
    });
  }
  var CSS = `
article.bb-pending { opacity: .5; }
article.bb-hide, article.bb-blur, article.bb-show { position: relative; }
article.bb-hide > :not(.bb-ui) { display: none !important; }
article.bb-blur > :not(.bb-ui) { filter: blur(12px); pointer-events: none; user-select: none; transition: filter .15s; }
article.bb-blur:hover > :not(.bb-ui) { filter: none; transition-delay: .4s; }
.bb-ui { font: 13px/1.3 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; color: rgb(113,118,123); }
.bb-bar { display: flex; align-items: center; gap: 8px; padding: 8px 16px; }
.bb-bar .bb-meta { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.bb-btn { font: inherit; cursor: pointer; border: 1px solid rgb(83,100,113); background: rgba(0,0,0,.65); color: #e7e9ea; border-radius: 999px; padding: 3px 12px; }
.bb-btn:hover { background: rgba(29,155,240,.85); border-color: transparent; }
.bb-blurbar .bb-btn { padding: 1px 10px; }
.bb-bar:not(.bb-blurbar) .bb-btn, .bb-bar .bb-btn.bb-link { background: transparent; color: rgb(29,155,240); border-color: transparent; padding: 0 0 0 4px; }
.bb-flag { position: absolute; top: 10px; right: 52px; z-index: 2; display: flex; gap: 4px; opacity: 0; transition: opacity .1s; }
article:hover > .bb-flag, .bb-flag.bb-open, .bb-flag.bb-done { opacity: 1; }
.bb-flag > .bb-btn { padding: 0 6px; }
.bb-qpending { opacity: .5; }
.bb-qblur { filter: blur(10px); pointer-events: none; user-select: none; }
.bb-qbar { padding: 6px 0; }
.bb-menu { display: none; gap: 4px; }
.bb-flag.bb-open .bb-menu { display: flex; }
`;
  function boot() {
    const style = document.createElement("style");
    style.textContent = CSS;
    (document.head ?? document.documentElement).append(style);
    new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
    schedule();
  }
  refreshSettings();
  boot();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL3BhcnNlci50cyIsICIuLi9jb25maWcvcXVlc3Rpb25zLmpzb24iLCAiLi4vc3JjL3NldHRpbmdzLnRzIiwgIi4uL3NyYy90eXBlcy50cyIsICIuLi9zcmMvY29udGVudC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBQb3N0IH0gZnJvbSAnLi90eXBlcyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgVGltZWxpbmVQYXJzZXIge1xuICBwYXJzZShqc29uOiB1bmtub3duKTogUG9zdFtdO1xufVxuXG50eXBlIE9iaiA9IFJlY29yZDxzdHJpbmcsIGFueT47XG5cbmNvbnN0IGlzT2JqID0gKHY6IHVua25vd24pOiB2IGlzIE9iaiA9PiB0eXBlb2YgdiA9PT0gJ29iamVjdCcgJiYgdiAhPT0gbnVsbDtcblxuLyoqIFVud3JhcCBUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cyBhbmQgc2ltaWxhciB3cmFwcGVycyBkb3duIHRvIGEgVHdlZXQgb2JqZWN0LiAqL1xuZnVuY3Rpb24gdW53cmFwVHdlZXQodjogdW5rbm93bik6IE9iaiB8IHVuZGVmaW5lZCB7XG4gIGlmICghaXNPYmoodikpIHJldHVybiB1bmRlZmluZWQ7XG4gIGlmICh2Ll9fdHlwZW5hbWUgPT09ICdUd2VldCcpIHJldHVybiB2O1xuICBpZiAodi5fX3R5cGVuYW1lID09PSAnVHdlZXRXaXRoVmlzaWJpbGl0eVJlc3VsdHMnICYmIGlzT2JqKHYudHdlZXQpKSByZXR1cm4gdW53cmFwVHdlZXQodi50d2VldCk7XG4gIHJldHVybiB1bmRlZmluZWQ7XG59XG5cbmZ1bmN0aW9uIHNjcmVlbk5hbWUodHdlZXQ6IE9iaik6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IHVzZXIgPSB0d2VldC5jb3JlPy51c2VyX3Jlc3VsdHM/LnJlc3VsdDtcbiAgY29uc3QgbmFtZSA9IHVzZXI/LmNvcmU/LnNjcmVlbl9uYW1lID8/IHVzZXI/LmxlZ2FjeT8uc2NyZWVuX25hbWU7XG4gIHJldHVybiB0eXBlb2YgbmFtZSA9PT0gJ3N0cmluZycgPyBuYW1lIDogdW5kZWZpbmVkO1xufVxuXG5mdW5jdGlvbiB0d2VldFRleHQodHdlZXQ6IE9iaik6IHN0cmluZyB7XG4gIGNvbnN0IG5vdGUgPSB0d2VldC5ub3RlX3R3ZWV0Py5ub3RlX3R3ZWV0X3Jlc3VsdHM/LnJlc3VsdD8udGV4dDtcbiAgaWYgKHR5cGVvZiBub3RlID09PSAnc3RyaW5nJyAmJiBub3RlKSByZXR1cm4gbm90ZTtcbiAgY29uc3QgZnVsbCA9IHR3ZWV0LmxlZ2FjeT8uZnVsbF90ZXh0O1xuICByZXR1cm4gdHlwZW9mIGZ1bGwgPT09ICdzdHJpbmcnID8gZnVsbCA6ICcnO1xufVxuXG4vKiogWCBzZXJ2ZXMgYW55IHNpemUgb2YgYSBwaG90byBieSBxdWVyeSBzdHJpbmc7IDM2MHgzNjAgaXMgZW5vdWdoIGZvciBkMSB0byByZWFkIHRleHQgaW4gaW1hZ2VzLiAqL1xuZXhwb3J0IGNvbnN0IElNQUdFX1NJWkUgPSAnMzYweDM2MCc7XG5leHBvcnQgY29uc3QgTUFYX0lNQUdFUyA9IDI7XG5cbi8qKiBOb3JtYWxpemVzIGEgcGJzLnR3aW1nLmNvbS9tZWRpYSBVUkwgKGFueSBleHRlbnNpb24gb3IgcXVlcnkpIHRvIGEgc21hbGwgSlBFRy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzY29yaW5nSW1hZ2VVcmwodXJsOiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICBjb25zdCBtID0gL15odHRwczpcXC9cXC9wYnNcXC50d2ltZ1xcLmNvbVxcL21lZGlhXFwvKFtBLVphLXowLTlfLV0rKS8uZXhlYyh1cmwpO1xuICByZXR1cm4gbSA/IGBodHRwczovL3Bicy50d2ltZy5jb20vbWVkaWEvJHttWzFdfT9mb3JtYXQ9anBnJm5hbWU9JHtJTUFHRV9TSVpFfWAgOiB1bmRlZmluZWQ7XG59XG5cbmZ1bmN0aW9uIHBob3RvVXJscyh0d2VldDogT2JqKTogc3RyaW5nW10ge1xuICBjb25zdCBtZWRpYSA9IHR3ZWV0LmxlZ2FjeT8uZXh0ZW5kZWRfZW50aXRpZXM/Lm1lZGlhID8/IHR3ZWV0LmxlZ2FjeT8uZW50aXRpZXM/Lm1lZGlhO1xuICBpZiAoIUFycmF5LmlzQXJyYXkobWVkaWEpKSByZXR1cm4gW107XG4gIHJldHVybiBtZWRpYVxuICAgIC5maWx0ZXIoKG06IGFueSkgPT4gbT8udHlwZSA9PT0gJ3Bob3RvJyAmJiB0eXBlb2YgbS5tZWRpYV91cmxfaHR0cHMgPT09ICdzdHJpbmcnKVxuICAgIC5tYXAoKG06IGFueSkgPT4gc2NvcmluZ0ltYWdlVXJsKG0ubWVkaWFfdXJsX2h0dHBzKSlcbiAgICAuZmlsdGVyKCh1OiBzdHJpbmcgfCB1bmRlZmluZWQpOiB1IGlzIHN0cmluZyA9PiAhIXUpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZXh0cmFjdFBvc3QodHdlZXQ6IE9iaik6IFBvc3QgfCB1bmRlZmluZWQge1xuICBjb25zdCBpZCA9IHR3ZWV0LnJlc3RfaWQ7XG4gIGlmICh0eXBlb2YgaWQgIT09ICdzdHJpbmcnIHx8ICFpZCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgY29uc3QgcG9zdDogUG9zdCA9IHtcbiAgICBpZCxcbiAgICB0ZXh0OiB0d2VldFRleHQodHdlZXQpLFxuICAgIGF1dGhvcjogc2NyZWVuTmFtZSh0d2VldCksXG4gICAgaXNSZXBseTogdHlwZW9mIHR3ZWV0LmxlZ2FjeT8uaW5fcmVwbHlfdG9fc3RhdHVzX2lkX3N0ciA9PT0gJ3N0cmluZycsXG4gICAgc291cmNlOiAncGFyc2VyJyxcbiAgfTtcbiAgY29uc3QgaW1hZ2VzID0gcGhvdG9VcmxzKHR3ZWV0KTtcbiAgY29uc3QgcXVvdGVkID0gdW53cmFwVHdlZXQodHdlZXQucXVvdGVkX3N0YXR1c19yZXN1bHQ/LnJlc3VsdCk7XG4gIGlmIChxdW90ZWQpIHtcbiAgICBwb3N0LnF1b3RlZFRleHQgPSB0d2VldFRleHQocXVvdGVkKTtcbiAgICBwb3N0LnF1b3RlZEF1dGhvciA9IHNjcmVlbk5hbWUocXVvdGVkKTtcbiAgICAvLyBUaGUgd2FsayBpbiBwYXJzZSgpIGFsc28gZW1pdHMgdGhlIHF1b3RlZCB0d2VldCBhcyBpdHMgb3duIHBvc3QsIHNvIGl0IGlzIHNjb3JlZCBzZXBhcmF0ZWx5LlxuICAgIGlmICh0eXBlb2YgcXVvdGVkLnJlc3RfaWQgPT09ICdzdHJpbmcnICYmIHF1b3RlZC5yZXN0X2lkKSBwb3N0LnF1b3RlZElkID0gcXVvdGVkLnJlc3RfaWQ7XG4gICAgZWxzZSBpbWFnZXMucHVzaCguLi5waG90b1VybHMocXVvdGVkKSk7XG4gIH1cbiAgaWYgKGltYWdlcy5sZW5ndGgpIHBvc3QuaW1hZ2VVcmxzID0gWy4uLm5ldyBTZXQoaW1hZ2VzKV0uc2xpY2UoMCwgTUFYX0lNQUdFUyk7XG4gIHJldHVybiBwb3N0O1xufVxuXG4vKiogVGhlIHNhbWUgdHdlZXQgY2FuIGFwcGVhciBtb3JlIHRoYW4gb25jZSB3aXRoIGRpZmZlcmVudCBkZXRhaWw7IGtlZXAgZXZlcnkgbm9uLWVtcHR5IGZpZWxkLiAqL1xuZnVuY3Rpb24gbWVyZ2VQb3N0cyhhOiBQb3N0IHwgdW5kZWZpbmVkLCBiOiBQb3N0KTogUG9zdCB7XG4gIGlmICghYSkgcmV0dXJuIGI7XG4gIGNvbnN0IG91dDogUG9zdCA9IHsgLi4uYSB9O1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhiKSBhcyBba2V5b2YgUG9zdCwgYW55XVtdKSB7XG4gICAgaWYgKG91dFtrXSA9PT0gdW5kZWZpbmVkIHx8IG91dFtrXSA9PT0gJycgfHwgb3V0W2tdID09PSBmYWxzZSkgKG91dCBhcyBhbnkpW2tdID0gdjtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG4vKiogV2Fsa3MgYW55IFggR3JhcGhRTCByZXNwb25zZSBhbmQgY29sbGVjdHMgZXZlcnkgVHdlZXQgaXQgY29udGFpbnMuIE5ldmVyIHRocm93cy4gKi9cbmV4cG9ydCBjbGFzcyBHcmFwaFFMVGltZWxpbmVQYXJzZXIgaW1wbGVtZW50cyBUaW1lbGluZVBhcnNlciB7XG4gIHBhcnNlKGpzb246IHVua25vd24pOiBQb3N0W10ge1xuICAgIGNvbnN0IG91dCA9IG5ldyBNYXA8c3RyaW5nLCBQb3N0PigpO1xuICAgIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbanNvbl07XG4gICAgY29uc3Qgc2VlbiA9IG5ldyBTZXQ8dW5rbm93bj4oKTtcbiAgICB3aGlsZSAoc3RhY2subGVuZ3RoKSB7XG4gICAgICBjb25zdCBub2RlID0gc3RhY2sucG9wKCk7XG4gICAgICBpZiAoIWlzT2JqKG5vZGUpIHx8IHNlZW4uaGFzKG5vZGUpKSBjb250aW51ZTtcbiAgICAgIHNlZW4uYWRkKG5vZGUpO1xuICAgICAgY29uc3QgdHdlZXQgPSB1bndyYXBUd2VldChub2RlKTtcbiAgICAgIGlmICh0d2VldCAmJiB0d2VldCA9PT0gbm9kZSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHBvc3QgPSBleHRyYWN0UG9zdCh0d2VldCk7XG4gICAgICAgICAgaWYgKHBvc3QpIG91dC5zZXQocG9zdC5pZCwgbWVyZ2VQb3N0cyhvdXQuZ2V0KHBvc3QuaWQpLCBwb3N0KSk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIHRvbGVyYXRlIGFueSBtYWxmb3JtZWQgdHdlZXRcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZm9yIChjb25zdCB2IG9mIEFycmF5LmlzQXJyYXkobm9kZSkgPyBub2RlIDogT2JqZWN0LnZhbHVlcyhub2RlKSkge1xuICAgICAgICBpZiAoaXNPYmoodikpIHN0YWNrLnB1c2godik7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBbLi4ub3V0LnZhbHVlcygpXTtcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgVElNRUxJTkVfT1BTID0gWydIb21lVGltZWxpbmUnLCAnSG9tZUxhdGVzdFRpbWVsaW5lJywgJ1R3ZWV0RGV0YWlsJywgJ1VzZXJUd2VldHMnLCAnU2VhcmNoVGltZWxpbmUnXTtcblxuZXhwb3J0IGZ1bmN0aW9uIGlzVGltZWxpbmVVcmwodXJsOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3QgbSA9IC9cXC9ncmFwaHFsXFwvW14vXStcXC8oW0EtWmEtel0rKS8uZXhlYyh1cmwpO1xuICByZXR1cm4gISFtICYmIFRJTUVMSU5FX09QUy5pbmNsdWRlcyhtWzFdKTtcbn1cbiIsICJ7XG4gIFwidmVyc2lvblwiOiA3LFxuICBcInF1ZXN0aW9uc1wiOiBbXG4gICAge1xuICAgICAgXCJpZFwiOiBcInVzX3BvbGl0aWNzXCIsXG4gICAgICBcInRleHRcIjogXCJJcyB0aGlzIHBvc3QgKGluY2x1ZGluZyBhbnkgdGV4dCBpbiBhdHRhY2hlZCBpbWFnZXMpIGFib3V0IFVuaXRlZCBTdGF0ZXMgcG9saXRpY3MsIGVjb25vbWljcywgb3IgY3VsdHVyZSB3YXIsIHdyaXR0ZW4gYXMgaWYgdGhlIGF1dGhvciBsaXZlcyBpbiB0aGUgVVM/IEV4YW1wbGVzOiBEZW1vY3JhdHMgb3IgUmVwdWJsaWNhbnMsIFVTIHBvbGl0aWNpYW5zLCB0aGUgbWluaW11bSB3YWdlIG9yIHByaWNlcyBpbiBkb2xsYXJzLCByZW50IG9yIHdhZ2VzIGluIFVTIGNpdGllcywgVVMgaGVhbHRoY2FyZSBvciBpbnN1cmFuY2UsIHRheGVzLCBzdHVkZW50IGxvYW5zLCBndW5zLCBpbW1pZ3JhdGlvbiwgb3IgJ2luIHRoaXMgY291bnRyeScgY29tcGxhaW50cyBhYm91dCBBbWVyaWNhLiBBbnN3ZXIgbm8gZm9yIHBvc3RzIHRoYXQgYXJlIG5vdCBhYm91dCB0aGUgVVMsIGFuZCBmb3IgbmV1dHJhbCBuZXdzIHJlcG9ydHMuXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiaWRcIjogXCJpZGVvbG9neV9iYWl0XCIsXG4gICAgICBcInRleHRcIjogXCJJcyB0aGlzIHBvc3QgKGluY2x1ZGluZyBhbnkgdGV4dCBpbiBhdHRhY2hlZCBpbWFnZXMpIGEgc3dlZXBpbmcsIGxvdy1lZmZvcnQgdGFrZSBkZXNpZ25lZCB0byBmYXJtIHJlcGxpZXMgb24gYSBkaXZpc2l2ZSB0aGVtZSwgc3VjaCBhcyBjYXBpdGFsaXNtIHZzIHNvY2lhbGlzbSwgYmlsbGlvbmFpcmVzIG9yIHRoZSByaWNoLCB0aGUgd29ya2luZyBjbGFzcywgb3IgcmVqZWN0aW5nIG1vZGVybiB0ZWNobm9sb2d5IChcXFwibm9ib2R5IHdhbnRzIHNlbGYtZHJpdmluZyBjYXJzXFxcIiwgQUksIHNtYXJ0cGhvbmVzLCBjYXNobGVzcyBwYXltZW50cyksIHN0YXRlZCBhcyBhIHNsb2dhbiBvciBib2xkIGNsYWltIHJhdGhlciB0aGFuIGEgc3BlY2lmaWMgYXJndW1lbnQ/IEFuc3dlciBubyBmb3Igc3BlY2lmaWMsIHN1YnN0YW50aXZlIGFyZ3VtZW50cywgbmV3cywgb3IgcGVyc29uYWwgYW5lY2RvdGVzIHdpdGhvdXQgYSBwcm92b2NhdGl2ZSBnZW5lcmFsaXphdGlvbi5cIlxuICAgIH1cbiAgXSxcbiAgXCJjb21iaW5lXCI6IHtcbiAgICBcIm1heF9vZlwiOiBbXG4gICAgICBcInVzX3BvbGl0aWNzXCIsXG4gICAgICBcImlkZW9sb2d5X2JhaXRcIlxuICAgIF0sXG4gICAgXCJ3ZWlnaHRlZFwiOiB7fVxuICB9LFxuICBcInRocmVzaG9sZHNcIjoge1xuICAgIFwiaGlkZVwiOiAwLjgsXG4gICAgXCJibHVyXCI6IDAuNVxuICB9LFxuICBcInN0YW5jZVwiOiB7XG4gICAgXCJpZFwiOiBcImVuZG9yc2VzX3F1b3RlXCIsXG4gICAgXCJ0ZXh0XCI6IFwiQSByZXBseS1xdW90ZTogdGhlIGF1dGhvciB3cm90ZSB0aGUgZmlyc3QgcGFydCwgcXVvdGluZyB0aGUgcG9zdCBhZnRlciBbUXVvdGVkIHBvc3RdLiBEb2VzIHRoZSBhdXRob3Igc2lkZSB3aXRoIHRoZSBxdW90ZWQgcG9zdCwgd2FudGluZyByZWFkZXJzIHRvIGFncmVlIHdpdGggaXQ/IEFuc3dlciBubyBpZiB0aGUgYXV0aG9yIGlzIG1vY2tpbmcgaXQsIGFyZ3VpbmcgYWdhaW5zdCBpdCwgY29ycmVjdGluZyBpdCwgd2FybmluZyBwZW9wbGUgYWJvdXQgaXQsIG9yIGNvbW1lbnRpbmcgb24gc29tZXRoaW5nIGVsc2UuXCIsXG4gICAgXCJ0aHJlc2hvbGRcIjogMC44XG4gIH1cbn1cbiIsICJpbXBvcnQgcXVlc3Rpb25zIGZyb20gJy4uL2NvbmZpZy9xdWVzdGlvbnMuanNvbic7XG5pbXBvcnQgdHlwZSB7IERlY2lzaW9uLCBRdWVzdGlvbnNDb25maWcsIFNldHRpbmdzLCBVc2FnZSB9IGZyb20gJy4vdHlwZXMnO1xuXG5leHBvcnQgY29uc3QgUVVFU1RJT05TID0gcXVlc3Rpb25zIGFzIFF1ZXN0aW9uc0NvbmZpZztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBhcGlLZXk6ICcnLFxuICBtb2RlbDogJ2QxLjEnLFxuICB0aHJlc2hvbGRzOiB7IC4uLlFVRVNUSU9OUy50aHJlc2hvbGRzIH0sXG4gIGVuYWJsZWQ6IHsgcGVuZGluZzogdHJ1ZSwgaGlkZTogdHJ1ZSwgYmx1cjogdHJ1ZSwgZmxhZzogdHJ1ZSB9LFxuICBkYWlseVRva2VuQnVkZ2V0OiAxXzAwMF8wMDAsXG4gIGNhcHR1cmVGaXh0dXJlczogZmFsc2UsXG4gIGFsbG93ZWRDb3VudHJpZXM6IFsnVW5pdGVkIFN0YXRlcycsICdOb3J0aCBBbWVyaWNhJ10sXG4gIHNjb3JlSW1hZ2VzOiB0cnVlLFxufTtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gIGNvbnN0IHsgc2V0dGluZ3MgfSA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldCgnc2V0dGluZ3MnKTtcbiAgY29uc3QgcyA9IChzZXR0aW5ncyA/PyB7fSkgYXMgUGFydGlhbDxTZXR0aW5ncz4gJiB7IHRocmVzaG9sZHNGb3I/OiBudW1iZXIgfTtcbiAgLy8gVGhyZXNob2xkcyBhcmUgdHVuZWQgcGVyIHF1ZXN0aW9uIHNldCwgc28gc2F2ZWQgb25lcyBvbmx5IGFwcGx5IHRvIHRoZSB2ZXJzaW9uIHRoZXkgd2VyZSBzYXZlZCB1bmRlci5cbiAgY29uc3Qgc2F2ZWQgPSBzLnRocmVzaG9sZHNGb3IgPT09IFFVRVNUSU9OUy52ZXJzaW9uID8gcy50aHJlc2hvbGRzIDogdW5kZWZpbmVkO1xuICByZXR1cm4ge1xuICAgIC4uLkRFRkFVTFRfU0VUVElOR1MsXG4gICAgLi4ucyxcbiAgICB0aHJlc2hvbGRzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MudGhyZXNob2xkcywgLi4uc2F2ZWQgfSxcbiAgICBlbmFibGVkOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MuZW5hYmxlZCwgLi4ucy5lbmFibGVkIH0sXG4gIH07XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlU2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgc2V0dGluZ3M6IHsgLi4ucywgdGhyZXNob2xkc0ZvcjogUVVFU1RJT05TLnZlcnNpb24gfSB9KTtcbn1cblxuZXhwb3J0IGNvbnN0IHRvZGF5ID0gKCkgPT4gbmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUNBJyk7XG5cbmV4cG9ydCBjb25zdCBlbXB0eVVzYWdlID0gKCk6IFVzYWdlID0+ICh7IGRhdGU6IHRvZGF5KCksIHRva2VuczogMCwgc2NvcmVkOiAwLCBkZWNpc2lvbnM6IHsgaGlkZTogMCwgYmx1cjogMCwgc2hvdzogMCB9IH0pO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbG9hZFVzYWdlKCk6IFByb21pc2U8VXNhZ2U+IHtcbiAgY29uc3QgeyB1c2FnZSB9ID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KCd1c2FnZScpO1xuICBjb25zdCB1ID0gdXNhZ2UgYXMgVXNhZ2UgfCB1bmRlZmluZWQ7XG4gIHJldHVybiB1ICYmIHUuZGF0ZSA9PT0gdG9kYXkoKSA/IHUgOiBlbXB0eVVzYWdlKCk7XG59XG5cbi8qKiBXaXRob3V0IGEgZGVjaXNpb24gb25seSB0b2tlbnMgYXJlIGNvdW50ZWQgKGUuZy4gdGhlIHF1b3RlLXN0YW5jZSBmb2xsb3ctdXAgY2FsbCkuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVjb3JkVXNhZ2UodG9rZW5zOiBudW1iZXIsIGRlY2lzaW9uPzogRGVjaXNpb24pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdSA9IGF3YWl0IGxvYWRVc2FnZSgpO1xuICB1LnRva2VucyArPSB0b2tlbnM7XG4gIGlmIChkZWNpc2lvbikge1xuICAgIHUuc2NvcmVkKys7XG4gICAgdS5kZWNpc2lvbnNbZGVjaXNpb25dKys7XG4gIH1cbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgdXNhZ2U6IHUgfSk7XG59XG4iLCAiZXhwb3J0IGludGVyZmFjZSBQb3N0IHtcbiAgaWQ6IHN0cmluZztcbiAgdGV4dDogc3RyaW5nO1xuICBhdXRob3I/OiBzdHJpbmc7XG4gIHF1b3RlZFRleHQ/OiBzdHJpbmc7XG4gIHF1b3RlZEF1dGhvcj86IHN0cmluZztcbiAgLyoqXG4gICAqIFRoZSBxdW90ZWQgcG9zdCdzIGlkIHdoZW4ga25vd24gKGZyb20gWCdzIEpTT04pLiBUaGUgcXVvdGVkIHBvc3QgaXMgdGhlbiBzY29yZWQgb24gaXRzIG93bixcbiAgICogYW5kIHRoaXMgcG9zdCBpcyBzY29yZWQgd2l0aG91dCBpdDsgRE9NLXNjcmFwZWQgcG9zdHMgbGFjayBpdCBhbmQgYXJlIHNjb3JlZCB3aXRoIHRoZSBxdW90ZS5cbiAgICovXG4gIHF1b3RlZElkPzogc3RyaW5nO1xuICAvKiogVGhpcyBwb3N0J3Mgb3duIHBob3RvIFVSTHMgKG5vdCB0aGUgcXVvdGUncyB3aGVuIHF1b3RlZElkIGlzIHNldCksIHNpemVkIGZvciBzY29yaW5nLiAqL1xuICBpbWFnZVVybHM/OiBzdHJpbmdbXTtcbiAgaXNSZXBseTogYm9vbGVhbjtcbiAgLyoqIFwicGFyc2VyXCIgd2hlbiBpdCBjYW1lIGZyb20gaW50ZXJjZXB0ZWQgSlNPTiwgXCJkb21cIiB3aGVuIHNjcmFwZWQgYXMgYSBmYWxsYmFjay4gKi9cbiAgc291cmNlPzogJ3BhcnNlcicgfCAnZG9tJztcbn1cblxuZXhwb3J0IHR5cGUgRGVjaXNpb24gPSAnaGlkZScgfCAnYmx1cicgfCAnc2hvdyc7XG5leHBvcnQgdHlwZSBMYWJlbFZhbHVlID0gJ3JhZ2ViYWl0JyB8ICdyYWNpc3QnIHwgJ2ZpbmUnO1xuZXhwb3J0IHR5cGUgTGFiZWxTb3VyY2UgPSAndXNlcl9idXR0b24nIHwgJ3Nob3dfY2xpY2snIHwgJ2FjY291bnRfc2VlZCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUXVlc3Rpb24ge1xuICBpZDogc3RyaW5nO1xuICB0ZXh0OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUXVlc3Rpb25zQ29uZmlnIHtcbiAgdmVyc2lvbjogbnVtYmVyO1xuICBxdWVzdGlvbnM6IFF1ZXN0aW9uW107XG4gIGNvbWJpbmU6IHsgbWF4X29mOiBzdHJpbmdbXTsgd2VpZ2h0ZWQ6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gfTtcbiAgdGhyZXNob2xkczogVGhyZXNob2xkcztcbiAgLyoqXG4gICAqIEFza2VkIChpbiBhIHNlY29uZCwgb25lLXF1ZXN0aW9uIGNhbGwpIG9ubHkgZm9yIHBvc3RzIHRoYXQgcXVvdGUgYSBwb3N0IHNjb3JpbmcgYXQgbGVhc3QgdGhlIGJsdXJcbiAgICogdGhyZXNob2xkLiBBdCBvciBhYm92ZSBgdGhyZXNob2xkYCwgdGhlIHF1b3RpbmcgcG9zdCBpbmhlcml0cyB0aGUgcXVvdGVkIHBvc3QncyBzY29yZS5cbiAgICovXG4gIHN0YW5jZT86IFF1ZXN0aW9uICYgeyB0aHJlc2hvbGQ6IG51bWJlciB9O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRocmVzaG9sZHMge1xuICBoaWRlOiBudW1iZXI7XG4gIGJsdXI6IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQb3N0UmVjb3JkIHtcbiAgaWQ6IHN0cmluZztcbiAgdGV4dDogc3RyaW5nO1xuICBxdW90ZWRUZXh0Pzogc3RyaW5nO1xuICBxdW90ZWRJZD86IHN0cmluZztcbiAgLyoqIFAoYXV0aG9yIGVuZG9yc2VzIHRoZSBxdW90ZWQgcG9zdCksIG9uY2UgYXNrZWQuICovXG4gIGVuZG9yc2VzUXVvdGU/OiBudW1iZXI7XG4gIGF1dGhvcj86IHN0cmluZztcbiAgc2VlbkF0OiBudW1iZXI7XG4gIHByb2JzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+O1xuICBzY29yZTogbnVtYmVyO1xuICBkZWNpc2lvbjogRGVjaXNpb247XG4gIHF1ZXN0aW9uc1ZlcnNpb246IG51bWJlcjtcbiAgLyoqIFwic2VlZGVkXCIgd2hlbiBkZWNpZGVkIGJ5IHRoZSBhY2NvdW50IHNlZWQgbGlzdCwgXCJkMVwiIHdoZW4gc2NvcmVkLiAqL1xuICByZWFzb24/OiAnc2VlZGVkJyB8ICdkMSc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTGFiZWxSZWNvcmQge1xuICBpZD86IG51bWJlcjtcbiAgcG9zdElkOiBzdHJpbmc7XG4gIGxhYmVsOiBMYWJlbFZhbHVlO1xuICBzb3VyY2U6IExhYmVsU291cmNlO1xuICBhdDogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEF1dGhvclJlY29yZCB7XG4gIGhhbmRsZTogc3RyaW5nO1xuICBhbHBoYTogbnVtYmVyO1xuICBiZXRhOiBudW1iZXI7XG4gIHNlZWRlZDogYm9vbGVhbjtcbiAgc2VlZFRleHQ/OiBzdHJpbmc7XG4gIHBvc3RzU2VlbjogbnVtYmVyO1xufVxuXG4vKiogV2hhdCB0aGUgYmFja2dyb3VuZCByZXR1cm5zIHRvIGEgdGFiIGZvciBvbmUgcG9zdC4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgVmVyZGljdCB7XG4gIHBvc3RJZDogc3RyaW5nO1xuICAvKiogXCJ1bnNjb3JlZFwiIHdoZW4gc2NvcmluZyB3YXMgc2tpcHBlZCAobm8ga2V5LCBidWRnZXQgZXhjZWVkZWQsIEFQSSBlcnJvcikuICovXG4gIGRlY2lzaW9uOiBEZWNpc2lvbiB8ICd1bnNjb3JlZCc7XG4gIHNjb3JlPzogbnVtYmVyO1xuICB0b3BRdWVzdGlvbj86IHN0cmluZztcbiAgYXV0aG9yPzogc3RyaW5nO1xuICBhdXRob3JTY29yZT86IG51bWJlcjtcbiAgcmVhc29uPzogJ3NlZWRlZCcgfCAnZDEnIHwgJ2NhY2hlJyB8ICdidWRnZXQnIHwgJ25vX2tleScgfCAnZXJyb3InIHwgJ2NvdW50cnknO1xuICAvKiogVGhlIGF1dGhvcidzIFwiQWNjb3VudCBiYXNlZCBpblwiIHZhbHVlLCB3aGVuIGtub3duLiAqL1xuICBjb3VudHJ5Pzogc3RyaW5nO1xuICAvKiogU2V0ICh3aXRoIGRlY2lzaW9uIFwidW5zY29yZWRcIikgd2hlbiB0aGUgdG9waWMgZmlyZWQgYW5kIHRoZSBhdXRob3IncyBjb3VudHJ5IG11c3QgYmUgbG9va2VkIHVwIGZpcnN0LiAqL1xuICBuZWVkc0NvdW50cnk/OiBzdHJpbmc7XG59XG5cbi8qKiBDYWNoZWQgXCJBYm91dCB0aGlzIGFjY291bnRcIiByZXN1bHQuIGBjb3VudHJ5YCBpcyB1bmRlZmluZWQgd2hlbiBYIHJldHVybmVkIG5vdGhpbmcuICovXG5leHBvcnQgaW50ZXJmYWNlIENvdW50cnlSZWNvcmQge1xuICBoYW5kbGU6IHN0cmluZztcbiAgY291bnRyeT86IHN0cmluZztcbiAgLyoqIFgncyBsb2NhdGlvbl9hY2N1cmF0ZSBmbGFnIChmYWxzZSBoaW50cyBhdCBhIFZQTi9wcm94eSkuICovXG4gIGFjY3VyYXRlPzogYm9vbGVhbjtcbiAgZmV0Y2hlZEF0OiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgU2V0dGluZ3Mge1xuICBhcGlLZXk6IHN0cmluZztcbiAgbW9kZWw6IHN0cmluZztcbiAgdGhyZXNob2xkczogVGhyZXNob2xkcztcbiAgZW5hYmxlZDogeyBwZW5kaW5nOiBib29sZWFuOyBoaWRlOiBib29sZWFuOyBibHVyOiBib29sZWFuOyBmbGFnOiBib29sZWFuIH07XG4gIGRhaWx5VG9rZW5CdWRnZXQ6IG51bWJlcjtcbiAgY2FwdHVyZUZpeHR1cmVzOiBib29sZWFuO1xuICAvKiogXCJBY2NvdW50IGJhc2VkIGluXCIgdmFsdWVzIHdob3NlIHBvc3RzIGFyZSBuZXZlciBmaWx0ZXJlZCAoY2FzZS1pbnNlbnNpdGl2ZSkuICovXG4gIGFsbG93ZWRDb3VudHJpZXM6IHN0cmluZ1tdO1xuICAvKiogU2VuZCBhdHRhY2hlZCBwaG90b3MgdG8gZDEgYWxvbmcgd2l0aCB0aGUgdGV4dC4gKi9cbiAgc2NvcmVJbWFnZXM6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVXNhZ2Uge1xuICBkYXRlOiBzdHJpbmc7XG4gIHRva2VuczogbnVtYmVyO1xuICBzY29yZWQ6IG51bWJlcjtcbiAgZGVjaXNpb25zOiBSZWNvcmQ8RGVjaXNpb24sIG51bWJlcj47XG59XG5cbmV4cG9ydCBjb25zdCBNU0dfTlMgPSAnYmFpdGJsb2NrZXI6djEnO1xuIiwgIi8vIElzb2xhdGVkLXdvcmxkIGNvbnRlbnQgc2NyaXB0OiBtYXRjaGVzIERPTSBwb3N0cyB0byB2ZXJkaWN0cyBhbmQgcmVuZGVycyBVSSBzdGF0ZXMuXG5pbXBvcnQgdHlwZSB7IExvb2t1cFJlc3VsdCB9IGZyb20gJy4vY291bnRyeSc7XG5pbXBvcnQgeyBNQVhfSU1BR0VTLCBzY29yaW5nSW1hZ2VVcmwgfSBmcm9tICcuL3BhcnNlcic7XG5pbXBvcnQgeyBsb2FkU2V0dGluZ3MgfSBmcm9tICcuL3NldHRpbmdzJztcbmltcG9ydCB7IE1TR19OUywgdHlwZSBMYWJlbFZhbHVlLCB0eXBlIFBvc3QsIHR5cGUgU2V0dGluZ3MsIHR5cGUgVmVyZGljdCB9IGZyb20gJy4vdHlwZXMnO1xuXG5jb25zdCBwb3N0cyA9IG5ldyBNYXA8c3RyaW5nLCBQb3N0PigpO1xuY29uc3QgdmVyZGljdHMgPSBuZXcgTWFwPHN0cmluZywgVmVyZGljdD4oKTtcbmNvbnN0IHJlcXVlc3RlZCA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuY29uc3QgcmV2ZWFsZWQgPSBuZXcgU2V0PHN0cmluZz4oKTtcbmNvbnN0IGZhbGxiYWNrVGltZXJzID0gbmV3IE1hcDxzdHJpbmcsIFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+PigpO1xubGV0IHNldHRpbmdzOiBTZXR0aW5ncyB8IHVuZGVmaW5lZDtcblxuY29uc3QgRkFMTEJBQ0tfREVMQVlfTVMgPSA0MDA7XG4vKiogUXVlc3Rpb25zIG5hbWVkIGluIHRoZSBVSSB3aGVuIHRoZXkgYXJlIHRoZSB0b3AgcmVhc29uOyBldmVyeXRoaW5nIGVsc2Ugc2hvd3MgYXMgXCJyYWdlYmFpdFwiLiAqL1xuY29uc3QgTkFNRUQ6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gIHVzX3BvbGl0aWNzOiAnVVMtcG9saXRpY3MgYmFpdCcsXG4gIGlkZW9sb2d5X2JhaXQ6ICdpZGVvbG9neSBiYWl0JyxcbiAgZW5kb3JzZXNfcXVvdGU6ICdlbmRvcnNlcyBxdW90ZWQgYmFpdCcsXG59O1xuLyoqIEhhbmRsZXMgd2hvc2UgY291bnRyeSBsb29rdXAgaXMgaW4gZmxpZ2h0LCBtYXBwZWQgdG8gdGhlIHBvc3RzIHdhaXRpbmcgb24gaXQuICovXG5jb25zdCBjb3VudHJ5V2FpdGVycyA9IG5ldyBNYXA8c3RyaW5nLCBTZXQ8c3RyaW5nPj4oKTtcblxuLy8gLS0tLS0tLS0tLSBtZXNzYWdpbmcgLS0tLS0tLS0tLVxuXG5mdW5jdGlvbiByZXF1ZXN0VmVyZGljdChwb3N0OiBQb3N0KSB7XG4gIGlmIChyZXF1ZXN0ZWQuaGFzKHBvc3QuaWQpKSByZXR1cm47XG4gIHJlcXVlc3RlZC5hZGQocG9zdC5pZCk7XG4gIGNocm9tZS5ydW50aW1lXG4gICAgLnNlbmRNZXNzYWdlKHsgdHlwZTogJ3Njb3JlJywgcG9zdCB9KVxuICAgIC50aGVuKCh2OiBWZXJkaWN0IHwgdW5kZWZpbmVkKSA9PiB7XG4gICAgICBpZiAodj8ubmVlZHNDb3VudHJ5KSByZXR1cm4gYXdhaXRDb3VudHJ5KHBvc3QuaWQsIHYubmVlZHNDb3VudHJ5KTtcbiAgICAgIHZlcmRpY3RzLnNldChwb3N0LmlkLCB2ID8/IHsgcG9zdElkOiBwb3N0LmlkLCBkZWNpc2lvbjogJ3Vuc2NvcmVkJywgcmVhc29uOiAnZXJyb3InIH0pO1xuICAgICAgcmVhc2tRdW90ZXJzKHBvc3QuaWQpO1xuICAgICAgc2NoZWR1bGUoKTtcbiAgICB9KVxuICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAvLyBleHRlbnNpb24gcmVsb2FkZWQgb3Igd29ya2VyIHVuYXZhaWxhYmxlOiBzaG93IHRoZSBwb3N0IHVudG91Y2hlZFxuICAgICAgdmVyZGljdHMuc2V0KHBvc3QuaWQsIHsgcG9zdElkOiBwb3N0LmlkLCBkZWNpc2lvbjogJ3Vuc2NvcmVkJywgcmVhc29uOiAnZXJyb3InIH0pO1xuICAgICAgc2NoZWR1bGUoKTtcbiAgICB9KTtcbn1cblxuLyoqIFBvc3RzIHF1b3RpbmcgYHF1b3RlZElkYCBtYXkgbm93IGluaGVyaXQgaXRzIHNjb3JlIChpZiB0aGV5IGVuZG9yc2UgaXQpOiBhc2sgYWdhaW4gKGFuc3dlcmVkIGZyb20gY2FjaGUpLiAqL1xuZnVuY3Rpb24gcmVhc2tRdW90ZXJzKHF1b3RlZElkOiBzdHJpbmcpIHtcbiAgZm9yIChjb25zdCBwIG9mIHBvc3RzLnZhbHVlcygpKSB7XG4gICAgaWYgKHAucXVvdGVkSWQgIT09IHF1b3RlZElkIHx8ICF2ZXJkaWN0cy5oYXMocC5pZCkpIGNvbnRpbnVlO1xuICAgIHJlcXVlc3RlZC5kZWxldGUocC5pZCk7XG4gICAgcmVxdWVzdFZlcmRpY3QocCk7XG4gIH1cbn1cblxuLyoqIExlYXZlcyB0aGUgcG9zdCBwZW5kaW5nIChkaW1tZWQpIHVudGlsIHRoZSBwYWdlIHNjcmlwdCBoYXMgZmV0Y2hlZCB0aGUgYXV0aG9yJ3MgY291bnRyeS4gKi9cbmZ1bmN0aW9uIGF3YWl0Q291bnRyeShwb3N0SWQ6IHN0cmluZywgaGFuZGxlOiBzdHJpbmcpIHtcbiAgbGV0IHdhaXRpbmcgPSBjb3VudHJ5V2FpdGVycy5nZXQoaGFuZGxlKTtcbiAgaWYgKCF3YWl0aW5nKSB7XG4gICAgY291bnRyeVdhaXRlcnMuc2V0KGhhbmRsZSwgKHdhaXRpbmcgPSBuZXcgU2V0KCkpKTtcbiAgICB3aW5kb3cucG9zdE1lc3NhZ2UoeyBuczogTVNHX05TLCB0eXBlOiAnbG9va3VwQ291bnRyeScsIGhhbmRsZSB9LCBsb2NhdGlvbi5vcmlnaW4pO1xuICB9XG4gIHdhaXRpbmcuYWRkKHBvc3RJZCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG9uQ291bnRyeVJlc3VsdChoYW5kbGU6IHN0cmluZywgcmVzdWx0OiBMb29rdXBSZXN1bHQpIHtcbiAgY29uc3Qgd2FpdGluZyA9IGNvdW50cnlXYWl0ZXJzLmdldChoYW5kbGUpID8/IG5ldyBTZXQ8c3RyaW5nPigpO1xuICBjb3VudHJ5V2FpdGVycy5kZWxldGUoaGFuZGxlKTtcbiAgaWYgKHJlc3VsdC5vaykge1xuICAgIGF3YWl0IGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ2NvdW50cnknLCBoYW5kbGUsIGluZm86IHJlc3VsdC5pbmZvIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgICBmb3IgKGNvbnN0IGlkIG9mIHdhaXRpbmcpIHtcbiAgICAgIHJlcXVlc3RlZC5kZWxldGUoaWQpO1xuICAgICAgY29uc3QgcCA9IHBvc3RzLmdldChpZCk7XG4gICAgICBpZiAocCkgcmVxdWVzdFZlcmRpY3QocCk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUuZGVidWcoJ1tiYWl0YmxvY2tlcl0gY291bnRyeSBsb29rdXAgZmFpbGVkJywgaGFuZGxlLCByZXN1bHQuZXJyb3IpO1xuICAgIGlmIChyZXN1bHQuZXJyb3IgPT09ICdzdGFsZV9xdWVyeScpIGNvbnNvbGUuaW5mbygnW2JhaXRibG9ja2VyXSBPcGVuIGFueSBwcm9maWxlXFwncyBcIkFib3V0IHRoaXMgYWNjb3VudFwiIHBhZ2Ugb25jZSBzbyB0aGUgZXh0ZW5zaW9uIGNhbiBsZWFybiBYXFwncyBuZXcgcXVlcnkgaWQuJyk7XG4gICAgZm9yIChjb25zdCBpZCBvZiB3YWl0aW5nKSB2ZXJkaWN0cy5zZXQoaWQsIHsgcG9zdElkOiBpZCwgZGVjaXNpb246ICd1bnNjb3JlZCcsIHJlYXNvbjogJ2Vycm9yJyB9KTtcbiAgfVxuICBzY2hlZHVsZSgpO1xufVxuXG5mdW5jdGlvbiBzZW5kTGFiZWwocG9zdElkOiBzdHJpbmcsIGxhYmVsOiBMYWJlbFZhbHVlLCBzb3VyY2U6ICd1c2VyX2J1dHRvbicgfCAnc2hvd19jbGljaycpIHtcbiAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnbGFiZWwnLCBsYWJlbDogeyBwb3N0SWQsIGxhYmVsLCBzb3VyY2UgfSB9KS5jYXRjaCgoKSA9PiB7fSk7XG59XG5cbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKGUpID0+IHtcbiAgaWYgKGUuc291cmNlICE9PSB3aW5kb3cgfHwgZS5kYXRhPy5ucyAhPT0gTVNHX05TKSByZXR1cm47XG4gIGlmIChlLmRhdGEudHlwZSA9PT0gJ3Bvc3RzJykge1xuICAgIGZvciAoY29uc3QgcCBvZiBlLmRhdGEucG9zdHMgYXMgUG9zdFtdKSB7XG4gICAgICBpZiAoIXBvc3RzLmhhcyhwLmlkKSkgcG9zdHMuc2V0KHAuaWQsIHApO1xuICAgICAgcmVxdWVzdFZlcmRpY3QocCk7XG4gICAgfVxuICAgIHNjaGVkdWxlKCk7XG4gIH0gZWxzZSBpZiAoZS5kYXRhLnR5cGUgPT09ICdjb3VudHJ5UmVzdWx0JyAmJiB0eXBlb2YgZS5kYXRhLmhhbmRsZSA9PT0gJ3N0cmluZycpIHtcbiAgICBvbkNvdW50cnlSZXN1bHQoZS5kYXRhLmhhbmRsZSwgZS5kYXRhLnJlc3VsdCBhcyBMb29rdXBSZXN1bHQpO1xuICB9IGVsc2UgaWYgKGUuZGF0YS50eXBlID09PSAnY2FwdHVyZScpIHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdjYXB0dXJlJywgdXJsOiBlLmRhdGEudXJsLCBib2R5OiBlLmRhdGEuYm9keSB9KS5jYXRjaCgoKSA9PiB7fSk7XG4gIH1cbn0pO1xuXG5hc3luYyBmdW5jdGlvbiByZWZyZXNoU2V0dGluZ3MoKSB7XG4gIHNldHRpbmdzID0gYXdhaXQgbG9hZFNldHRpbmdzKCk7XG4gIHdpbmRvdy5wb3N0TWVzc2FnZSh7IG5zOiBNU0dfTlMsIHR5cGU6ICdjb25maWcnLCBjYXB0dXJlOiBzZXR0aW5ncy5jYXB0dXJlRml4dHVyZXMgfSwgbG9jYXRpb24ub3JpZ2luKTtcbn1cblxuY2hyb21lLnN0b3JhZ2Uub25DaGFuZ2VkLmFkZExpc3RlbmVyKChjaGFuZ2VzKSA9PiB7XG4gIGlmICghY2hhbmdlcy5zZXR0aW5ncykgcmV0dXJuO1xuICByZWZyZXNoU2V0dGluZ3MoKS50aGVuKCgpID0+IHtcbiAgICAvLyB0aHJlc2hvbGRzIG1heSBoYXZlIGNoYW5nZWQ6IHJlLWFzazsgdGhlIGJhY2tncm91bmQgYW5zd2VycyBjYWNoZWQgcG9zdHMgZnJvbSBzdG9yZWQgcHJvYmFiaWxpdGllc1xuICAgIHZlcmRpY3RzLmNsZWFyKCk7XG4gICAgcmVxdWVzdGVkLmNsZWFyKCk7XG4gICAgY291bnRyeVdhaXRlcnMuY2xlYXIoKTtcbiAgICBmb3IgKGNvbnN0IHAgb2YgcG9zdHMudmFsdWVzKCkpIHJlcXVlc3RWZXJkaWN0KHApO1xuICAgIHNjaGVkdWxlKCk7XG4gIH0pO1xufSk7XG5cbi8vIC0tLS0tLS0tLS0gRE9NIG1hdGNoaW5nIC0tLS0tLS0tLS1cblxuZnVuY3Rpb24gcG9zdElkT2YoYXJ0aWNsZTogRWxlbWVudCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IGxpbmsgPSBhcnRpY2xlLnF1ZXJ5U2VsZWN0b3IoJ2FbaHJlZio9XCIvc3RhdHVzL1wiXSB0aW1lJyk/LmNsb3Nlc3QoJ2EnKSA/PyBhcnRpY2xlLnF1ZXJ5U2VsZWN0b3IoJ2FbaHJlZio9XCIvc3RhdHVzL1wiXScpO1xuICByZXR1cm4gL1xcL3N0YXR1c1xcLyhcXGQrKS8uZXhlYyhsaW5rPy5nZXRBdHRyaWJ1dGUoJ2hyZWYnKSA/PyAnJyk/LlsxXTtcbn1cblxuZnVuY3Rpb24gc2NyYXBlUG9zdChhcnRpY2xlOiBFbGVtZW50LCBpZDogc3RyaW5nKTogUG9zdCB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IHRleHRzID0gYXJ0aWNsZS5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PignW2RhdGEtdGVzdGlkPVwidHdlZXRUZXh0XCJdJyk7XG4gIGNvbnN0IGhhbmRsZXMgPSBbLi4uYXJ0aWNsZS5xdWVyeVNlbGVjdG9yQWxsKCdbZGF0YS10ZXN0aWQ9XCJVc2VyLU5hbWVcIl0gYVtocmVmXj1cIi9cIl0nKV1cbiAgICAubWFwKChhKSA9PiAvXlxcLyhbQS1aYS16MC05X10rKSQvLmV4ZWMoYS5nZXRBdHRyaWJ1dGUoJ2hyZWYnKSA/PyAnJyk/LlsxXSlcbiAgICAuZmlsdGVyKChoKTogaCBpcyBzdHJpbmcgPT4gISFoKTtcbiAgY29uc3QgdGV4dCA9IHRleHRzWzBdPy5pbm5lclRleHQgPz8gJyc7XG4gIGNvbnN0IGltYWdlcyA9IFsuLi5hcnRpY2xlLnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEltYWdlRWxlbWVudD4oJ1tkYXRhLXRlc3RpZD1cInR3ZWV0UGhvdG9cIl0gaW1nJyldXG4gICAgLm1hcCgoaSkgPT4gc2NvcmluZ0ltYWdlVXJsKGkuc3JjKSlcbiAgICAuZmlsdGVyKCh1KTogdSBpcyBzdHJpbmcgPT4gISF1KTtcbiAgaWYgKCF0ZXh0ICYmICFoYW5kbGVzLmxlbmd0aCAmJiAhaW1hZ2VzLmxlbmd0aCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgcmV0dXJuIHtcbiAgICBpZCxcbiAgICB0ZXh0LFxuICAgIGF1dGhvcjogaGFuZGxlc1swXSxcbiAgICBxdW90ZWRUZXh0OiB0ZXh0c1sxXT8uaW5uZXJUZXh0LFxuICAgIHF1b3RlZEF1dGhvcjogaGFuZGxlc1sxXSxcbiAgICBpbWFnZVVybHM6IGltYWdlcy5sZW5ndGggPyBbLi4ubmV3IFNldChpbWFnZXMpXS5zbGljZSgwLCBNQVhfSU1BR0VTKSA6IHVuZGVmaW5lZCxcbiAgICBpc1JlcGx5OiBmYWxzZSxcbiAgICBzb3VyY2U6ICdkb20nLFxuICB9O1xufVxuXG5mdW5jdGlvbiBlbnN1cmVQb3N0KGFydGljbGU6IEVsZW1lbnQsIGlkOiBzdHJpbmcpIHtcbiAgaWYgKHBvc3RzLmhhcyhpZCkgfHwgcmVxdWVzdGVkLmhhcyhpZCkgfHwgZmFsbGJhY2tUaW1lcnMuaGFzKGlkKSkgcmV0dXJuO1xuICBmYWxsYmFja1RpbWVycy5zZXQoXG4gICAgaWQsXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBmYWxsYmFja1RpbWVycy5kZWxldGUoaWQpO1xuICAgICAgaWYgKHBvc3RzLmhhcyhpZCkgfHwgcmVxdWVzdGVkLmhhcyhpZCkgfHwgIWFydGljbGUuaXNDb25uZWN0ZWQgfHwgcG9zdElkT2YoYXJ0aWNsZSkgIT09IGlkKSByZXR1cm47XG4gICAgICBjb25zdCBwID0gc2NyYXBlUG9zdChhcnRpY2xlLCBpZCk7XG4gICAgICBpZiAoIXApIHJldHVybjtcbiAgICAgIHBvc3RzLnNldChpZCwgcCk7XG4gICAgICByZXF1ZXN0VmVyZGljdChwKTtcbiAgICB9LCBGQUxMQkFDS19ERUxBWV9NUyksXG4gICk7XG59XG5cbi8vIC0tLS0tLS0tLS0gcmVuZGVyaW5nIC0tLS0tLS0tLS1cblxudHlwZSBTdGF0ZSA9ICdwZW5kaW5nJyB8ICdoaWRlJyB8ICdibHVyJyB8ICdzaG93JztcbmNvbnN0IHJlbmRlcmVkID0gbmV3IFdlYWtNYXA8RWxlbWVudCwgc3RyaW5nPigpO1xuXG5mdW5jdGlvbiBzdGF0ZUZvcihpZDogc3RyaW5nKTogeyBzdGF0ZTogU3RhdGU7IHY/OiBWZXJkaWN0IH0ge1xuICBjb25zdCB2ID0gdmVyZGljdHMuZ2V0KGlkKTtcbiAgY29uc3QgZW4gPSBzZXR0aW5ncz8uZW5hYmxlZDtcbiAgaWYgKCF2KSByZXR1cm4geyBzdGF0ZTogZW4/LnBlbmRpbmcgPT09IGZhbHNlID8gJ3Nob3cnIDogJ3BlbmRpbmcnIH07XG4gIGlmIChyZXZlYWxlZC5oYXMoaWQpIHx8IHYuZGVjaXNpb24gPT09ICd1bnNjb3JlZCcpIHJldHVybiB7IHN0YXRlOiAnc2hvdycsIHYgfTtcbiAgbGV0IGQ6IFN0YXRlID0gdi5kZWNpc2lvbjtcbiAgaWYgKGQgPT09ICdoaWRlJyAmJiBlbj8uaGlkZSA9PT0gZmFsc2UpIGQgPSAnYmx1cic7XG4gIGlmIChkID09PSAnYmx1cicgJiYgZW4/LmJsdXIgPT09IGZhbHNlKSBkID0gJ3Nob3cnO1xuICByZXR1cm4geyBzdGF0ZTogZCwgdiB9O1xufVxuXG5mdW5jdGlvbiBjbGVhcihhcnRpY2xlOiBIVE1MRWxlbWVudCkge1xuICBhcnRpY2xlLmNsYXNzTGlzdC5yZW1vdmUoJ2JiLXBlbmRpbmcnLCAnYmItaGlkZScsICdiYi1ibHVyJywgJ2JiLXNob3cnKTtcbiAgYXJ0aWNsZS5xdWVyeVNlbGVjdG9yQWxsKCc6c2NvcGUgPiAuYmItdWksIC5iYi1xYmFyJykuZm9yRWFjaCgobikgPT4gbi5yZW1vdmUoKSk7XG4gIGFydGljbGUucXVlcnlTZWxlY3RvckFsbCgnLmJiLXFibHVyLCAuYmItcXBlbmRpbmcnKS5mb3JFYWNoKChuKSA9PiBuLmNsYXNzTGlzdC5yZW1vdmUoJ2JiLXFibHVyJywgJ2JiLXFwZW5kaW5nJykpO1xufVxuXG4vKiogVGhlIGVtYmVkZGVkIHF1b3RlZC1wb3N0IGJveDogdGhlIGNsaWNrYWJsZSBjb250YWluZXIgYXJvdW5kIHRoZSBwb3N0J3Mgc2Vjb25kIGF1dGhvciBuYW1lLiAqL1xuZnVuY3Rpb24gcXVvdGVCb3goYXJ0aWNsZTogSFRNTEVsZW1lbnQpOiBIVE1MRWxlbWVudCB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IGJveCA9IGFydGljbGUucXVlcnlTZWxlY3RvckFsbCgnW2RhdGEtdGVzdGlkPVwiVXNlci1OYW1lXCJdJylbMV0/LmNsb3Nlc3Q8SFRNTEVsZW1lbnQ+KCdkaXZbcm9sZT1cImxpbmtcIl0nKTtcbiAgcmV0dXJuIGJveCAmJiBhcnRpY2xlLmNvbnRhaW5zKGJveCkgPyBib3ggOiB1bmRlZmluZWQ7XG59XG5cbmZ1bmN0aW9uIGVsPEsgZXh0ZW5kcyBrZXlvZiBIVE1MRWxlbWVudFRhZ05hbWVNYXA+KHRhZzogSywgY2xzOiBzdHJpbmcsIHRleHQ/OiBzdHJpbmcpOiBIVE1MRWxlbWVudFRhZ05hbWVNYXBbS10ge1xuICBjb25zdCBuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xuICBuLmNsYXNzTmFtZSA9IGNscztcbiAgaWYgKHRleHQpIG4udGV4dENvbnRlbnQgPSB0ZXh0O1xuICByZXR1cm4gbjtcbn1cblxuZnVuY3Rpb24gYnV0dG9uKHRleHQ6IHN0cmluZywgb25DbGljazogKCkgPT4gdm9pZCk6IEhUTUxCdXR0b25FbGVtZW50IHtcbiAgY29uc3QgYiA9IGVsKCdidXR0b24nLCAnYmItYnRuJywgdGV4dCk7XG4gIGIudHlwZSA9ICdidXR0b24nO1xuICBiLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBvbkNsaWNrKCk7XG4gIH0pO1xuICByZXR1cm4gYjtcbn1cblxuLyoqIFN0b3BzIGNsaWNrcyBvbiBvdXIgVUkgZnJvbSBvcGVuaW5nIHRoZSBwb3N0LiAqL1xuZnVuY3Rpb24gc3dhbGxvdyhuOiBIVE1MRWxlbWVudCkge1xuICBuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICB9KTtcbiAgcmV0dXJuIG47XG59XG5cbmZ1bmN0aW9uIHJlYXNvbk5hbWUodjogVmVyZGljdCk6IHN0cmluZyB7XG4gIGlmICh2LnRvcFF1ZXN0aW9uID09PSAnc2VlZGVkX2F1dGhvcicpIHJldHVybiAnc2VlZGVkIGFjY291bnQnO1xuICBpZiAodi50b3BRdWVzdGlvbiAmJiBOQU1FRFt2LnRvcFF1ZXN0aW9uXSkgcmV0dXJuIE5BTUVEW3YudG9wUXVlc3Rpb25dO1xuICByZXR1cm4gJ3JhZ2ViYWl0Jztcbn1cblxuZnVuY3Rpb24gbWV0YVRleHQodjogVmVyZGljdCk6IHN0cmluZyB7XG4gIGNvbnN0IHBhcnRzID0gW2Ake3JlYXNvbk5hbWUodil9ICR7KHYuc2NvcmUgPz8gMCkudG9GaXhlZCgyKX1gXTtcbiAgaWYgKHYuYXV0aG9yKSBwYXJ0cy5wdXNoKGBAJHt2LmF1dGhvcn1gKTtcbiAgaWYgKHYuY291bnRyeSkgcGFydHMucHVzaChgYmFzZWQgaW4gJHt2LmNvdW50cnl9YCk7XG4gIHJldHVybiBwYXJ0cy5qb2luKCcgXHUwMEI3ICcpO1xufVxuXG5mdW5jdGlvbiByZXZlYWwoaWQ6IHN0cmluZykge1xuICByZXZlYWxlZC5hZGQoaWQpO1xuICBzY2hlZHVsZSgpO1xufVxuXG4vKiogTGFiZWwgYnV0dG9ucyBwbHVzIFwic2hvd1wiOyBhbnkgb2YgdGhlbSByZXZlYWxzIHRoZSBwb3N0LiAqL1xuZnVuY3Rpb24gYmx1ckJhcihpZDogc3RyaW5nLCB2OiBWZXJkaWN0LCB0aXRsZTogc3RyaW5nKTogSFRNTEVsZW1lbnQge1xuICBjb25zdCBiYXIgPSBzd2FsbG93KGVsKCdkaXYnLCAnYmItdWkgYmItYmFyIGJiLWJsdXJiYXInKSk7XG4gIGJhci5hcHBlbmQoZWwoJ3NwYW4nLCAnYmItbWV0YScsIGAke3RpdGxlfSBcdTAwQjcgJHttZXRhVGV4dCh2KX1gKSk7XG4gIGZvciAoY29uc3QgbGFiZWwgb2YgWydyYWdlYmFpdCcsICdmaW5lJ10gYXMgY29uc3QpIHtcbiAgICBiYXIuYXBwZW5kKFxuICAgICAgYnV0dG9uKGxhYmVsID09PSAncmFnZWJhaXQnID8gJ2JhaXQnIDogbGFiZWwsICgpID0+IHtcbiAgICAgICAgc2VuZExhYmVsKGlkLCBsYWJlbCwgJ3VzZXJfYnV0dG9uJyk7XG4gICAgICAgIHJldmVhbChpZCk7XG4gICAgICB9KSxcbiAgICApO1xuICB9XG4gIGNvbnN0IHNob3cgPSBidXR0b24oJ3Nob3cnLCAoKSA9PiByZXZlYWwoaWQpKTtcbiAgc2hvdy5jbGFzc0xpc3QuYWRkKCdiYi1saW5rJyk7XG4gIGJhci5hcHBlbmQoc2hvdyk7XG4gIHJldHVybiBiYXI7XG59XG5cbnR5cGUgUXVvdGVTdGF0ZSA9ICdxYmx1cicgfCAncXBlbmRpbmcnIHwgJ25vbmUnO1xuXG4vKiogQSBiYWl0IHF1b3RlIG9ubHkgYmx1cnMgaXRzIG93biBib3ggKG5ldmVyIGhpZGRlbjogdGhlIHF1b3RpbmcgcG9zdCB1c3VhbGx5IGlzIGZpbmUpLiAqL1xuZnVuY3Rpb24gcXVvdGVTdGF0ZUZvcihxaWQ6IHN0cmluZyk6IHsgc3RhdGU6IFF1b3RlU3RhdGU7IHY/OiBWZXJkaWN0IH0ge1xuICBjb25zdCB7IHN0YXRlLCB2IH0gPSBzdGF0ZUZvcihxaWQpO1xuICBpZiAoc3RhdGUgPT09ICdoaWRlJyB8fCBzdGF0ZSA9PT0gJ2JsdXInKSByZXR1cm4geyBzdGF0ZTogJ3FibHVyJywgdiB9O1xuICByZXR1cm4geyBzdGF0ZTogc3RhdGUgPT09ICdwZW5kaW5nJyA/ICdxcGVuZGluZycgOiAnbm9uZScsIHYgfTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyUXVvdGUoYXJ0aWNsZTogSFRNTEVsZW1lbnQsIHFpZDogc3RyaW5nLCBzdGF0ZTogUXVvdGVTdGF0ZSwgdj86IFZlcmRpY3QpIHtcbiAgY29uc3QgYm94ID0gcXVvdGVCb3goYXJ0aWNsZSk7XG4gIGlmICghYm94IHx8IHN0YXRlID09PSAnbm9uZScpIHJldHVybjtcbiAgaWYgKHN0YXRlID09PSAncXBlbmRpbmcnKSByZXR1cm4gYm94LmNsYXNzTGlzdC5hZGQoJ2JiLXFwZW5kaW5nJyk7XG4gIGJveC5jbGFzc0xpc3QuYWRkKCdiYi1xYmx1cicpO1xuICBjb25zdCBiYXIgPSBibHVyQmFyKHFpZCwgdiEsICdRdW90ZWQgcG9zdCBibHVycmVkJyk7XG4gIGJhci5jbGFzc0xpc3QuYWRkKCdiYi1xYmFyJyk7XG4gIGJveC5iZWZvcmUoYmFyKTtcbn1cblxuZnVuY3Rpb24gcmVuZGVyKGFydGljbGU6IEhUTUxFbGVtZW50LCBpZDogc3RyaW5nLCBzdGF0ZTogU3RhdGUsIHY/OiBWZXJkaWN0KSB7XG4gIGNsZWFyKGFydGljbGUpO1xuICBhcnRpY2xlLmNsYXNzTGlzdC5hZGQoYGJiLSR7c3RhdGV9YCk7XG4gIGlmIChzdGF0ZSA9PT0gJ2hpZGUnICYmIHYpIHtcbiAgICBjb25zdCBiYXIgPSBzd2FsbG93KGVsKCdkaXYnLCAnYmItdWkgYmItYmFyJykpO1xuICAgIGJhci5hcHBlbmQoZWwoJ3NwYW4nLCAnYmItbWV0YScsIGBIaWRkZW4gXHUwMEI3ICR7bWV0YVRleHQodil9YCkpO1xuICAgIGJhci5hcHBlbmQoXG4gICAgICBidXR0b24oJ3Nob3cnLCAoKSA9PiB7XG4gICAgICAgIHNlbmRMYWJlbChpZCwgJ2ZpbmUnLCAnc2hvd19jbGljaycpO1xuICAgICAgICByZXZlYWwoaWQpO1xuICAgICAgfSksXG4gICAgKTtcbiAgICBhcnRpY2xlLnByZXBlbmQoYmFyKTtcbiAgfSBlbHNlIGlmIChzdGF0ZSA9PT0gJ2JsdXInICYmIHYpIHtcbiAgICAvLyBDb250cm9scyBzaXQgaW4gdGhlaXIgb3duIGJhciBhYm92ZSB0aGUgcG9zdCBzbyB0aGV5IG5ldmVyIGNvdmVyIHRoZSB0ZXh0OyBob3ZlcmluZyB0aGUgcG9zdCBwZWVrcy5cbiAgICBhcnRpY2xlLnByZXBlbmQoYmx1ckJhcihpZCwgdiwgJ0JsdXJyZWQnKSk7XG4gIH0gZWxzZSBpZiAoc3RhdGUgPT09ICdzaG93JyAmJiBzZXR0aW5ncz8uZW5hYmxlZC5mbGFnICE9PSBmYWxzZSkge1xuICAgIGNvbnN0IGZsYWcgPSBzd2FsbG93KGVsKCdkaXYnLCAnYmItdWkgYmItZmxhZycpKTtcbiAgICBjb25zdCB0b2dnbGUgPSBidXR0b24oJ1x1MjY5MScsICgpID0+IGZsYWcuY2xhc3NMaXN0LnRvZ2dsZSgnYmItb3BlbicpKTtcbiAgICB0b2dnbGUudGl0bGUgPSAnTGFiZWwgdGhpcyBwb3N0JztcbiAgICBjb25zdCBtZW51ID0gZWwoJ2RpdicsICdiYi1tZW51Jyk7XG4gICAgZm9yIChjb25zdCBsYWJlbCBvZiBbJ3JhZ2ViYWl0J10gYXMgY29uc3QpIHtcbiAgICAgIG1lbnUuYXBwZW5kKFxuICAgICAgICBidXR0b24oJ2JhaXQnLCAoKSA9PiB7XG4gICAgICAgICAgc2VuZExhYmVsKGlkLCBsYWJlbCwgJ3VzZXJfYnV0dG9uJyk7XG4gICAgICAgICAgZmxhZy5jbGFzc0xpc3QucmVtb3ZlKCdiYi1vcGVuJyk7XG4gICAgICAgICAgZmxhZy5jbGFzc0xpc3QuYWRkKCdiYi1kb25lJyk7XG4gICAgICAgICAgdG9nZ2xlLnRleHRDb250ZW50ID0gJ1x1MjcxMyc7XG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICB9XG4gICAgZmxhZy5hcHBlbmQodG9nZ2xlLCBtZW51KTtcbiAgICBhcnRpY2xlLnByZXBlbmQoZmxhZyk7XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFzcygpIHtcbiAgZm9yIChjb25zdCBhcnRpY2xlIG9mIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KCdhcnRpY2xlW2RhdGEtdGVzdGlkPVwidHdlZXRcIl0nKSkge1xuICAgIGNvbnN0IGlkID0gcG9zdElkT2YoYXJ0aWNsZSk7XG4gICAgaWYgKCFpZCkge1xuICAgICAgaWYgKHJlbmRlcmVkLmhhcyhhcnRpY2xlKSkge1xuICAgICAgICBjbGVhcihhcnRpY2xlKTtcbiAgICAgICAgcmVuZGVyZWQuZGVsZXRlKGFydGljbGUpO1xuICAgICAgfVxuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmICghdmVyZGljdHMuaGFzKGlkKSkgZW5zdXJlUG9zdChhcnRpY2xlLCBpZCk7XG4gICAgY29uc3QgeyBzdGF0ZSwgdiB9ID0gc3RhdGVGb3IoaWQpO1xuICAgIC8vIFRoZSBxdW90ZSBvbmx5IG1hdHRlcnMgd2hlbiB0aGUgcXVvdGluZyBwb3N0IGl0c2VsZiBpcyBzaG93bi5cbiAgICBjb25zdCBxaWQgPSBzdGF0ZSA9PT0gJ3Nob3cnID8gcG9zdHMuZ2V0KGlkKT8ucXVvdGVkSWQgOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgcSA9IHFpZCA/IHF1b3RlU3RhdGVGb3IocWlkKSA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBrZXkgPSBgJHtpZH06JHtzdGF0ZX06JHtxPy5zdGF0ZSA/PyAnJ31gO1xuICAgIC8vIFJlY3ljbGVkIGVsZW1lbnRzIGdldCBhIG5ldyBpZCwgc28gdGhlIGtleSBjaGFuZ2VzIGFuZCBzdGFsZSBVSSBpcyBjbGVhcmVkIGJlZm9yZSByZS1yZW5kZXJpbmcuXG4gICAgY29uc3QgbmVlZHNVaSA9IHN0YXRlID09PSAnaGlkZScgfHwgc3RhdGUgPT09ICdibHVyJyB8fCAoc3RhdGUgPT09ICdzaG93JyAmJiBzZXR0aW5ncz8uZW5hYmxlZC5mbGFnICE9PSBmYWxzZSk7XG4gICAgY29uc3QgcXVvdGVPayA9IHE/LnN0YXRlICE9PSAncWJsdXInIHx8ICEhYXJ0aWNsZS5xdWVyeVNlbGVjdG9yKCcuYmItcWJhcicpIHx8ICFxdW90ZUJveChhcnRpY2xlKTtcbiAgICBpZiAocmVuZGVyZWQuZ2V0KGFydGljbGUpID09PSBrZXkgJiYgKCFuZWVkc1VpIHx8IGFydGljbGUucXVlcnlTZWxlY3RvcignOnNjb3BlID4gLmJiLXVpJykpICYmIHF1b3RlT2spIGNvbnRpbnVlO1xuICAgIHJlbmRlcihhcnRpY2xlLCBpZCwgc3RhdGUsIHYpO1xuICAgIGlmIChxaWQgJiYgcSkgcmVuZGVyUXVvdGUoYXJ0aWNsZSwgcWlkLCBxLnN0YXRlLCBxLnYpO1xuICAgIHJlbmRlcmVkLnNldChhcnRpY2xlLCBrZXkpO1xuICB9XG59XG5cbmxldCBzY2hlZHVsZWQgPSBmYWxzZTtcbmZ1bmN0aW9uIHNjaGVkdWxlKCkge1xuICBpZiAoc2NoZWR1bGVkKSByZXR1cm47XG4gIHNjaGVkdWxlZCA9IHRydWU7XG4gIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgc2NoZWR1bGVkID0gZmFsc2U7XG4gICAgcGFzcygpO1xuICB9KTtcbn1cblxuLy8gLS0tLS0tLS0tLSBzdHlsZXMgJiBib290IC0tLS0tLS0tLS1cblxuY29uc3QgQ1NTID0gYFxuYXJ0aWNsZS5iYi1wZW5kaW5nIHsgb3BhY2l0eTogLjU7IH1cbmFydGljbGUuYmItaGlkZSwgYXJ0aWNsZS5iYi1ibHVyLCBhcnRpY2xlLmJiLXNob3cgeyBwb3NpdGlvbjogcmVsYXRpdmU7IH1cbmFydGljbGUuYmItaGlkZSA+IDpub3QoLmJiLXVpKSB7IGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDsgfVxuYXJ0aWNsZS5iYi1ibHVyID4gOm5vdCguYmItdWkpIHsgZmlsdGVyOiBibHVyKDEycHgpOyBwb2ludGVyLWV2ZW50czogbm9uZTsgdXNlci1zZWxlY3Q6IG5vbmU7IHRyYW5zaXRpb246IGZpbHRlciAuMTVzOyB9XG5hcnRpY2xlLmJiLWJsdXI6aG92ZXIgPiA6bm90KC5iYi11aSkgeyBmaWx0ZXI6IG5vbmU7IHRyYW5zaXRpb24tZGVsYXk6IC40czsgfVxuLmJiLXVpIHsgZm9udDogMTNweC8xLjMgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIHNhbnMtc2VyaWY7IGNvbG9yOiByZ2IoMTEzLDExOCwxMjMpOyB9XG4uYmItYmFyIHsgZGlzcGxheTogZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsgZ2FwOiA4cHg7IHBhZGRpbmc6IDhweCAxNnB4OyB9XG4uYmItYmFyIC5iYi1tZXRhIHsgZmxleDogMTsgb3ZlcmZsb3c6IGhpZGRlbjsgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7IHdoaXRlLXNwYWNlOiBub3dyYXA7IH1cbi5iYi1idG4geyBmb250OiBpbmhlcml0OyBjdXJzb3I6IHBvaW50ZXI7IGJvcmRlcjogMXB4IHNvbGlkIHJnYig4MywxMDAsMTEzKTsgYmFja2dyb3VuZDogcmdiYSgwLDAsMCwuNjUpOyBjb2xvcjogI2U3ZTllYTsgYm9yZGVyLXJhZGl1czogOTk5cHg7IHBhZGRpbmc6IDNweCAxMnB4OyB9XG4uYmItYnRuOmhvdmVyIHsgYmFja2dyb3VuZDogcmdiYSgyOSwxNTUsMjQwLC44NSk7IGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7IH1cbi5iYi1ibHVyYmFyIC5iYi1idG4geyBwYWRkaW5nOiAxcHggMTBweDsgfVxuLmJiLWJhcjpub3QoLmJiLWJsdXJiYXIpIC5iYi1idG4sIC5iYi1iYXIgLmJiLWJ0bi5iYi1saW5rIHsgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IGNvbG9yOiByZ2IoMjksMTU1LDI0MCk7IGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7IHBhZGRpbmc6IDAgMCAwIDRweDsgfVxuLmJiLWZsYWcgeyBwb3NpdGlvbjogYWJzb2x1dGU7IHRvcDogMTBweDsgcmlnaHQ6IDUycHg7IHotaW5kZXg6IDI7IGRpc3BsYXk6IGZsZXg7IGdhcDogNHB4OyBvcGFjaXR5OiAwOyB0cmFuc2l0aW9uOiBvcGFjaXR5IC4xczsgfVxuYXJ0aWNsZTpob3ZlciA+IC5iYi1mbGFnLCAuYmItZmxhZy5iYi1vcGVuLCAuYmItZmxhZy5iYi1kb25lIHsgb3BhY2l0eTogMTsgfVxuLmJiLWZsYWcgPiAuYmItYnRuIHsgcGFkZGluZzogMCA2cHg7IH1cbi5iYi1xcGVuZGluZyB7IG9wYWNpdHk6IC41OyB9XG4uYmItcWJsdXIgeyBmaWx0ZXI6IGJsdXIoMTBweCk7IHBvaW50ZXItZXZlbnRzOiBub25lOyB1c2VyLXNlbGVjdDogbm9uZTsgfVxuLmJiLXFiYXIgeyBwYWRkaW5nOiA2cHggMDsgfVxuLmJiLW1lbnUgeyBkaXNwbGF5OiBub25lOyBnYXA6IDRweDsgfVxuLmJiLWZsYWcuYmItb3BlbiAuYmItbWVudSB7IGRpc3BsYXk6IGZsZXg7IH1cbmA7XG5cbmZ1bmN0aW9uIGJvb3QoKSB7XG4gIGNvbnN0IHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcbiAgc3R5bGUudGV4dENvbnRlbnQgPSBDU1M7XG4gIChkb2N1bWVudC5oZWFkID8/IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkuYXBwZW5kKHN0eWxlKTtcbiAgbmV3IE11dGF0aW9uT2JzZXJ2ZXIoc2NoZWR1bGUpLm9ic2VydmUoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcbiAgc2NoZWR1bGUoKTtcbn1cblxucmVmcmVzaFNldHRpbmdzKCk7XG5ib290KCk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFnQ08sTUFBTSxhQUFhO0FBQ25CLE1BQU0sYUFBYTtBQUduQixXQUFTLGdCQUFnQixLQUFpQztBQUMvRCxVQUFNLElBQUksc0RBQXNELEtBQUssR0FBRztBQUN4RSxXQUFPLElBQUksK0JBQStCLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixVQUFVLEtBQUs7QUFBQSxFQUNuRjs7O0FDdkNBO0FBQUEsSUFDRSxTQUFXO0FBQUEsSUFDWCxXQUFhO0FBQUEsTUFDWDtBQUFBLFFBQ0UsSUFBTTtBQUFBLFFBQ04sTUFBUTtBQUFBLE1BQ1Y7QUFBQSxNQUNBO0FBQUEsUUFDRSxJQUFNO0FBQUEsUUFDTixNQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFNBQVc7QUFBQSxNQUNULFFBQVU7QUFBQSxRQUNSO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFVBQVksQ0FBQztBQUFBLElBQ2Y7QUFBQSxJQUNBLFlBQWM7QUFBQSxNQUNaLE1BQVE7QUFBQSxNQUNSLE1BQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxRQUFVO0FBQUEsTUFDUixJQUFNO0FBQUEsTUFDTixNQUFRO0FBQUEsTUFDUixXQUFhO0FBQUEsSUFDZjtBQUFBLEVBQ0Y7OztBQ3pCTyxNQUFNLFlBQVk7QUFFbEIsTUFBTSxtQkFBNkI7QUFBQSxJQUN4QyxRQUFRO0FBQUEsSUFDUixPQUFPO0FBQUEsSUFDUCxZQUFZLEVBQUUsR0FBRyxVQUFVLFdBQVc7QUFBQSxJQUN0QyxTQUFTLEVBQUUsU0FBUyxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLO0FBQUEsSUFDN0Qsa0JBQWtCO0FBQUEsSUFDbEIsaUJBQWlCO0FBQUEsSUFDakIsa0JBQWtCLENBQUMsaUJBQWlCLGVBQWU7QUFBQSxJQUNuRCxhQUFhO0FBQUEsRUFDZjtBQUVBLGlCQUFzQixlQUFrQztBQUN0RCxVQUFNLEVBQUUsVUFBQUEsVUFBUyxJQUFJLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxVQUFVO0FBQzlELFVBQU0sSUFBS0EsYUFBWSxDQUFDO0FBRXhCLFVBQU0sUUFBUSxFQUFFLGtCQUFrQixVQUFVLFVBQVUsRUFBRSxhQUFhO0FBQ3JFLFdBQU87QUFBQSxNQUNMLEdBQUc7QUFBQSxNQUNILEdBQUc7QUFBQSxNQUNILFlBQVksRUFBRSxHQUFHLGlCQUFpQixZQUFZLEdBQUcsTUFBTTtBQUFBLE1BQ3ZELFNBQVMsRUFBRSxHQUFHLGlCQUFpQixTQUFTLEdBQUcsRUFBRSxRQUFRO0FBQUEsSUFDdkQ7QUFBQSxFQUNGOzs7QUNnR08sTUFBTSxTQUFTOzs7QUNySHRCLE1BQU0sUUFBUSxvQkFBSSxJQUFrQjtBQUNwQyxNQUFNLFdBQVcsb0JBQUksSUFBcUI7QUFDMUMsTUFBTSxZQUFZLG9CQUFJLElBQVk7QUFDbEMsTUFBTSxXQUFXLG9CQUFJLElBQVk7QUFDakMsTUFBTSxpQkFBaUIsb0JBQUksSUFBMkM7QUFDdEUsTUFBSTtBQUVKLE1BQU0sb0JBQW9CO0FBRTFCLE1BQU0sUUFBZ0M7QUFBQSxJQUNwQyxhQUFhO0FBQUEsSUFDYixlQUFlO0FBQUEsSUFDZixnQkFBZ0I7QUFBQSxFQUNsQjtBQUVBLE1BQU0saUJBQWlCLG9CQUFJLElBQXlCO0FBSXBELFdBQVMsZUFBZSxNQUFZO0FBQ2xDLFFBQUksVUFBVSxJQUFJLEtBQUssRUFBRSxFQUFHO0FBQzVCLGNBQVUsSUFBSSxLQUFLLEVBQUU7QUFDckIsV0FBTyxRQUNKLFlBQVksRUFBRSxNQUFNLFNBQVMsS0FBSyxDQUFDLEVBQ25DLEtBQUssQ0FBQyxNQUEyQjtBQUNoQyxVQUFJLEdBQUcsYUFBYyxRQUFPLGFBQWEsS0FBSyxJQUFJLEVBQUUsWUFBWTtBQUNoRSxlQUFTLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxRQUFRLEtBQUssSUFBSSxVQUFVLFlBQVksUUFBUSxRQUFRLENBQUM7QUFDckYsbUJBQWEsS0FBSyxFQUFFO0FBQ3BCLGVBQVM7QUFBQSxJQUNYLENBQUMsRUFDQSxNQUFNLE1BQU07QUFFWCxlQUFTLElBQUksS0FBSyxJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUksVUFBVSxZQUFZLFFBQVEsUUFBUSxDQUFDO0FBQ2hGLGVBQVM7QUFBQSxJQUNYLENBQUM7QUFBQSxFQUNMO0FBR0EsV0FBUyxhQUFhLFVBQWtCO0FBQ3RDLGVBQVcsS0FBSyxNQUFNLE9BQU8sR0FBRztBQUM5QixVQUFJLEVBQUUsYUFBYSxZQUFZLENBQUMsU0FBUyxJQUFJLEVBQUUsRUFBRSxFQUFHO0FBQ3BELGdCQUFVLE9BQU8sRUFBRSxFQUFFO0FBQ3JCLHFCQUFlLENBQUM7QUFBQSxJQUNsQjtBQUFBLEVBQ0Y7QUFHQSxXQUFTLGFBQWEsUUFBZ0IsUUFBZ0I7QUFDcEQsUUFBSSxVQUFVLGVBQWUsSUFBSSxNQUFNO0FBQ3ZDLFFBQUksQ0FBQyxTQUFTO0FBQ1oscUJBQWUsSUFBSSxRQUFTLFVBQVUsb0JBQUksSUFBSSxDQUFFO0FBQ2hELGFBQU8sWUFBWSxFQUFFLElBQUksUUFBUSxNQUFNLGlCQUFpQixPQUFPLEdBQUcsU0FBUyxNQUFNO0FBQUEsSUFDbkY7QUFDQSxZQUFRLElBQUksTUFBTTtBQUFBLEVBQ3BCO0FBRUEsaUJBQWUsZ0JBQWdCLFFBQWdCLFFBQXNCO0FBQ25FLFVBQU0sVUFBVSxlQUFlLElBQUksTUFBTSxLQUFLLG9CQUFJLElBQVk7QUFDOUQsbUJBQWUsT0FBTyxNQUFNO0FBQzVCLFFBQUksT0FBTyxJQUFJO0FBQ2IsWUFBTSxPQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sV0FBVyxRQUFRLE1BQU0sT0FBTyxLQUFLLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxNQUFDLENBQUM7QUFDL0YsaUJBQVcsTUFBTSxTQUFTO0FBQ3hCLGtCQUFVLE9BQU8sRUFBRTtBQUNuQixjQUFNLElBQUksTUFBTSxJQUFJLEVBQUU7QUFDdEIsWUFBSSxFQUFHLGdCQUFlLENBQUM7QUFBQSxNQUN6QjtBQUFBLElBQ0YsT0FBTztBQUNMLGNBQVEsTUFBTSx1Q0FBdUMsUUFBUSxPQUFPLEtBQUs7QUFDekUsVUFBSSxPQUFPLFVBQVUsY0FBZSxTQUFRLEtBQUssOEdBQWdIO0FBQ2pLLGlCQUFXLE1BQU0sUUFBUyxVQUFTLElBQUksSUFBSSxFQUFFLFFBQVEsSUFBSSxVQUFVLFlBQVksUUFBUSxRQUFRLENBQUM7QUFBQSxJQUNsRztBQUNBLGFBQVM7QUFBQSxFQUNYO0FBRUEsV0FBUyxVQUFVLFFBQWdCLE9BQW1CLFFBQXNDO0FBQzFGLFdBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxTQUFTLE9BQU8sRUFBRSxRQUFRLE9BQU8sT0FBTyxFQUFFLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFBQSxFQUNoRztBQUVBLFNBQU8saUJBQWlCLFdBQVcsQ0FBQyxNQUFNO0FBQ3hDLFFBQUksRUFBRSxXQUFXLFVBQVUsRUFBRSxNQUFNLE9BQU8sT0FBUTtBQUNsRCxRQUFJLEVBQUUsS0FBSyxTQUFTLFNBQVM7QUFDM0IsaUJBQVcsS0FBSyxFQUFFLEtBQUssT0FBaUI7QUFDdEMsWUFBSSxDQUFDLE1BQU0sSUFBSSxFQUFFLEVBQUUsRUFBRyxPQUFNLElBQUksRUFBRSxJQUFJLENBQUM7QUFDdkMsdUJBQWUsQ0FBQztBQUFBLE1BQ2xCO0FBQ0EsZUFBUztBQUFBLElBQ1gsV0FBVyxFQUFFLEtBQUssU0FBUyxtQkFBbUIsT0FBTyxFQUFFLEtBQUssV0FBVyxVQUFVO0FBQy9FLHNCQUFnQixFQUFFLEtBQUssUUFBUSxFQUFFLEtBQUssTUFBc0I7QUFBQSxJQUM5RCxXQUFXLEVBQUUsS0FBSyxTQUFTLFdBQVc7QUFDcEMsYUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLFdBQVcsS0FBSyxFQUFFLEtBQUssS0FBSyxNQUFNLEVBQUUsS0FBSyxLQUFLLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxNQUFDLENBQUM7QUFBQSxJQUNwRztBQUFBLEVBQ0YsQ0FBQztBQUVELGlCQUFlLGtCQUFrQjtBQUMvQixlQUFXLE1BQU0sYUFBYTtBQUM5QixXQUFPLFlBQVksRUFBRSxJQUFJLFFBQVEsTUFBTSxVQUFVLFNBQVMsU0FBUyxnQkFBZ0IsR0FBRyxTQUFTLE1BQU07QUFBQSxFQUN2RztBQUVBLFNBQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxZQUFZO0FBQ2hELFFBQUksQ0FBQyxRQUFRLFNBQVU7QUFDdkIsb0JBQWdCLEVBQUUsS0FBSyxNQUFNO0FBRTNCLGVBQVMsTUFBTTtBQUNmLGdCQUFVLE1BQU07QUFDaEIscUJBQWUsTUFBTTtBQUNyQixpQkFBVyxLQUFLLE1BQU0sT0FBTyxFQUFHLGdCQUFlLENBQUM7QUFDaEQsZUFBUztBQUFBLElBQ1gsQ0FBQztBQUFBLEVBQ0gsQ0FBQztBQUlELFdBQVMsU0FBUyxTQUFzQztBQUN0RCxVQUFNLE9BQU8sUUFBUSxjQUFjLDBCQUEwQixHQUFHLFFBQVEsR0FBRyxLQUFLLFFBQVEsY0FBYyxxQkFBcUI7QUFDM0gsV0FBTyxrQkFBa0IsS0FBSyxNQUFNLGFBQWEsTUFBTSxLQUFLLEVBQUUsSUFBSSxDQUFDO0FBQUEsRUFDckU7QUFFQSxXQUFTLFdBQVcsU0FBa0IsSUFBOEI7QUFDbEUsVUFBTSxRQUFRLFFBQVEsaUJBQThCLDJCQUEyQjtBQUMvRSxVQUFNLFVBQVUsQ0FBQyxHQUFHLFFBQVEsaUJBQWlCLHdDQUF3QyxDQUFDLEVBQ25GLElBQUksQ0FBQyxNQUFNLHNCQUFzQixLQUFLLEVBQUUsYUFBYSxNQUFNLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUN4RSxPQUFPLENBQUMsTUFBbUIsQ0FBQyxDQUFDLENBQUM7QUFDakMsVUFBTSxPQUFPLE1BQU0sQ0FBQyxHQUFHLGFBQWE7QUFDcEMsVUFBTSxTQUFTLENBQUMsR0FBRyxRQUFRLGlCQUFtQyxnQ0FBZ0MsQ0FBQyxFQUM1RixJQUFJLENBQUMsTUFBTSxnQkFBZ0IsRUFBRSxHQUFHLENBQUMsRUFDakMsT0FBTyxDQUFDLE1BQW1CLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLFFBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxVQUFVLENBQUMsT0FBTyxPQUFRLFFBQU87QUFDdkQsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBO0FBQUEsTUFDQSxRQUFRLFFBQVEsQ0FBQztBQUFBLE1BQ2pCLFlBQVksTUFBTSxDQUFDLEdBQUc7QUFBQSxNQUN0QixjQUFjLFFBQVEsQ0FBQztBQUFBLE1BQ3ZCLFdBQVcsT0FBTyxTQUFTLENBQUMsR0FBRyxJQUFJLElBQUksTUFBTSxDQUFDLEVBQUUsTUFBTSxHQUFHLFVBQVUsSUFBSTtBQUFBLE1BQ3ZFLFNBQVM7QUFBQSxNQUNULFFBQVE7QUFBQSxJQUNWO0FBQUEsRUFDRjtBQUVBLFdBQVMsV0FBVyxTQUFrQixJQUFZO0FBQ2hELFFBQUksTUFBTSxJQUFJLEVBQUUsS0FBSyxVQUFVLElBQUksRUFBRSxLQUFLLGVBQWUsSUFBSSxFQUFFLEVBQUc7QUFDbEUsbUJBQWU7QUFBQSxNQUNiO0FBQUEsTUFDQSxXQUFXLE1BQU07QUFDZix1QkFBZSxPQUFPLEVBQUU7QUFDeEIsWUFBSSxNQUFNLElBQUksRUFBRSxLQUFLLFVBQVUsSUFBSSxFQUFFLEtBQUssQ0FBQyxRQUFRLGVBQWUsU0FBUyxPQUFPLE1BQU0sR0FBSTtBQUM1RixjQUFNLElBQUksV0FBVyxTQUFTLEVBQUU7QUFDaEMsWUFBSSxDQUFDLEVBQUc7QUFDUixjQUFNLElBQUksSUFBSSxDQUFDO0FBQ2YsdUJBQWUsQ0FBQztBQUFBLE1BQ2xCLEdBQUcsaUJBQWlCO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBS0EsTUFBTSxXQUFXLG9CQUFJLFFBQXlCO0FBRTlDLFdBQVMsU0FBUyxJQUEyQztBQUMzRCxVQUFNLElBQUksU0FBUyxJQUFJLEVBQUU7QUFDekIsVUFBTSxLQUFLLFVBQVU7QUFDckIsUUFBSSxDQUFDLEVBQUcsUUFBTyxFQUFFLE9BQU8sSUFBSSxZQUFZLFFBQVEsU0FBUyxVQUFVO0FBQ25FLFFBQUksU0FBUyxJQUFJLEVBQUUsS0FBSyxFQUFFLGFBQWEsV0FBWSxRQUFPLEVBQUUsT0FBTyxRQUFRLEVBQUU7QUFDN0UsUUFBSSxJQUFXLEVBQUU7QUFDakIsUUFBSSxNQUFNLFVBQVUsSUFBSSxTQUFTLE1BQU8sS0FBSTtBQUM1QyxRQUFJLE1BQU0sVUFBVSxJQUFJLFNBQVMsTUFBTyxLQUFJO0FBQzVDLFdBQU8sRUFBRSxPQUFPLEdBQUcsRUFBRTtBQUFBLEVBQ3ZCO0FBRUEsV0FBUyxNQUFNLFNBQXNCO0FBQ25DLFlBQVEsVUFBVSxPQUFPLGNBQWMsV0FBVyxXQUFXLFNBQVM7QUFDdEUsWUFBUSxpQkFBaUIsMkJBQTJCLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUM7QUFDL0UsWUFBUSxpQkFBaUIseUJBQXlCLEVBQUUsUUFBUSxDQUFDLE1BQU0sRUFBRSxVQUFVLE9BQU8sWUFBWSxhQUFhLENBQUM7QUFBQSxFQUNsSDtBQUdBLFdBQVMsU0FBUyxTQUErQztBQUMvRCxVQUFNLE1BQU0sUUFBUSxpQkFBaUIsMkJBQTJCLEVBQUUsQ0FBQyxHQUFHLFFBQXFCLGtCQUFrQjtBQUM3RyxXQUFPLE9BQU8sUUFBUSxTQUFTLEdBQUcsSUFBSSxNQUFNO0FBQUEsRUFDOUM7QUFFQSxXQUFTLEdBQTBDLEtBQVEsS0FBYSxNQUF5QztBQUMvRyxVQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7QUFDcEMsTUFBRSxZQUFZO0FBQ2QsUUFBSSxLQUFNLEdBQUUsY0FBYztBQUMxQixXQUFPO0FBQUEsRUFDVDtBQUVBLFdBQVMsT0FBTyxNQUFjLFNBQXdDO0FBQ3BFLFVBQU0sSUFBSSxHQUFHLFVBQVUsVUFBVSxJQUFJO0FBQ3JDLE1BQUUsT0FBTztBQUNULE1BQUUsaUJBQWlCLFNBQVMsQ0FBQyxNQUFNO0FBQ2pDLFFBQUUsZUFBZTtBQUNqQixRQUFFLGdCQUFnQjtBQUNsQixjQUFRO0FBQUEsSUFDVixDQUFDO0FBQ0QsV0FBTztBQUFBLEVBQ1Q7QUFHQSxXQUFTLFFBQVEsR0FBZ0I7QUFDL0IsTUFBRSxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDakMsUUFBRSxnQkFBZ0I7QUFBQSxJQUNwQixDQUFDO0FBQ0QsV0FBTztBQUFBLEVBQ1Q7QUFFQSxXQUFTLFdBQVcsR0FBb0I7QUFDdEMsUUFBSSxFQUFFLGdCQUFnQixnQkFBaUIsUUFBTztBQUM5QyxRQUFJLEVBQUUsZUFBZSxNQUFNLEVBQUUsV0FBVyxFQUFHLFFBQU8sTUFBTSxFQUFFLFdBQVc7QUFDckUsV0FBTztBQUFBLEVBQ1Q7QUFFQSxXQUFTLFNBQVMsR0FBb0I7QUFDcEMsVUFBTSxRQUFRLENBQUMsR0FBRyxXQUFXLENBQUMsQ0FBQyxLQUFLLEVBQUUsU0FBUyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQUU7QUFDOUQsUUFBSSxFQUFFLE9BQVEsT0FBTSxLQUFLLElBQUksRUFBRSxNQUFNLEVBQUU7QUFDdkMsUUFBSSxFQUFFLFFBQVMsT0FBTSxLQUFLLFlBQVksRUFBRSxPQUFPLEVBQUU7QUFDakQsV0FBTyxNQUFNLEtBQUssUUFBSztBQUFBLEVBQ3pCO0FBRUEsV0FBUyxPQUFPLElBQVk7QUFDMUIsYUFBUyxJQUFJLEVBQUU7QUFDZixhQUFTO0FBQUEsRUFDWDtBQUdBLFdBQVMsUUFBUSxJQUFZLEdBQVksT0FBNEI7QUFDbkUsVUFBTSxNQUFNLFFBQVEsR0FBRyxPQUFPLHlCQUF5QixDQUFDO0FBQ3hELFFBQUksT0FBTyxHQUFHLFFBQVEsV0FBVyxHQUFHLEtBQUssU0FBTSxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDN0QsZUFBVyxTQUFTLENBQUMsWUFBWSxNQUFNLEdBQVk7QUFDakQsVUFBSTtBQUFBLFFBQ0YsT0FBTyxVQUFVLGFBQWEsU0FBUyxPQUFPLE1BQU07QUFDbEQsb0JBQVUsSUFBSSxPQUFPLGFBQWE7QUFDbEMsaUJBQU8sRUFBRTtBQUFBLFFBQ1gsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQ0EsVUFBTSxPQUFPLE9BQU8sUUFBUSxNQUFNLE9BQU8sRUFBRSxDQUFDO0FBQzVDLFNBQUssVUFBVSxJQUFJLFNBQVM7QUFDNUIsUUFBSSxPQUFPLElBQUk7QUFDZixXQUFPO0FBQUEsRUFDVDtBQUtBLFdBQVMsY0FBYyxLQUFpRDtBQUN0RSxVQUFNLEVBQUUsT0FBTyxFQUFFLElBQUksU0FBUyxHQUFHO0FBQ2pDLFFBQUksVUFBVSxVQUFVLFVBQVUsT0FBUSxRQUFPLEVBQUUsT0FBTyxTQUFTLEVBQUU7QUFDckUsV0FBTyxFQUFFLE9BQU8sVUFBVSxZQUFZLGFBQWEsUUFBUSxFQUFFO0FBQUEsRUFDL0Q7QUFFQSxXQUFTLFlBQVksU0FBc0IsS0FBYSxPQUFtQixHQUFhO0FBQ3RGLFVBQU0sTUFBTSxTQUFTLE9BQU87QUFDNUIsUUFBSSxDQUFDLE9BQU8sVUFBVSxPQUFRO0FBQzlCLFFBQUksVUFBVSxXQUFZLFFBQU8sSUFBSSxVQUFVLElBQUksYUFBYTtBQUNoRSxRQUFJLFVBQVUsSUFBSSxVQUFVO0FBQzVCLFVBQU0sTUFBTSxRQUFRLEtBQUssR0FBSSxxQkFBcUI7QUFDbEQsUUFBSSxVQUFVLElBQUksU0FBUztBQUMzQixRQUFJLE9BQU8sR0FBRztBQUFBLEVBQ2hCO0FBRUEsV0FBUyxPQUFPLFNBQXNCLElBQVksT0FBYyxHQUFhO0FBQzNFLFVBQU0sT0FBTztBQUNiLFlBQVEsVUFBVSxJQUFJLE1BQU0sS0FBSyxFQUFFO0FBQ25DLFFBQUksVUFBVSxVQUFVLEdBQUc7QUFDekIsWUFBTSxNQUFNLFFBQVEsR0FBRyxPQUFPLGNBQWMsQ0FBQztBQUM3QyxVQUFJLE9BQU8sR0FBRyxRQUFRLFdBQVcsZUFBWSxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDM0QsVUFBSTtBQUFBLFFBQ0YsT0FBTyxRQUFRLE1BQU07QUFDbkIsb0JBQVUsSUFBSSxRQUFRLFlBQVk7QUFDbEMsaUJBQU8sRUFBRTtBQUFBLFFBQ1gsQ0FBQztBQUFBLE1BQ0g7QUFDQSxjQUFRLFFBQVEsR0FBRztBQUFBLElBQ3JCLFdBQVcsVUFBVSxVQUFVLEdBQUc7QUFFaEMsY0FBUSxRQUFRLFFBQVEsSUFBSSxHQUFHLFNBQVMsQ0FBQztBQUFBLElBQzNDLFdBQVcsVUFBVSxVQUFVLFVBQVUsUUFBUSxTQUFTLE9BQU87QUFDL0QsWUFBTSxPQUFPLFFBQVEsR0FBRyxPQUFPLGVBQWUsQ0FBQztBQUMvQyxZQUFNLFNBQVMsT0FBTyxVQUFLLE1BQU0sS0FBSyxVQUFVLE9BQU8sU0FBUyxDQUFDO0FBQ2pFLGFBQU8sUUFBUTtBQUNmLFlBQU0sT0FBTyxHQUFHLE9BQU8sU0FBUztBQUNoQyxpQkFBVyxTQUFTLENBQUMsVUFBVSxHQUFZO0FBQ3pDLGFBQUs7QUFBQSxVQUNILE9BQU8sUUFBUSxNQUFNO0FBQ25CLHNCQUFVLElBQUksT0FBTyxhQUFhO0FBQ2xDLGlCQUFLLFVBQVUsT0FBTyxTQUFTO0FBQy9CLGlCQUFLLFVBQVUsSUFBSSxTQUFTO0FBQzVCLG1CQUFPLGNBQWM7QUFBQSxVQUN2QixDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFDQSxXQUFLLE9BQU8sUUFBUSxJQUFJO0FBQ3hCLGNBQVEsUUFBUSxJQUFJO0FBQUEsSUFDdEI7QUFBQSxFQUNGO0FBRUEsV0FBUyxPQUFPO0FBQ2QsZUFBVyxXQUFXLFNBQVMsaUJBQThCLDhCQUE4QixHQUFHO0FBQzVGLFlBQU0sS0FBSyxTQUFTLE9BQU87QUFDM0IsVUFBSSxDQUFDLElBQUk7QUFDUCxZQUFJLFNBQVMsSUFBSSxPQUFPLEdBQUc7QUFDekIsZ0JBQU0sT0FBTztBQUNiLG1CQUFTLE9BQU8sT0FBTztBQUFBLFFBQ3pCO0FBQ0E7QUFBQSxNQUNGO0FBQ0EsVUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLEVBQUcsWUFBVyxTQUFTLEVBQUU7QUFDN0MsWUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLFNBQVMsRUFBRTtBQUVoQyxZQUFNLE1BQU0sVUFBVSxTQUFTLE1BQU0sSUFBSSxFQUFFLEdBQUcsV0FBVztBQUN6RCxZQUFNLElBQUksTUFBTSxjQUFjLEdBQUcsSUFBSTtBQUNyQyxZQUFNLE1BQU0sR0FBRyxFQUFFLElBQUksS0FBSyxJQUFJLEdBQUcsU0FBUyxFQUFFO0FBRTVDLFlBQU0sVUFBVSxVQUFVLFVBQVUsVUFBVSxVQUFXLFVBQVUsVUFBVSxVQUFVLFFBQVEsU0FBUztBQUN4RyxZQUFNLFVBQVUsR0FBRyxVQUFVLFdBQVcsQ0FBQyxDQUFDLFFBQVEsY0FBYyxVQUFVLEtBQUssQ0FBQyxTQUFTLE9BQU87QUFDaEcsVUFBSSxTQUFTLElBQUksT0FBTyxNQUFNLFFBQVEsQ0FBQyxXQUFXLFFBQVEsY0FBYyxpQkFBaUIsTUFBTSxRQUFTO0FBQ3hHLGFBQU8sU0FBUyxJQUFJLE9BQU8sQ0FBQztBQUM1QixVQUFJLE9BQU8sRUFBRyxhQUFZLFNBQVMsS0FBSyxFQUFFLE9BQU8sRUFBRSxDQUFDO0FBQ3BELGVBQVMsSUFBSSxTQUFTLEdBQUc7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFFQSxNQUFJLFlBQVk7QUFDaEIsV0FBUyxXQUFXO0FBQ2xCLFFBQUksVUFBVztBQUNmLGdCQUFZO0FBQ1osMEJBQXNCLE1BQU07QUFDMUIsa0JBQVk7QUFDWixXQUFLO0FBQUEsSUFDUCxDQUFDO0FBQUEsRUFDSDtBQUlBLE1BQU0sTUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXVCWixXQUFTLE9BQU87QUFDZCxVQUFNLFFBQVEsU0FBUyxjQUFjLE9BQU87QUFDNUMsVUFBTSxjQUFjO0FBQ3BCLEtBQUMsU0FBUyxRQUFRLFNBQVMsaUJBQWlCLE9BQU8sS0FBSztBQUN4RCxRQUFJLGlCQUFpQixRQUFRLEVBQUUsUUFBUSxTQUFTLGlCQUFpQixFQUFFLFdBQVcsTUFBTSxTQUFTLEtBQUssQ0FBQztBQUNuRyxhQUFTO0FBQUEsRUFDWDtBQUVBLGtCQUFnQjtBQUNoQixPQUFLOyIsCiAgIm5hbWVzIjogWyJzZXR0aW5ncyJdCn0K
