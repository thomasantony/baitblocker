"use strict";
(() => {
  // node_modules/idb/build/index.js
  var instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
  var idbProxyableTypes;
  var cursorAdvanceMethods;
  function getIdbProxyableTypes() {
    return idbProxyableTypes || (idbProxyableTypes = [
      IDBIndex,
      IDBObjectStore,
      IDBCursor,
      IDBDatabase,
      IDBTransaction
    ]);
  }
  function getCursorAdvanceMethods() {
    return cursorAdvanceMethods || (cursorAdvanceMethods = ["advance", "continue", "continuePrimaryKey"].map((method) => IDBCursor.prototype[method]));
  }
  var transactionDoneMap = /* @__PURE__ */ new WeakMap();
  var transformCache = /* @__PURE__ */ new WeakMap();
  var reverseTransformCache = /* @__PURE__ */ new WeakMap();
  function promisifyRequest(request) {
    const promise = new Promise((resolve, reject) => {
      const unlisten = () => {
        request.removeEventListener("success", success);
        request.removeEventListener("error", error);
      };
      const success = () => {
        resolve(wrap(request.result));
        unlisten();
      };
      const error = () => {
        reject(request.error);
        unlisten();
      };
      request.addEventListener("success", success);
      request.addEventListener("error", error);
    });
    reverseTransformCache.set(promise, request);
    return promise;
  }
  function cacheDonePromiseForTransaction(tx) {
    if (transactionDoneMap.has(tx))
      return;
    const done = new Promise((resolve, reject) => {
      const unlisten = () => {
        tx.removeEventListener("complete", complete);
        tx.removeEventListener("error", error);
        tx.removeEventListener("abort", error);
      };
      const complete = () => {
        resolve();
        unlisten();
      };
      const error = () => {
        reject(tx.error || new DOMException("AbortError", "AbortError"));
        unlisten();
      };
      tx.addEventListener("complete", complete);
      tx.addEventListener("error", error);
      tx.addEventListener("abort", error);
    });
    transactionDoneMap.set(tx, done);
  }
  var idbProxyTraps = {
    get(target, prop, receiver) {
      if (target instanceof IDBTransaction) {
        if (prop === "done")
          return transactionDoneMap.get(target);
        if (prop === "store") {
          return receiver.objectStoreNames[1] ? void 0 : receiver.objectStore(receiver.objectStoreNames[0]);
        }
      }
      return wrap(target[prop]);
    },
    set(target, prop, value) {
      target[prop] = value;
      return true;
    },
    has(target, prop) {
      if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
        return true;
      }
      return prop in target;
    }
  };
  function replaceTraps(callback) {
    idbProxyTraps = callback(idbProxyTraps);
  }
  function wrapFunction(func) {
    if (getCursorAdvanceMethods().includes(func)) {
      return function(...args) {
        func.apply(unwrap(this), args);
        return wrap(this.request);
      };
    }
    return function(...args) {
      return wrap(func.apply(unwrap(this), args));
    };
  }
  function transformCachableValue(value) {
    if (typeof value === "function")
      return wrapFunction(value);
    if (value instanceof IDBTransaction)
      cacheDonePromiseForTransaction(value);
    if (instanceOfAny(value, getIdbProxyableTypes()))
      return new Proxy(value, idbProxyTraps);
    return value;
  }
  function wrap(value) {
    if (value instanceof IDBRequest)
      return promisifyRequest(value);
    if (transformCache.has(value))
      return transformCache.get(value);
    const newValue = transformCachableValue(value);
    if (!Object.is(newValue, value)) {
      transformCache.set(value, newValue);
      reverseTransformCache.set(newValue, value);
    }
    return newValue;
  }
  var unwrap = (value) => reverseTransformCache.get(value);
  function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
    const request = indexedDB.open(name, version);
    const openPromise = wrap(request);
    if (upgrade) {
      request.addEventListener("upgradeneeded", (event) => {
        upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
      });
    }
    if (blocked) {
      request.addEventListener("blocked", (event) => blocked(
        // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion,
        event.newVersion,
        event
      ));
    }
    openPromise.then((db) => {
      if (terminated)
        db.addEventListener("close", () => terminated());
      if (blocking) {
        db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
      }
    }).catch(() => {
    });
    return openPromise;
  }
  var readMethods = ["get", "getKey", "getAll", "getAllKeys", "count"];
  var writeMethods = ["put", "add", "delete", "clear"];
  var cachedMethods = {};
  function getMethod(target, prop) {
    if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
      return;
    }
    if (cachedMethods[prop])
      return cachedMethods[prop];
    const targetFuncName = prop.replace(/FromIndex$/, "");
    const useIndex = prop !== targetFuncName;
    const isWrite = writeMethods.includes(targetFuncName);
    if (
      // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
      !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))
    ) {
      return;
    }
    const method = async function(storeName, ...args) {
      const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
      let target2 = tx.store;
      if (useIndex)
        target2 = target2.index(args.shift());
      return (await Promise.all([
        target2[targetFuncName](...args),
        isWrite && tx.done
      ]))[0];
    };
    return cachedMethods[prop] = method;
  }
  replaceTraps((oldTraps) => ({
    ...oldTraps,
    get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
    has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
  }));
  var advanceMethodProps = ["advance", "continue", "continuePrimaryKey"];
  var methodMap = {};
  var advanceResults = /* @__PURE__ */ new WeakMap();
  var ittrProxiedCursorToOriginalProxy = /* @__PURE__ */ new WeakMap();
  var cursorIteratorTraps = {
    get(target, prop) {
      if (!advanceMethodProps.includes(prop))
        return target[prop];
      let cachedFunc = methodMap[prop];
      if (!cachedFunc) {
        cachedFunc = methodMap[prop] = function(...args) {
          advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
        };
      }
      return cachedFunc;
    }
  };
  async function* iterate(...args) {
    let cursor = this;
    if (!(cursor instanceof IDBCursor)) {
      cursor = await cursor.openCursor(...args);
    }
    if (!cursor)
      return;
    cursor = cursor;
    const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
    ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
    reverseTransformCache.set(proxiedCursor, unwrap(cursor));
    while (cursor) {
      yield proxiedCursor;
      cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
      advanceResults.delete(proxiedCursor);
    }
  }
  function isIteratorProp(target, prop) {
    return prop === Symbol.asyncIterator && instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor]) || prop === "iterate" && instanceOfAny(target, [IDBIndex, IDBObjectStore]);
  }
  replaceTraps((oldTraps) => ({
    ...oldTraps,
    get(target, prop, receiver) {
      if (isIteratorProp(target, prop))
        return iterate;
      return oldTraps.get(target, prop, receiver);
    },
    has(target, prop) {
      return isIteratorProp(target, prop) || oldTraps.has(target, prop);
    }
  }));

  // src/db.ts
  function openDb(name = "baitblocker") {
    return openDB(name, 2, {
      upgrade(db, oldVersion) {
        if (oldVersion < 1) {
          db.createObjectStore("posts", { keyPath: "id" });
          const labels = db.createObjectStore("labels", { keyPath: "id", autoIncrement: true });
          labels.createIndex("postId", "postId");
          db.createObjectStore("authors", { keyPath: "handle" });
        }
        if (oldVersion < 2) db.createObjectStore("countries", { keyPath: "handle" });
      }
    });
  }
  var normHandle = (h) => h.trim().replace(/^@/, "").toLowerCase();
  var newAuthor = (handle) => ({ handle, alpha: 1, beta: 1, seeded: false, postsSeen: 0 });
  var authorScore = (a) => a.alpha / (a.alpha + a.beta);
  var IdbStore = class {
    constructor(db) {
      this.db = db;
    }
    db;
    getPost(id) {
      return this.db.get("posts", id);
    }
    async putPost(p) {
      await this.db.put("posts", p);
    }
    getAuthor(handle) {
      return this.db.get("authors", normHandle(handle));
    }
    async putAuthor(a) {
      await this.db.put("authors", { ...a, handle: normHandle(a.handle) });
    }
    async addLabel(l) {
      await this.db.add("labels", l);
    }
    getCountry(handle) {
      return this.db.get("countries", normHandle(handle));
    }
    async putCountry(c) {
      await this.db.put("countries", { ...c, handle: normHandle(c.handle) });
    }
  };

  // src/combine.ts
  function combineScore(probs, cfg) {
    const maxPart = Math.max(0, ...cfg.max_of.map((q) => probs[q] ?? 0));
    let weighted = 0;
    for (const [q, w] of Object.entries(cfg.weighted)) weighted += w * (probs[q] ?? 0);
    return Math.max(maxPart, weighted);
  }
  function decide(score, t) {
    if (score >= t.hide) return "hide";
    if (score >= t.blur) return "blur";
    return "show";
  }
  function topQuestion(probs) {
    let best;
    for (const [q, p] of Object.entries(probs)) if (best === void 0 || p > probs[best]) best = q;
    return best;
  }
  function combine(probs, cfg, thresholds = cfg.thresholds) {
    const score = combineScore(probs, cfg.combine);
    return { score, decision: decide(score, thresholds), topQuestion: topQuestion(probs) };
  }

  // src/country.ts
  var KNOWN_TTL_MS = 30 * 24 * 36e5;
  var UNKNOWN_TTL_MS = 24 * 36e5;
  function isFresh(r, now = Date.now()) {
    if (!r) return false;
    return now - r.fetchedAt < (r.country ? KNOWN_TTL_MS : UNKNOWN_TTL_MS);
  }
  function isAllowed(country, allowed) {
    if (!country) return false;
    const c = country.toLowerCase();
    return allowed.some((a) => a.trim().toLowerCase() === c);
  }

  // src/scorer.ts
  var Scorer = class {
    constructor(o) {
      this.o = o;
      this.concurrency = o.concurrency ?? 6;
      this.flushMs = o.flushMs ?? 300;
    }
    o;
    queue = [];
    inflight = /* @__PURE__ */ new Map();
    active = 0;
    timer;
    concurrency;
    flushMs;
    decide(post) {
      const existing = this.inflight.get(post.id);
      if (existing) return existing;
      const p = this.decideUncached(post).finally(() => this.inflight.delete(post.id));
      this.inflight.set(post.id, p);
      return p;
    }
    async decideUncached(post) {
      const cached = await this.o.store.getPost(post.id);
      if (cached && (cached.reason === "seeded" || cached.questionsVersion === this.o.config.version)) {
        return this.verdictFor(cached, "cache");
      }
      const seededBy = await this.seededAuthor(post);
      if (seededBy) {
        const rec = {
          ...this.baseRecord(post),
          probs: {},
          score: 1,
          decision: "hide",
          reason: "seeded"
        };
        await this.o.store.putPost(rec);
        await this.o.store.addLabel({ postId: post.id, label: "ragebait", source: "account_seed", at: Date.now() });
        await this.bumpAuthor(post.author);
        return this.verdictFor(rec, "seeded");
      }
      const country = post.author ? await this.o.store.getCountry(normHandle(post.author)) : void 0;
      if (isFresh(country) && isAllowed(country.country, this.allowed())) {
        return { postId: post.id, decision: "show", reason: "country", author: normHandle(post.author), country: country.country };
      }
      if (!this.o.client()) return { postId: post.id, decision: "unscored", reason: "no_key" };
      return new Promise((resolve) => {
        this.queue.push({ post, rescore: !!cached, resolve });
        if (this.queue.length >= this.concurrency) this.flush();
        else this.timer ??= setTimeout(() => this.flush(), this.flushMs);
      });
    }
    flush() {
      clearTimeout(this.timer);
      this.timer = void 0;
      while (this.active < this.concurrency && this.queue.length) {
        const job = this.queue.shift();
        this.active++;
        this.run(job.post, job.rescore).catch(() => ({ postId: job.post.id, decision: "unscored", reason: "error" })).then(job.resolve).finally(() => {
          this.active--;
          if (this.queue.length) this.flush();
        });
      }
    }
    async run(post, rescore) {
      const client2 = this.o.client();
      if (!client2) return { postId: post.id, decision: "unscored", reason: "no_key" };
      if (!await this.o.budget.canSpend()) return { postId: post.id, decision: "unscored", reason: "budget" };
      const images = post.imageUrls?.length && this.o.images ? await this.o.images(post).catch(() => []) : [];
      const { probs, inputTokens } = await client2.score(post, this.o.config.questions, images);
      const c = combine(probs, this.o.config, this.o.thresholds());
      const rec = { ...this.baseRecord(post), probs, score: c.score, decision: c.decision, reason: "d1" };
      await this.o.store.putPost(rec);
      await this.o.budget.record(inputTokens, c.decision);
      if (!rescore) await this.bumpAuthor(post.author, c.score);
      return this.verdictFor(rec, "d1");
    }
    /**
     * A post that endorses a bait quote ("this 👆 so true") inherits the quote's score. The stance is
     * only asked once the quoted post has been scored as bait; until then the post's own score stands
     * (the content script re-asks when the quote's verdict arrives).
     */
    async withEndorsedQuote(rec, own) {
      const stance = this.o.config.stance;
      if (!stance || !rec.quotedId || !rec.quotedText) return own;
      const quoted = await this.o.store.getPost(rec.quotedId);
      if (!quoted || quoted.questionsVersion !== this.o.config.version) return own;
      const t = this.o.thresholds();
      const q = quoted.reason === "seeded" ? { score: 1, decision: "hide" } : combine(quoted.probs, this.o.config, t);
      if (q.score < t.blur || q.score <= own.score) return own;
      if (rec.endorsesQuote === void 0) {
        const p = await this.askStance(rec).catch(() => void 0);
        if (p === void 0) return own;
        rec.endorsesQuote = p;
        await this.o.store.putPost(rec);
      }
      if (rec.endorsesQuote >= stance.threshold) return { score: q.score, decision: q.decision, topQuestion: "endorses_quote" };
      return own.decision === "hide" ? own : { ...own, decision: "show" };
    }
    async askStance(rec) {
      const client2 = this.o.client();
      const stance = this.o.config.stance;
      if (!client2 || !await this.o.budget.canSpend()) return void 0;
      const state = { id: rec.id, text: `${rec.text}

[Quoted post]
${rec.quotedText}`, isReply: false };
      const { probs, inputTokens } = await client2.score(state, [stance]);
      await this.o.budget.record(inputTokens);
      return probs[stance.id];
    }
    allowed() {
      return this.o.allowedCountries?.() ?? ["United States"];
    }
    baseRecord(post) {
      return {
        id: post.id,
        text: post.text,
        quotedText: post.quotedText,
        quotedId: post.quotedId,
        author: post.author ? normHandle(post.author) : void 0,
        seenAt: Date.now(),
        questionsVersion: this.o.config.version
      };
    }
    async seededAuthor(post) {
      for (const h of [post.author, post.quotedId ? void 0 : post.quotedAuthor]) {
        if (!h) continue;
        const a = await this.o.store.getAuthor(normHandle(h));
        if (a?.seeded) return a.handle;
      }
      return void 0;
    }
    async bumpAuthor(handle, score) {
      if (!handle) return;
      const h = normHandle(handle);
      const a = await this.o.store.getAuthor(h) ?? newAuthor(h);
      a.postsSeen++;
      if (score !== void 0) {
        a.alpha += score;
        a.beta += 1 - score;
      }
      await this.o.store.putAuthor(a);
    }
    async verdictFor(rec, reason) {
      const c = rec.reason === "seeded" ? void 0 : await this.withEndorsedQuote(rec, combine(rec.probs, this.o.config, this.o.thresholds()));
      const author = rec.author ? await this.o.store.getAuthor(rec.author) : void 0;
      const v = {
        postId: rec.id,
        decision: c?.decision ?? rec.decision,
        score: c?.score ?? rec.score,
        topQuestion: rec.reason === "seeded" ? "seeded_author" : c?.topQuestion,
        author: rec.author,
        authorScore: author ? authorScore(author) : void 0,
        reason
      };
      if (c && v.decision !== "show") {
        if (!rec.author) return { ...v, decision: "show" };
        const country = await this.o.store.getCountry(rec.author);
        if (!isFresh(country)) return { ...v, decision: "unscored", needsCountry: rec.author };
        v.country = country.country;
        if (!country.country || isAllowed(country.country, this.allowed())) v.decision = "show";
      }
      return v;
    }
  };

  // src/scoring.ts
  var D1_ENDPOINT = "https://api.liquid.ai/decisions/v1/systemone";
  function postToState(post) {
    let s = post.text;
    if (post.quotedText && !post.quotedId) s += `

[Quoting${post.quotedAuthor ? " @" + post.quotedAuthor : ""}]
${post.quotedText}`;
    return s;
  }
  async function imageToDataUrl(url, fetchImpl = (...a) => fetch(...a)) {
    const res = await fetchImpl(url);
    if (!res.ok) throw new Error(`image HTTP ${res.status}`);
    const type = res.headers.get("content-type")?.split(";")[0] || "image/jpeg";
    const bytes = new Uint8Array(await res.arrayBuffer());
    let bin = "";
    for (let i = 0; i < bytes.length; i += 32768) bin += String.fromCharCode(...bytes.subarray(i, i + 32768));
    return `data:${type};base64,${btoa(bin)}`;
  }
  var D1Client = class {
    constructor(apiKey, model = "d1.1", fetchImpl = (...a) => fetch(...a)) {
      this.apiKey = apiKey;
      this.model = model;
      this.fetchImpl = fetchImpl;
    }
    apiKey;
    model;
    fetchImpl;
    async score(post, questions, images = []) {
      const body = {
        model: this.model,
        state: postToState(post),
        ...images.length ? { images } : {},
        questions: Object.fromEntries(questions.map((q) => [q.id, { type: "noul", instructions: q.text }]))
      };
      const res = await this.fetchImpl(D1_ENDPOINT, {
        method: "POST",
        headers: { Authorization: `Bearer ${this.apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      if (!res.ok) throw new Error(`d1 HTTP ${res.status}`);
      const json = await res.json();
      const probs = {};
      for (const q of questions) {
        const a = json?.answers?.[q.id];
        if (typeof a?.noul === "number") probs[q.id] = a.noul;
      }
      return { probs, inputTokens: Number(json?.usage?.input_tokens) || 0 };
    }
  };

  // config/questions.json
  var questions_default = {
    version: 7,
    questions: [
      {
        id: "us_politics",
        text: "Is this post (including any text in attached images) about United States politics, economics, or culture war, written as if the author lives in the US? Examples: Democrats or Republicans, US politicians, the minimum wage or prices in dollars, rent or wages in US cities, US healthcare or insurance, taxes, student loans, guns, immigration, or 'in this country' complaints about America. Answer no for posts that are not about the US, and for neutral news reports."
      },
      {
        id: "ideology_bait",
        text: 'Is this post (including any text in attached images) a sweeping, low-effort take designed to farm replies on a divisive theme, such as capitalism vs socialism, billionaires or the rich, the working class, or rejecting modern technology ("nobody wants self-driving cars", AI, smartphones, cashless payments), stated as a slogan or bold claim rather than a specific argument? Answer no for specific, substantive arguments, news, or personal anecdotes without a provocative generalization.'
      }
    ],
    combine: {
      max_of: [
        "us_politics",
        "ideology_bait"
      ],
      weighted: {}
    },
    thresholds: {
      hide: 0.8,
      blur: 0.5
    },
    stance: {
      id: "endorses_quote",
      text: "A reply-quote: the author wrote the first part, quoting the post after [Quoted post]. Does the author side with the quoted post, wanting readers to agree with it? Answer no if the author is mocking it, arguing against it, correcting it, warning people about it, or commenting on something else.",
      threshold: 0.8
    }
  };

  // src/settings.ts
  var QUESTIONS = questions_default;
  var DEFAULT_SETTINGS = {
    apiKey: "",
    model: "d1.1",
    thresholds: { ...QUESTIONS.thresholds },
    enabled: { pending: true, hide: true, blur: true, flag: true },
    dailyTokenBudget: 1e6,
    captureFixtures: false,
    allowedCountries: ["United States", "North America"],
    scoreImages: true
  };
  async function loadSettings() {
    const { settings: settings2 } = await chrome.storage.local.get("settings");
    const s = settings2 ?? {};
    const saved = s.thresholdsFor === QUESTIONS.version ? s.thresholds : void 0;
    return {
      ...DEFAULT_SETTINGS,
      ...s,
      thresholds: { ...DEFAULT_SETTINGS.thresholds, ...saved },
      enabled: { ...DEFAULT_SETTINGS.enabled, ...s.enabled }
    };
  }
  var today = () => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
  var emptyUsage = () => ({ date: today(), tokens: 0, scored: 0, decisions: { hide: 0, blur: 0, show: 0 } });
  async function loadUsage() {
    const { usage } = await chrome.storage.local.get("usage");
    const u = usage;
    return u && u.date === today() ? u : emptyUsage();
  }
  async function recordUsage(tokens, decision) {
    const u = await loadUsage();
    u.tokens += tokens;
    if (decision) {
      u.scored++;
      u.decisions[decision]++;
    }
    await chrome.storage.local.set({ usage: u });
  }

  // src/background.ts
  var settings = DEFAULT_SETTINGS;
  var client;
  var ready = (async () => {
    settings = await loadSettings();
    client = settings.apiKey ? new D1Client(settings.apiKey, settings.model) : void 0;
    return openDb();
  })();
  chrome.storage.onChanged.addListener(async (changes) => {
    if (!changes.settings) return;
    settings = await loadSettings();
    client = settings.apiKey ? new D1Client(settings.apiKey, settings.model) : void 0;
  });
  var scorer;
  async function getScorer() {
    const db = await ready;
    scorer ??= new Scorer({
      store: new IdbStore(db),
      client: () => client,
      config: QUESTIONS,
      thresholds: () => settings.thresholds,
      allowedCountries: () => settings.allowedCountries,
      images: async (post) => settings.scoreImages ? Promise.all((post.imageUrls ?? []).map((u) => imageToDataUrl(u))) : [],
      budget: {
        canSpend: async () => (await loadUsage()).tokens < settings.dailyTokenBudget,
        record: recordUsage
      }
    });
    return scorer;
  }
  var MAX_CAPTURES = 30;
  var captures = openDB("baitblocker-debug", 1, {
    upgrade(db) {
      db.createObjectStore("captures", { keyPath: "id", autoIncrement: true });
    }
  });
  async function saveCapture(url, body) {
    const db = await captures;
    await db.add("captures", { url, at: Date.now(), body });
    const keys = await db.getAllKeys("captures");
    for (const k of keys.slice(0, Math.max(0, keys.length - MAX_CAPTURES))) await db.delete("captures", k);
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    (async () => {
      switch (msg.type) {
        case "score":
          return (await getScorer()).decide(msg.post);
        case "label": {
          const db = await ready;
          await db.add("labels", { ...msg.label, at: Date.now() });
          return { ok: true };
        }
        case "country": {
          const db = await ready;
          await new IdbStore(db).putCountry({ handle: msg.handle, ...msg.info, fetchedAt: Date.now() });
          return { ok: true };
        }
        case "capture":
          if (settings.captureFixtures) await saveCapture(msg.url, msg.body);
          return { ok: true };
      }
    })().then(sendResponse).catch((e) => {
      console.warn("[baitblocker]", msg.type, "failed:", e instanceof Error ? e.message : e);
      sendResponse(void 0);
    });
    return true;
  });
  chrome.action?.onClicked.addListener(() => chrome.runtime.openOptionsPage());
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vbm9kZV9tb2R1bGVzL2lkYi9idWlsZC9pbmRleC5qcyIsICIuLi9zcmMvZGIudHMiLCAiLi4vc3JjL2NvbWJpbmUudHMiLCAiLi4vc3JjL2NvdW50cnkudHMiLCAiLi4vc3JjL3Njb3Jlci50cyIsICIuLi9zcmMvc2NvcmluZy50cyIsICIuLi9jb25maWcvcXVlc3Rpb25zLmpzb24iLCAiLi4vc3JjL3NldHRpbmdzLnRzIiwgIi4uL3NyYy9iYWNrZ3JvdW5kLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJjb25zdCBpbnN0YW5jZU9mQW55ID0gKG9iamVjdCwgY29uc3RydWN0b3JzKSA9PiBjb25zdHJ1Y3RvcnMuc29tZSgoYykgPT4gb2JqZWN0IGluc3RhbmNlb2YgYyk7XG5cbmxldCBpZGJQcm94eWFibGVUeXBlcztcbmxldCBjdXJzb3JBZHZhbmNlTWV0aG9kcztcbi8vIFRoaXMgaXMgYSBmdW5jdGlvbiB0byBwcmV2ZW50IGl0IHRocm93aW5nIHVwIGluIG5vZGUgZW52aXJvbm1lbnRzLlxuZnVuY3Rpb24gZ2V0SWRiUHJveHlhYmxlVHlwZXMoKSB7XG4gICAgcmV0dXJuIChpZGJQcm94eWFibGVUeXBlcyB8fFxuICAgICAgICAoaWRiUHJveHlhYmxlVHlwZXMgPSBbXG4gICAgICAgICAgICBJREJJbmRleCxcbiAgICAgICAgICAgIElEQk9iamVjdFN0b3JlLFxuICAgICAgICAgICAgSURCQ3Vyc29yLFxuICAgICAgICAgICAgSURCRGF0YWJhc2UsXG4gICAgICAgICAgICBJREJUcmFuc2FjdGlvbixcbiAgICAgICAgXSkpO1xufVxuLy8gVGhpcyBpcyBhIGZ1bmN0aW9uIHRvIHByZXZlbnQgaXQgdGhyb3dpbmcgdXAgaW4gbm9kZSBlbnZpcm9ubWVudHMuXG5mdW5jdGlvbiBnZXRDdXJzb3JBZHZhbmNlTWV0aG9kcygpIHtcbiAgICByZXR1cm4gKGN1cnNvckFkdmFuY2VNZXRob2RzIHx8XG4gICAgICAgIChjdXJzb3JBZHZhbmNlTWV0aG9kcyA9IFsnYWR2YW5jZScsICdjb250aW51ZScsICdjb250aW51ZVByaW1hcnlLZXknXS5tYXAoKG1ldGhvZCkgPT4gSURCQ3Vyc29yLnByb3RvdHlwZVttZXRob2RdKSkpO1xufVxuY29uc3QgdHJhbnNhY3Rpb25Eb25lTWFwID0gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IHRyYW5zZm9ybUNhY2hlID0gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IHJldmVyc2VUcmFuc2Zvcm1DYWNoZSA9IG5ldyBXZWFrTWFwKCk7XG5mdW5jdGlvbiBwcm9taXNpZnlSZXF1ZXN0KHJlcXVlc3QpIHtcbiAgICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBjb25zdCB1bmxpc3RlbiA9ICgpID0+IHtcbiAgICAgICAgICAgIHJlcXVlc3QucmVtb3ZlRXZlbnRMaXN0ZW5lcignc3VjY2VzcycsIHN1Y2Nlc3MpO1xuICAgICAgICAgICAgcmVxdWVzdC5yZW1vdmVFdmVudExpc3RlbmVyKCdlcnJvcicsIGVycm9yKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3Qgc3VjY2VzcyA9ICgpID0+IHtcbiAgICAgICAgICAgIHJlc29sdmUod3JhcChyZXF1ZXN0LnJlc3VsdCkpO1xuICAgICAgICAgICAgdW5saXN0ZW4oKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZXJyb3IgPSAoKSA9PiB7XG4gICAgICAgICAgICByZWplY3QocmVxdWVzdC5lcnJvcik7XG4gICAgICAgICAgICB1bmxpc3RlbigpO1xuICAgICAgICB9O1xuICAgICAgICByZXF1ZXN0LmFkZEV2ZW50TGlzdGVuZXIoJ3N1Y2Nlc3MnLCBzdWNjZXNzKTtcbiAgICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKCdlcnJvcicsIGVycm9yKTtcbiAgICB9KTtcbiAgICAvLyBUaGlzIG1hcHBpbmcgZXhpc3RzIGluIHJldmVyc2VUcmFuc2Zvcm1DYWNoZSBidXQgZG9lc24ndCBleGlzdCBpbiB0cmFuc2Zvcm1DYWNoZS4gVGhpc1xuICAgIC8vIGlzIGJlY2F1c2Ugd2UgY3JlYXRlIG1hbnkgcHJvbWlzZXMgZnJvbSBhIHNpbmdsZSBJREJSZXF1ZXN0LlxuICAgIHJldmVyc2VUcmFuc2Zvcm1DYWNoZS5zZXQocHJvbWlzZSwgcmVxdWVzdCk7XG4gICAgcmV0dXJuIHByb21pc2U7XG59XG5mdW5jdGlvbiBjYWNoZURvbmVQcm9taXNlRm9yVHJhbnNhY3Rpb24odHgpIHtcbiAgICAvLyBFYXJseSBiYWlsIGlmIHdlJ3ZlIGFscmVhZHkgY3JlYXRlZCBhIGRvbmUgcHJvbWlzZSBmb3IgdGhpcyB0cmFuc2FjdGlvbi5cbiAgICBpZiAodHJhbnNhY3Rpb25Eb25lTWFwLmhhcyh0eCkpXG4gICAgICAgIHJldHVybjtcbiAgICBjb25zdCBkb25lID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBjb25zdCB1bmxpc3RlbiA9ICgpID0+IHtcbiAgICAgICAgICAgIHR4LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NvbXBsZXRlJywgY29tcGxldGUpO1xuICAgICAgICAgICAgdHgucmVtb3ZlRXZlbnRMaXN0ZW5lcignZXJyb3InLCBlcnJvcik7XG4gICAgICAgICAgICB0eC5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIGVycm9yKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgY29tcGxldGUgPSAoKSA9PiB7XG4gICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB1bmxpc3RlbigpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBlcnJvciA9ICgpID0+IHtcbiAgICAgICAgICAgIHJlamVjdCh0eC5lcnJvciB8fCBuZXcgRE9NRXhjZXB0aW9uKCdBYm9ydEVycm9yJywgJ0Fib3J0RXJyb3InKSk7XG4gICAgICAgICAgICB1bmxpc3RlbigpO1xuICAgICAgICB9O1xuICAgICAgICB0eC5hZGRFdmVudExpc3RlbmVyKCdjb21wbGV0ZScsIGNvbXBsZXRlKTtcbiAgICAgICAgdHguYWRkRXZlbnRMaXN0ZW5lcignZXJyb3InLCBlcnJvcik7XG4gICAgICAgIHR4LmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgZXJyb3IpO1xuICAgIH0pO1xuICAgIC8vIENhY2hlIGl0IGZvciBsYXRlciByZXRyaWV2YWwuXG4gICAgdHJhbnNhY3Rpb25Eb25lTWFwLnNldCh0eCwgZG9uZSk7XG59XG5sZXQgaWRiUHJveHlUcmFwcyA9IHtcbiAgICBnZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuICAgICAgICBpZiAodGFyZ2V0IGluc3RhbmNlb2YgSURCVHJhbnNhY3Rpb24pIHtcbiAgICAgICAgICAgIC8vIFNwZWNpYWwgaGFuZGxpbmcgZm9yIHRyYW5zYWN0aW9uLmRvbmUuXG4gICAgICAgICAgICBpZiAocHJvcCA9PT0gJ2RvbmUnKVxuICAgICAgICAgICAgICAgIHJldHVybiB0cmFuc2FjdGlvbkRvbmVNYXAuZ2V0KHRhcmdldCk7XG4gICAgICAgICAgICAvLyBNYWtlIHR4LnN0b3JlIHJldHVybiB0aGUgb25seSBzdG9yZSBpbiB0aGUgdHJhbnNhY3Rpb24sIG9yIHVuZGVmaW5lZCBpZiB0aGVyZSBhcmUgbWFueS5cbiAgICAgICAgICAgIGlmIChwcm9wID09PSAnc3RvcmUnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlY2VpdmVyLm9iamVjdFN0b3JlTmFtZXNbMV1cbiAgICAgICAgICAgICAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICAgICAgOiByZWNlaXZlci5vYmplY3RTdG9yZShyZWNlaXZlci5vYmplY3RTdG9yZU5hbWVzWzBdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBFbHNlIHRyYW5zZm9ybSB3aGF0ZXZlciB3ZSBnZXQgYmFjay5cbiAgICAgICAgcmV0dXJuIHdyYXAodGFyZ2V0W3Byb3BdKTtcbiAgICB9LFxuICAgIHNldCh0YXJnZXQsIHByb3AsIHZhbHVlKSB7XG4gICAgICAgIHRhcmdldFtwcm9wXSA9IHZhbHVlO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuICAgIGhhcyh0YXJnZXQsIHByb3ApIHtcbiAgICAgICAgaWYgKHRhcmdldCBpbnN0YW5jZW9mIElEQlRyYW5zYWN0aW9uICYmXG4gICAgICAgICAgICAocHJvcCA9PT0gJ2RvbmUnIHx8IHByb3AgPT09ICdzdG9yZScpKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcHJvcCBpbiB0YXJnZXQ7XG4gICAgfSxcbn07XG5mdW5jdGlvbiByZXBsYWNlVHJhcHMoY2FsbGJhY2spIHtcbiAgICBpZGJQcm94eVRyYXBzID0gY2FsbGJhY2soaWRiUHJveHlUcmFwcyk7XG59XG5mdW5jdGlvbiB3cmFwRnVuY3Rpb24oZnVuYykge1xuICAgIC8vIER1ZSB0byBleHBlY3RlZCBvYmplY3QgZXF1YWxpdHkgKHdoaWNoIGlzIGVuZm9yY2VkIGJ5IHRoZSBjYWNoaW5nIGluIGB3cmFwYCksIHdlXG4gICAgLy8gb25seSBjcmVhdGUgb25lIG5ldyBmdW5jIHBlciBmdW5jLlxuICAgIC8vIEN1cnNvciBtZXRob2RzIGFyZSBzcGVjaWFsLCBhcyB0aGUgYmVoYXZpb3VyIGlzIGEgbGl0dGxlIG1vcmUgZGlmZmVyZW50IHRvIHN0YW5kYXJkIElEQi4gSW5cbiAgICAvLyBJREIsIHlvdSBhZHZhbmNlIHRoZSBjdXJzb3IgYW5kIHdhaXQgZm9yIGEgbmV3ICdzdWNjZXNzJyBvbiB0aGUgSURCUmVxdWVzdCB0aGF0IGdhdmUgeW91IHRoZVxuICAgIC8vIGN1cnNvci4gSXQncyBraW5kYSBsaWtlIGEgcHJvbWlzZSB0aGF0IGNhbiByZXNvbHZlIHdpdGggbWFueSB2YWx1ZXMuIFRoYXQgZG9lc24ndCBtYWtlIHNlbnNlXG4gICAgLy8gd2l0aCByZWFsIHByb21pc2VzLCBzbyBlYWNoIGFkdmFuY2UgbWV0aG9kcyByZXR1cm5zIGEgbmV3IHByb21pc2UgZm9yIHRoZSBjdXJzb3Igb2JqZWN0LCBvclxuICAgIC8vIHVuZGVmaW5lZCBpZiB0aGUgZW5kIG9mIHRoZSBjdXJzb3IgaGFzIGJlZW4gcmVhY2hlZC5cbiAgICBpZiAoZ2V0Q3Vyc29yQWR2YW5jZU1ldGhvZHMoKS5pbmNsdWRlcyhmdW5jKSkge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgICAgIC8vIENhbGxpbmcgdGhlIG9yaWdpbmFsIGZ1bmN0aW9uIHdpdGggdGhlIHByb3h5IGFzICd0aGlzJyBjYXVzZXMgSUxMRUdBTCBJTlZPQ0FUSU9OLCBzbyB3ZSB1c2VcbiAgICAgICAgICAgIC8vIHRoZSBvcmlnaW5hbCBvYmplY3QuXG4gICAgICAgICAgICBmdW5jLmFwcGx5KHVud3JhcCh0aGlzKSwgYXJncyk7XG4gICAgICAgICAgICByZXR1cm4gd3JhcCh0aGlzLnJlcXVlc3QpO1xuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgLy8gQ2FsbGluZyB0aGUgb3JpZ2luYWwgZnVuY3Rpb24gd2l0aCB0aGUgcHJveHkgYXMgJ3RoaXMnIGNhdXNlcyBJTExFR0FMIElOVk9DQVRJT04sIHNvIHdlIHVzZVxuICAgICAgICAvLyB0aGUgb3JpZ2luYWwgb2JqZWN0LlxuICAgICAgICByZXR1cm4gd3JhcChmdW5jLmFwcGx5KHVud3JhcCh0aGlzKSwgYXJncykpO1xuICAgIH07XG59XG5mdW5jdGlvbiB0cmFuc2Zvcm1DYWNoYWJsZVZhbHVlKHZhbHVlKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgcmV0dXJuIHdyYXBGdW5jdGlvbih2YWx1ZSk7XG4gICAgLy8gVGhpcyBkb2Vzbid0IHJldHVybiwgaXQganVzdCBjcmVhdGVzIGEgJ2RvbmUnIHByb21pc2UgZm9yIHRoZSB0cmFuc2FjdGlvbixcbiAgICAvLyB3aGljaCBpcyBsYXRlciByZXR1cm5lZCBmb3IgdHJhbnNhY3Rpb24uZG9uZSAoc2VlIGlkYk9iamVjdEhhbmRsZXIpLlxuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIElEQlRyYW5zYWN0aW9uKVxuICAgICAgICBjYWNoZURvbmVQcm9taXNlRm9yVHJhbnNhY3Rpb24odmFsdWUpO1xuICAgIGlmIChpbnN0YW5jZU9mQW55KHZhbHVlLCBnZXRJZGJQcm94eWFibGVUeXBlcygpKSlcbiAgICAgICAgcmV0dXJuIG5ldyBQcm94eSh2YWx1ZSwgaWRiUHJveHlUcmFwcyk7XG4gICAgLy8gUmV0dXJuIHRoZSBzYW1lIHZhbHVlIGJhY2sgaWYgd2UncmUgbm90IGdvaW5nIHRvIHRyYW5zZm9ybSBpdC5cbiAgICByZXR1cm4gdmFsdWU7XG59XG5mdW5jdGlvbiB3cmFwKHZhbHVlKSB7XG4gICAgLy8gV2Ugc29tZXRpbWVzIGdlbmVyYXRlIG11bHRpcGxlIHByb21pc2VzIGZyb20gYSBzaW5nbGUgSURCUmVxdWVzdCAoZWcgd2hlbiBjdXJzb3JpbmcpLCBiZWNhdXNlXG4gICAgLy8gSURCIGlzIHdlaXJkIGFuZCBhIHNpbmdsZSBJREJSZXF1ZXN0IGNhbiB5aWVsZCBtYW55IHJlc3BvbnNlcywgc28gdGhlc2UgY2FuJ3QgYmUgY2FjaGVkLlxuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIElEQlJlcXVlc3QpXG4gICAgICAgIHJldHVybiBwcm9taXNpZnlSZXF1ZXN0KHZhbHVlKTtcbiAgICAvLyBJZiB3ZSd2ZSBhbHJlYWR5IHRyYW5zZm9ybWVkIHRoaXMgdmFsdWUgYmVmb3JlLCByZXVzZSB0aGUgdHJhbnNmb3JtZWQgdmFsdWUuXG4gICAgLy8gVGhpcyBpcyBmYXN0ZXIsIGJ1dCBpdCBhbHNvIHByb3ZpZGVzIG9iamVjdCBlcXVhbGl0eS5cbiAgICBpZiAodHJhbnNmb3JtQ2FjaGUuaGFzKHZhbHVlKSlcbiAgICAgICAgcmV0dXJuIHRyYW5zZm9ybUNhY2hlLmdldCh2YWx1ZSk7XG4gICAgY29uc3QgbmV3VmFsdWUgPSB0cmFuc2Zvcm1DYWNoYWJsZVZhbHVlKHZhbHVlKTtcbiAgICAvLyBOb3QgYWxsIHR5cGVzIGFyZSB0cmFuc2Zvcm1lZC5cbiAgICAvLyBUaGVzZSBtYXkgYmUgcHJpbWl0aXZlIHR5cGVzLCBzbyB0aGV5IGNhbid0IGJlIFdlYWtNYXAga2V5cy5cbiAgICBpZiAoIU9iamVjdC5pcyhuZXdWYWx1ZSwgdmFsdWUpKSB7XG4gICAgICAgIHRyYW5zZm9ybUNhY2hlLnNldCh2YWx1ZSwgbmV3VmFsdWUpO1xuICAgICAgICByZXZlcnNlVHJhbnNmb3JtQ2FjaGUuc2V0KG5ld1ZhbHVlLCB2YWx1ZSk7XG4gICAgfVxuICAgIHJldHVybiBuZXdWYWx1ZTtcbn1cbmNvbnN0IHVud3JhcCA9ICh2YWx1ZSkgPT4gcmV2ZXJzZVRyYW5zZm9ybUNhY2hlLmdldCh2YWx1ZSk7XG5cbi8qKlxuICogT3BlbiBhIGRhdGFiYXNlLlxuICpcbiAqIEBwYXJhbSBuYW1lIE5hbWUgb2YgdGhlIGRhdGFiYXNlLlxuICogQHBhcmFtIHZlcnNpb24gU2NoZW1hIHZlcnNpb24uXG4gKiBAcGFyYW0gY2FsbGJhY2tzIEFkZGl0aW9uYWwgY2FsbGJhY2tzLlxuICovXG5mdW5jdGlvbiBvcGVuREIobmFtZSwgdmVyc2lvbiwgeyBibG9ja2VkLCB1cGdyYWRlLCBibG9ja2luZywgdGVybWluYXRlZCB9ID0ge30pIHtcbiAgICBjb25zdCByZXF1ZXN0ID0gaW5kZXhlZERCLm9wZW4obmFtZSwgdmVyc2lvbik7XG4gICAgY29uc3Qgb3BlblByb21pc2UgPSB3cmFwKHJlcXVlc3QpO1xuICAgIGlmICh1cGdyYWRlKSB7XG4gICAgICAgIHJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcigndXBncmFkZW5lZWRlZCcsIChldmVudCkgPT4ge1xuICAgICAgICAgICAgdXBncmFkZSh3cmFwKHJlcXVlc3QucmVzdWx0KSwgZXZlbnQub2xkVmVyc2lvbiwgZXZlbnQubmV3VmVyc2lvbiwgd3JhcChyZXF1ZXN0LnRyYW5zYWN0aW9uKSwgZXZlbnQpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgaWYgKGJsb2NrZWQpIHtcbiAgICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKCdibG9ja2VkJywgKGV2ZW50KSA9PiBibG9ja2VkKFxuICAgICAgICAvLyBDYXN0aW5nIGR1ZSB0byBodHRwczovL2dpdGh1Yi5jb20vbWljcm9zb2Z0L1R5cGVTY3JpcHQtRE9NLWxpYi1nZW5lcmF0b3IvcHVsbC8xNDA1XG4gICAgICAgIGV2ZW50Lm9sZFZlcnNpb24sIGV2ZW50Lm5ld1ZlcnNpb24sIGV2ZW50KSk7XG4gICAgfVxuICAgIG9wZW5Qcm9taXNlXG4gICAgICAgIC50aGVuKChkYikgPT4ge1xuICAgICAgICBpZiAodGVybWluYXRlZClcbiAgICAgICAgICAgIGRiLmFkZEV2ZW50TGlzdGVuZXIoJ2Nsb3NlJywgKCkgPT4gdGVybWluYXRlZCgpKTtcbiAgICAgICAgaWYgKGJsb2NraW5nKSB7XG4gICAgICAgICAgICBkYi5hZGRFdmVudExpc3RlbmVyKCd2ZXJzaW9uY2hhbmdlJywgKGV2ZW50KSA9PiBibG9ja2luZyhldmVudC5vbGRWZXJzaW9uLCBldmVudC5uZXdWZXJzaW9uLCBldmVudCkpO1xuICAgICAgICB9XG4gICAgfSlcbiAgICAgICAgLmNhdGNoKCgpID0+IHsgfSk7XG4gICAgcmV0dXJuIG9wZW5Qcm9taXNlO1xufVxuLyoqXG4gKiBEZWxldGUgYSBkYXRhYmFzZS5cbiAqXG4gKiBAcGFyYW0gbmFtZSBOYW1lIG9mIHRoZSBkYXRhYmFzZS5cbiAqL1xuZnVuY3Rpb24gZGVsZXRlREIobmFtZSwgeyBibG9ja2VkIH0gPSB7fSkge1xuICAgIGNvbnN0IHJlcXVlc3QgPSBpbmRleGVkREIuZGVsZXRlRGF0YWJhc2UobmFtZSk7XG4gICAgaWYgKGJsb2NrZWQpIHtcbiAgICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKCdibG9ja2VkJywgKGV2ZW50KSA9PiBibG9ja2VkKFxuICAgICAgICAvLyBDYXN0aW5nIGR1ZSB0byBodHRwczovL2dpdGh1Yi5jb20vbWljcm9zb2Z0L1R5cGVTY3JpcHQtRE9NLWxpYi1nZW5lcmF0b3IvcHVsbC8xNDA1XG4gICAgICAgIGV2ZW50Lm9sZFZlcnNpb24sIGV2ZW50KSk7XG4gICAgfVxuICAgIHJldHVybiB3cmFwKHJlcXVlc3QpLnRoZW4oKCkgPT4gdW5kZWZpbmVkKTtcbn1cblxuY29uc3QgcmVhZE1ldGhvZHMgPSBbJ2dldCcsICdnZXRLZXknLCAnZ2V0QWxsJywgJ2dldEFsbEtleXMnLCAnY291bnQnXTtcbmNvbnN0IHdyaXRlTWV0aG9kcyA9IFsncHV0JywgJ2FkZCcsICdkZWxldGUnLCAnY2xlYXInXTtcbmNvbnN0IGNhY2hlZE1ldGhvZHMgPSB7fTtcbmZ1bmN0aW9uIGdldE1ldGhvZCh0YXJnZXQsIHByb3ApIHtcbiAgICBpZiAoISh0YXJnZXQgaW5zdGFuY2VvZiBJREJEYXRhYmFzZSAmJlxuICAgICAgICAhKHByb3AgaW4gdGFyZ2V0KSAmJlxuICAgICAgICB0eXBlb2YgcHJvcCA9PT0gJ3N0cmluZycpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGNhY2hlZE1ldGhvZHNbcHJvcF0pXG4gICAgICAgIHJldHVybiBjYWNoZWRNZXRob2RzW3Byb3BdO1xuICAgIGNvbnN0IHRhcmdldEZ1bmNOYW1lID0gcHJvcC5yZXBsYWNlKC9Gcm9tSW5kZXgkLywgJycpO1xuICAgIGNvbnN0IHVzZUluZGV4ID0gcHJvcCAhPT0gdGFyZ2V0RnVuY05hbWU7XG4gICAgY29uc3QgaXNXcml0ZSA9IHdyaXRlTWV0aG9kcy5pbmNsdWRlcyh0YXJnZXRGdW5jTmFtZSk7XG4gICAgaWYgKFxuICAgIC8vIEJhaWwgaWYgdGhlIHRhcmdldCBkb2Vzbid0IGV4aXN0IG9uIHRoZSB0YXJnZXQuIEVnLCBnZXRBbGwgaXNuJ3QgaW4gRWRnZS5cbiAgICAhKHRhcmdldEZ1bmNOYW1lIGluICh1c2VJbmRleCA/IElEQkluZGV4IDogSURCT2JqZWN0U3RvcmUpLnByb3RvdHlwZSkgfHxcbiAgICAgICAgIShpc1dyaXRlIHx8IHJlYWRNZXRob2RzLmluY2x1ZGVzKHRhcmdldEZ1bmNOYW1lKSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBtZXRob2QgPSBhc3luYyBmdW5jdGlvbiAoc3RvcmVOYW1lLCAuLi5hcmdzKSB7XG4gICAgICAgIC8vIGlzV3JpdGUgPyAncmVhZHdyaXRlJyA6IHVuZGVmaW5lZCBnemlwcHMgYmV0dGVyLCBidXQgZmFpbHMgaW4gRWRnZSA6KFxuICAgICAgICBjb25zdCB0eCA9IHRoaXMudHJhbnNhY3Rpb24oc3RvcmVOYW1lLCBpc1dyaXRlID8gJ3JlYWR3cml0ZScgOiAncmVhZG9ubHknKTtcbiAgICAgICAgbGV0IHRhcmdldCA9IHR4LnN0b3JlO1xuICAgICAgICBpZiAodXNlSW5kZXgpXG4gICAgICAgICAgICB0YXJnZXQgPSB0YXJnZXQuaW5kZXgoYXJncy5zaGlmdCgpKTtcbiAgICAgICAgLy8gTXVzdCByZWplY3QgaWYgb3AgcmVqZWN0cy5cbiAgICAgICAgLy8gSWYgaXQncyBhIHdyaXRlIG9wZXJhdGlvbiwgbXVzdCByZWplY3QgaWYgdHguZG9uZSByZWplY3RzLlxuICAgICAgICAvLyBNdXN0IHJlamVjdCB3aXRoIG9wIHJlamVjdGlvbiBmaXJzdC5cbiAgICAgICAgLy8gTXVzdCByZXNvbHZlIHdpdGggb3AgdmFsdWUuXG4gICAgICAgIC8vIE11c3QgaGFuZGxlIGJvdGggcHJvbWlzZXMgKG5vIHVuaGFuZGxlZCByZWplY3Rpb25zKVxuICAgICAgICByZXR1cm4gKGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgIHRhcmdldFt0YXJnZXRGdW5jTmFtZV0oLi4uYXJncyksXG4gICAgICAgICAgICBpc1dyaXRlICYmIHR4LmRvbmUsXG4gICAgICAgIF0pKVswXTtcbiAgICB9O1xuICAgIHJldHVybiAoY2FjaGVkTWV0aG9kc1twcm9wXSA9IG1ldGhvZCk7XG59XG5yZXBsYWNlVHJhcHMoKG9sZFRyYXBzKSA9PiAoe1xuICAgIC4uLm9sZFRyYXBzLFxuICAgIGdldDogKHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpID0+IGdldE1ldGhvZCh0YXJnZXQsIHByb3ApIHx8IG9sZFRyYXBzLmdldCh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKSxcbiAgICBoYXM6ICh0YXJnZXQsIHByb3ApID0+ICEhZ2V0TWV0aG9kKHRhcmdldCwgcHJvcCkgfHwgb2xkVHJhcHMuaGFzKHRhcmdldCwgcHJvcCksXG59KSk7XG5cbmNvbnN0IGFkdmFuY2VNZXRob2RQcm9wcyA9IFsnYWR2YW5jZScsICdjb250aW51ZScsICdjb250aW51ZVByaW1hcnlLZXknXTtcbmNvbnN0IG1ldGhvZE1hcCA9IHt9O1xuY29uc3QgYWR2YW5jZVJlc3VsdHMgPSBuZXcgV2Vha01hcCgpO1xuY29uc3QgaXR0clByb3hpZWRDdXJzb3JUb09yaWdpbmFsUHJveHkgPSBuZXcgV2Vha01hcCgpO1xuY29uc3QgY3Vyc29ySXRlcmF0b3JUcmFwcyA9IHtcbiAgICBnZXQodGFyZ2V0LCBwcm9wKSB7XG4gICAgICAgIGlmICghYWR2YW5jZU1ldGhvZFByb3BzLmluY2x1ZGVzKHByb3ApKVxuICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtwcm9wXTtcbiAgICAgICAgbGV0IGNhY2hlZEZ1bmMgPSBtZXRob2RNYXBbcHJvcF07XG4gICAgICAgIGlmICghY2FjaGVkRnVuYykge1xuICAgICAgICAgICAgY2FjaGVkRnVuYyA9IG1ldGhvZE1hcFtwcm9wXSA9IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgICAgICAgICAgICAgYWR2YW5jZVJlc3VsdHMuc2V0KHRoaXMsIGl0dHJQcm94aWVkQ3Vyc29yVG9PcmlnaW5hbFByb3h5LmdldCh0aGlzKVtwcm9wXSguLi5hcmdzKSk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjYWNoZWRGdW5jO1xuICAgIH0sXG59O1xuYXN5bmMgZnVuY3Rpb24qIGl0ZXJhdGUoLi4uYXJncykge1xuICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpuby10aGlzLWFzc2lnbm1lbnRcbiAgICBsZXQgY3Vyc29yID0gdGhpcztcbiAgICBpZiAoIShjdXJzb3IgaW5zdGFuY2VvZiBJREJDdXJzb3IpKSB7XG4gICAgICAgIGN1cnNvciA9IGF3YWl0IGN1cnNvci5vcGVuQ3Vyc29yKC4uLmFyZ3MpO1xuICAgIH1cbiAgICBpZiAoIWN1cnNvcilcbiAgICAgICAgcmV0dXJuO1xuICAgIGN1cnNvciA9IGN1cnNvcjtcbiAgICBjb25zdCBwcm94aWVkQ3Vyc29yID0gbmV3IFByb3h5KGN1cnNvciwgY3Vyc29ySXRlcmF0b3JUcmFwcyk7XG4gICAgaXR0clByb3hpZWRDdXJzb3JUb09yaWdpbmFsUHJveHkuc2V0KHByb3hpZWRDdXJzb3IsIGN1cnNvcik7XG4gICAgLy8gTWFwIHRoaXMgZG91YmxlLXByb3h5IGJhY2sgdG8gdGhlIG9yaWdpbmFsLCBzbyBvdGhlciBjdXJzb3IgbWV0aG9kcyB3b3JrLlxuICAgIHJldmVyc2VUcmFuc2Zvcm1DYWNoZS5zZXQocHJveGllZEN1cnNvciwgdW53cmFwKGN1cnNvcikpO1xuICAgIHdoaWxlIChjdXJzb3IpIHtcbiAgICAgICAgeWllbGQgcHJveGllZEN1cnNvcjtcbiAgICAgICAgLy8gSWYgb25lIG9mIHRoZSBhZHZhbmNpbmcgbWV0aG9kcyB3YXMgbm90IGNhbGxlZCwgY2FsbCBjb250aW51ZSgpLlxuICAgICAgICBjdXJzb3IgPSBhd2FpdCAoYWR2YW5jZVJlc3VsdHMuZ2V0KHByb3hpZWRDdXJzb3IpIHx8IGN1cnNvci5jb250aW51ZSgpKTtcbiAgICAgICAgYWR2YW5jZVJlc3VsdHMuZGVsZXRlKHByb3hpZWRDdXJzb3IpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGlzSXRlcmF0b3JQcm9wKHRhcmdldCwgcHJvcCkge1xuICAgIHJldHVybiAoKHByb3AgPT09IFN5bWJvbC5hc3luY0l0ZXJhdG9yICYmXG4gICAgICAgIGluc3RhbmNlT2ZBbnkodGFyZ2V0LCBbSURCSW5kZXgsIElEQk9iamVjdFN0b3JlLCBJREJDdXJzb3JdKSkgfHxcbiAgICAgICAgKHByb3AgPT09ICdpdGVyYXRlJyAmJiBpbnN0YW5jZU9mQW55KHRhcmdldCwgW0lEQkluZGV4LCBJREJPYmplY3RTdG9yZV0pKSk7XG59XG5yZXBsYWNlVHJhcHMoKG9sZFRyYXBzKSA9PiAoe1xuICAgIC4uLm9sZFRyYXBzLFxuICAgIGdldCh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG4gICAgICAgIGlmIChpc0l0ZXJhdG9yUHJvcCh0YXJnZXQsIHByb3ApKVxuICAgICAgICAgICAgcmV0dXJuIGl0ZXJhdGU7XG4gICAgICAgIHJldHVybiBvbGRUcmFwcy5nZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcik7XG4gICAgfSxcbiAgICBoYXModGFyZ2V0LCBwcm9wKSB7XG4gICAgICAgIHJldHVybiBpc0l0ZXJhdG9yUHJvcCh0YXJnZXQsIHByb3ApIHx8IG9sZFRyYXBzLmhhcyh0YXJnZXQsIHByb3ApO1xuICAgIH0sXG59KSk7XG5cbmV4cG9ydCB7IGRlbGV0ZURCLCBvcGVuREIsIHVud3JhcCwgd3JhcCB9O1xuIiwgImltcG9ydCB7IG9wZW5EQiwgdHlwZSBEQlNjaGVtYSwgdHlwZSBJREJQRGF0YWJhc2UgfSBmcm9tICdpZGInO1xuaW1wb3J0IHR5cGUgeyBBdXRob3JSZWNvcmQsIENvdW50cnlSZWNvcmQsIExhYmVsUmVjb3JkLCBQb3N0UmVjb3JkIH0gZnJvbSAnLi90eXBlcyc7XG5cbmludGVyZmFjZSBCYWl0U2NoZW1hIGV4dGVuZHMgREJTY2hlbWEge1xuICBwb3N0czogeyBrZXk6IHN0cmluZzsgdmFsdWU6IFBvc3RSZWNvcmQgfTtcbiAgbGFiZWxzOiB7IGtleTogbnVtYmVyOyB2YWx1ZTogTGFiZWxSZWNvcmQ7IGluZGV4ZXM6IHsgcG9zdElkOiBzdHJpbmcgfSB9O1xuICBhdXRob3JzOiB7IGtleTogc3RyaW5nOyB2YWx1ZTogQXV0aG9yUmVjb3JkIH07XG4gIGNvdW50cmllczogeyBrZXk6IHN0cmluZzsgdmFsdWU6IENvdW50cnlSZWNvcmQgfTtcbn1cblxuZXhwb3J0IHR5cGUgQmFpdERCID0gSURCUERhdGFiYXNlPEJhaXRTY2hlbWE+O1xuXG5leHBvcnQgZnVuY3Rpb24gb3BlbkRiKG5hbWUgPSAnYmFpdGJsb2NrZXInKTogUHJvbWlzZTxCYWl0REI+IHtcbiAgcmV0dXJuIG9wZW5EQjxCYWl0U2NoZW1hPihuYW1lLCAyLCB7XG4gICAgdXBncmFkZShkYiwgb2xkVmVyc2lvbikge1xuICAgICAgaWYgKG9sZFZlcnNpb24gPCAxKSB7XG4gICAgICAgIGRiLmNyZWF0ZU9iamVjdFN0b3JlKCdwb3N0cycsIHsga2V5UGF0aDogJ2lkJyB9KTtcbiAgICAgICAgY29uc3QgbGFiZWxzID0gZGIuY3JlYXRlT2JqZWN0U3RvcmUoJ2xhYmVscycsIHsga2V5UGF0aDogJ2lkJywgYXV0b0luY3JlbWVudDogdHJ1ZSB9KTtcbiAgICAgICAgbGFiZWxzLmNyZWF0ZUluZGV4KCdwb3N0SWQnLCAncG9zdElkJyk7XG4gICAgICAgIGRiLmNyZWF0ZU9iamVjdFN0b3JlKCdhdXRob3JzJywgeyBrZXlQYXRoOiAnaGFuZGxlJyB9KTtcbiAgICAgIH1cbiAgICAgIGlmIChvbGRWZXJzaW9uIDwgMikgZGIuY3JlYXRlT2JqZWN0U3RvcmUoJ2NvdW50cmllcycsIHsga2V5UGF0aDogJ2hhbmRsZScgfSk7XG4gICAgfSxcbiAgfSk7XG59XG5cbmV4cG9ydCBjb25zdCBub3JtSGFuZGxlID0gKGg6IHN0cmluZykgPT4gaC50cmltKCkucmVwbGFjZSgvXkAvLCAnJykudG9Mb3dlckNhc2UoKTtcblxuZXhwb3J0IGNvbnN0IG5ld0F1dGhvciA9IChoYW5kbGU6IHN0cmluZyk6IEF1dGhvclJlY29yZCA9PiAoeyBoYW5kbGUsIGFscGhhOiAxLCBiZXRhOiAxLCBzZWVkZWQ6IGZhbHNlLCBwb3N0c1NlZW46IDAgfSk7XG5cbmV4cG9ydCBjb25zdCBhdXRob3JTY29yZSA9IChhOiBBdXRob3JSZWNvcmQpID0+IGEuYWxwaGEgLyAoYS5hbHBoYSArIGEuYmV0YSk7XG5cbi8qKiBTdG9yYWdlIG9wZXJhdGlvbnMgdGhlIHNjb3JlciBuZWVkczsgaW1wbGVtZW50ZWQgb3ZlciBJbmRleGVkREIgaGVyZSBhbmQgbW9ja2VkIGluIHRlc3RzLiAqL1xuZXhwb3J0IGludGVyZmFjZSBTdG9yZSB7XG4gIGdldFBvc3QoaWQ6IHN0cmluZyk6IFByb21pc2U8UG9zdFJlY29yZCB8IHVuZGVmaW5lZD47XG4gIHB1dFBvc3QocDogUG9zdFJlY29yZCk6IFByb21pc2U8dm9pZD47XG4gIGdldEF1dGhvcihoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8QXV0aG9yUmVjb3JkIHwgdW5kZWZpbmVkPjtcbiAgcHV0QXV0aG9yKGE6IEF1dGhvclJlY29yZCk6IFByb21pc2U8dm9pZD47XG4gIGFkZExhYmVsKGw6IExhYmVsUmVjb3JkKTogUHJvbWlzZTx2b2lkPjtcbiAgZ2V0Q291bnRyeShoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8Q291bnRyeVJlY29yZCB8IHVuZGVmaW5lZD47XG4gIHB1dENvdW50cnkoYzogQ291bnRyeVJlY29yZCk6IFByb21pc2U8dm9pZD47XG59XG5cbmV4cG9ydCBjbGFzcyBJZGJTdG9yZSBpbXBsZW1lbnRzIFN0b3JlIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBkYjogQmFpdERCKSB7fVxuICBnZXRQb3N0KGlkOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5kYi5nZXQoJ3Bvc3RzJywgaWQpO1xuICB9XG4gIGFzeW5jIHB1dFBvc3QocDogUG9zdFJlY29yZCkge1xuICAgIGF3YWl0IHRoaXMuZGIucHV0KCdwb3N0cycsIHApO1xuICB9XG4gIGdldEF1dGhvcihoYW5kbGU6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLmRiLmdldCgnYXV0aG9ycycsIG5vcm1IYW5kbGUoaGFuZGxlKSk7XG4gIH1cbiAgYXN5bmMgcHV0QXV0aG9yKGE6IEF1dGhvclJlY29yZCkge1xuICAgIGF3YWl0IHRoaXMuZGIucHV0KCdhdXRob3JzJywgeyAuLi5hLCBoYW5kbGU6IG5vcm1IYW5kbGUoYS5oYW5kbGUpIH0pO1xuICB9XG4gIGFzeW5jIGFkZExhYmVsKGw6IExhYmVsUmVjb3JkKSB7XG4gICAgYXdhaXQgdGhpcy5kYi5hZGQoJ2xhYmVscycsIGwpO1xuICB9XG4gIGdldENvdW50cnkoaGFuZGxlOiBzdHJpbmcpIHtcbiAgICByZXR1cm4gdGhpcy5kYi5nZXQoJ2NvdW50cmllcycsIG5vcm1IYW5kbGUoaGFuZGxlKSk7XG4gIH1cbiAgYXN5bmMgcHV0Q291bnRyeShjOiBDb3VudHJ5UmVjb3JkKSB7XG4gICAgYXdhaXQgdGhpcy5kYi5wdXQoJ2NvdW50cmllcycsIHsgLi4uYywgaGFuZGxlOiBub3JtSGFuZGxlKGMuaGFuZGxlKSB9KTtcbiAgfVxufVxuXG4vKiogVXBzZXJ0IHNlZWQgZW50cmllczsgZXhpc3RpbmcgYWxwaGEvYmV0YSBhcmUga2VwdC4gUmV0dXJucyB0aGUgbnVtYmVyIGltcG9ydGVkLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGltcG9ydFNlZWRzKGRiOiBCYWl0REIsIHNlZWRzOiB7IGhhbmRsZTogc3RyaW5nOyB0ZXh0Pzogc3RyaW5nIH1bXSk6IFByb21pc2U8bnVtYmVyPiB7XG4gIGNvbnN0IHR4ID0gZGIudHJhbnNhY3Rpb24oJ2F1dGhvcnMnLCAncmVhZHdyaXRlJyk7XG4gIGxldCBuID0gMDtcbiAgZm9yIChjb25zdCBzIG9mIHNlZWRzKSB7XG4gICAgaWYgKCFzPy5oYW5kbGUpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGhhbmRsZSA9IG5vcm1IYW5kbGUocy5oYW5kbGUpO1xuICAgIGlmICghaGFuZGxlKSBjb250aW51ZTtcbiAgICBjb25zdCBleGlzdGluZyA9IChhd2FpdCB0eC5zdG9yZS5nZXQoaGFuZGxlKSkgPz8gbmV3QXV0aG9yKGhhbmRsZSk7XG4gICAgYXdhaXQgdHguc3RvcmUucHV0KHsgLi4uZXhpc3RpbmcsIHNlZWRlZDogdHJ1ZSwgc2VlZFRleHQ6IHMudGV4dCA/PyBleGlzdGluZy5zZWVkVGV4dCB9KTtcbiAgICBuKys7XG4gIH1cbiAgYXdhaXQgdHguZG9uZTtcbiAgcmV0dXJuIG47XG59XG5cbi8qKiBsYWJlbHMuanNvbmw6IGVhY2ggbGFiZWwgam9pbmVkIHdpdGggaXRzIHBvc3QgcmVjb3JkLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGV4cG9ydExhYmVscyhkYjogQmFpdERCKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgbGFiZWxzID0gYXdhaXQgZGIuZ2V0QWxsKCdsYWJlbHMnKTtcbiAgY29uc3QgbGluZXM6IHN0cmluZ1tdID0gW107XG4gIGZvciAoY29uc3QgbCBvZiBsYWJlbHMpIGxpbmVzLnB1c2goSlNPTi5zdHJpbmdpZnkoeyAuLi5sLCBwb3N0OiAoYXdhaXQgZGIuZ2V0KCdwb3N0cycsIGwucG9zdElkKSkgPz8gbnVsbCB9KSk7XG4gIHJldHVybiBsaW5lcy5qb2luKCdcXG4nKSArIChsaW5lcy5sZW5ndGggPyAnXFxuJyA6ICcnKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGV4cG9ydEF1dGhvcnMoZGI6IEJhaXREQik6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGF1dGhvcnMgPSBhd2FpdCBkYi5nZXRBbGwoJ2F1dGhvcnMnKTtcbiAgcmV0dXJuIGF1dGhvcnMubWFwKChhKSA9PiBKU09OLnN0cmluZ2lmeSh7IC4uLmEsIHNjb3JlOiBhdXRob3JTY29yZShhKSB9KSkuam9pbignXFxuJykgKyAoYXV0aG9ycy5sZW5ndGggPyAnXFxuJyA6ICcnKTtcbn1cbiIsICJpbXBvcnQgdHlwZSB7IERlY2lzaW9uLCBRdWVzdGlvbnNDb25maWcsIFRocmVzaG9sZHMgfSBmcm9tICcuL3R5cGVzJztcblxuZXhwb3J0IGludGVyZmFjZSBDb21iaW5lZCB7XG4gIHNjb3JlOiBudW1iZXI7XG4gIGRlY2lzaW9uOiBEZWNpc2lvbjtcbiAgLyoqIFF1ZXN0aW9uIHdpdGggdGhlIGhpZ2hlc3QgcHJvYmFiaWxpdHksIHVzZWQgdG8gbmFtZSB0aGUgcmVhc29uIGluIHRoZSBVSS4gKi9cbiAgdG9wUXVlc3Rpb24/OiBzdHJpbmc7XG59XG5cbi8qKiBzY29yZSA9IG1heChwW21heF9vZi4uLl0sIHN1bSh3X2kgKiBwX2kgZm9yIHdlaWdodGVkKSkgKi9cbmV4cG9ydCBmdW5jdGlvbiBjb21iaW5lU2NvcmUocHJvYnM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4sIGNmZzogUXVlc3Rpb25zQ29uZmlnWydjb21iaW5lJ10pOiBudW1iZXIge1xuICBjb25zdCBtYXhQYXJ0ID0gTWF0aC5tYXgoMCwgLi4uY2ZnLm1heF9vZi5tYXAoKHEpID0+IHByb2JzW3FdID8/IDApKTtcbiAgbGV0IHdlaWdodGVkID0gMDtcbiAgZm9yIChjb25zdCBbcSwgd10gb2YgT2JqZWN0LmVudHJpZXMoY2ZnLndlaWdodGVkKSkgd2VpZ2h0ZWQgKz0gdyAqIChwcm9ic1txXSA/PyAwKTtcbiAgcmV0dXJuIE1hdGgubWF4KG1heFBhcnQsIHdlaWdodGVkKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlY2lkZShzY29yZTogbnVtYmVyLCB0OiBUaHJlc2hvbGRzKTogRGVjaXNpb24ge1xuICBpZiAoc2NvcmUgPj0gdC5oaWRlKSByZXR1cm4gJ2hpZGUnO1xuICBpZiAoc2NvcmUgPj0gdC5ibHVyKSByZXR1cm4gJ2JsdXInO1xuICByZXR1cm4gJ3Nob3cnO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdG9wUXVlc3Rpb24ocHJvYnM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4pOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICBsZXQgYmVzdDogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICBmb3IgKGNvbnN0IFtxLCBwXSBvZiBPYmplY3QuZW50cmllcyhwcm9icykpIGlmIChiZXN0ID09PSB1bmRlZmluZWQgfHwgcCA+IHByb2JzW2Jlc3RdKSBiZXN0ID0gcTtcbiAgcmV0dXJuIGJlc3Q7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjb21iaW5lKHByb2JzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+LCBjZmc6IFF1ZXN0aW9uc0NvbmZpZywgdGhyZXNob2xkcyA9IGNmZy50aHJlc2hvbGRzKTogQ29tYmluZWQge1xuICBjb25zdCBzY29yZSA9IGNvbWJpbmVTY29yZShwcm9icywgY2ZnLmNvbWJpbmUpO1xuICByZXR1cm4geyBzY29yZSwgZGVjaXNpb246IGRlY2lkZShzY29yZSwgdGhyZXNob2xkcyksIHRvcFF1ZXN0aW9uOiB0b3BRdWVzdGlvbihwcm9icykgfTtcbn1cbiIsICJpbXBvcnQgdHlwZSB7IENvdW50cnlSZWNvcmQgfSBmcm9tICcuL3R5cGVzJztcblxuZXhwb3J0IGNvbnN0IEFCT1VUX09QID0gJ0Fib3V0QWNjb3VudFF1ZXJ5Jztcbi8qKiBRdWVyeSBJRCBvYnNlcnZlZCAyMDI2LTExLTExOyByZWZyZXNoZWQgYXV0b21hdGljYWxseSBmcm9tIFgncyBvd24gdHJhZmZpYyB3aGVuIGl0IHJvdGF0ZXMuICovXG5leHBvcnQgY29uc3QgREVGQVVMVF9BQk9VVF9RVUVSWV9JRCA9ICdUek9HMnR3WkVmaHI5S21DbHZWVnFBJztcbi8qKiBYIHdlYiBjbGllbnQncyBwdWJsaWMgYmVhcmVyIHRva2VuOyByZXBsYWNlZCBieSB3aGF0ZXZlciBYIGl0c2VsZiBzZW5kcyB3aGVuIG9ic2VydmVkLiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfQkVBUkVSID1cbiAgJ0JlYXJlciBBQUFBQUFBQUFBQUFBQUFBQUFBQUFOUklMZ0FBQUFBQW5Od0l6VWVqUkNPdUg1RTZJOHhuWno0cHVUcyUzRDFadjd0dGZrOExGODFJVXExNmNIamhMVHZKdTRGQTMzQUdXV2pDcFRuQSc7XG5cbmV4cG9ydCBjb25zdCBLTk9XTl9UVExfTVMgPSAzMCAqIDI0ICogMzYwMF8wMDA7XG5leHBvcnQgY29uc3QgVU5LTk9XTl9UVExfTVMgPSAyNCAqIDM2MDBfMDAwO1xuXG5leHBvcnQgaW50ZXJmYWNlIEFib3V0SW5mbyB7XG4gIGNvdW50cnk/OiBzdHJpbmc7XG4gIGFjY3VyYXRlPzogYm9vbGVhbjtcbn1cblxuLyoqIEZpbmRzIGBhYm91dF9wcm9maWxlYCBhbnl3aGVyZSBpbiBhbiBBYm91dEFjY291bnRRdWVyeSByZXNwb25zZS4gTmV2ZXIgdGhyb3dzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQWJvdXQoanNvbjogdW5rbm93bik6IEFib3V0SW5mbyB7XG4gIGNvbnN0IHN0YWNrOiB1bmtub3duW10gPSBbanNvbl07XG4gIHdoaWxlIChzdGFjay5sZW5ndGgpIHtcbiAgICBjb25zdCBuID0gc3RhY2sucG9wKCk7XG4gICAgaWYgKHR5cGVvZiBuICE9PSAnb2JqZWN0JyB8fCBuID09PSBudWxsKSBjb250aW51ZTtcbiAgICBjb25zdCBhYm91dCA9IChuIGFzIGFueSkuYWJvdXRfcHJvZmlsZTtcbiAgICBpZiAoYWJvdXQgJiYgdHlwZW9mIGFib3V0ID09PSAnb2JqZWN0Jykge1xuICAgICAgY29uc3QgYyA9IGFib3V0LmFjY291bnRfYmFzZWRfaW47XG4gICAgICByZXR1cm4ge1xuICAgICAgICBjb3VudHJ5OiB0eXBlb2YgYyA9PT0gJ3N0cmluZycgJiYgYy50cmltKCkgPyBjLnRyaW0oKSA6IHVuZGVmaW5lZCxcbiAgICAgICAgYWNjdXJhdGU6IHR5cGVvZiBhYm91dC5sb2NhdGlvbl9hY2N1cmF0ZSA9PT0gJ2Jvb2xlYW4nID8gYWJvdXQubG9jYXRpb25fYWNjdXJhdGUgOiB1bmRlZmluZWQsXG4gICAgICB9O1xuICAgIH1cbiAgICBzdGFjay5wdXNoKC4uLk9iamVjdC52YWx1ZXMobikpO1xuICB9XG4gIHJldHVybiB7fTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRnJlc2gocjogQ291bnRyeVJlY29yZCB8IHVuZGVmaW5lZCwgbm93ID0gRGF0ZS5ub3coKSk6IHIgaXMgQ291bnRyeVJlY29yZCB7XG4gIGlmICghcikgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gbm93IC0gci5mZXRjaGVkQXQgPCAoci5jb3VudHJ5ID8gS05PV05fVFRMX01TIDogVU5LTk9XTl9UVExfTVMpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNBbGxvd2VkKGNvdW50cnk6IHN0cmluZyB8IHVuZGVmaW5lZCwgYWxsb3dlZDogc3RyaW5nW10pOiBib29sZWFuIHtcbiAgaWYgKCFjb3VudHJ5KSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IGMgPSBjb3VudHJ5LnRvTG93ZXJDYXNlKCk7XG4gIHJldHVybiBhbGxvd2VkLnNvbWUoKGEpID0+IGEudHJpbSgpLnRvTG93ZXJDYXNlKCkgPT09IGMpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYWJvdXRRdWVyeUlkKHVybDogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgcmV0dXJuIG5ldyBSZWdFeHAoYC9ncmFwaHFsLyhbXi9dKykvJHtBQk9VVF9PUH1cXFxcYmApLmV4ZWModXJsKT8uWzFdO1xufVxuXG5leHBvcnQgdHlwZSBMb29rdXBSZXN1bHQgPSB7IG9rOiB0cnVlOyBpbmZvOiBBYm91dEluZm8gfSB8IHsgb2s6IGZhbHNlOyBlcnJvcjogc3RyaW5nIH07XG5cbmV4cG9ydCBpbnRlcmZhY2UgRmV0Y2hlckRlcHMge1xuICBmZXRjaDogdHlwZW9mIGZldGNoO1xuICBxdWVyeUlkOiAoKSA9PiBzdHJpbmc7XG4gIGhlYWRlcnM6ICgpID0+IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XG4gIG5vdz86ICgpID0+IG51bWJlcjtcbiAgc2xlZXA/OiAobXM6IG51bWJlcikgPT4gUHJvbWlzZTx2b2lkPjtcbiAgLyoqIE1pbmltdW0gZ2FwIGJldHdlZW4gcmVxdWVzdHMuICovXG4gIGdhcE1zPzogbnVtYmVyO1xufVxuXG4vKipcbiAqIE9uZSByZXF1ZXN0IGF0IGEgdGltZSwgc3BhY2VkIG91dCwgcGF1c2luZyB1bnRpbCBYJ3MgcmF0ZS1saW1pdCByZXNldCB3aGVuIHRoZVxuICogd2luZG93ICg1MCBwZXIgMTUgbWluIGF0IHRoZSB0aW1lIG9mIHdyaXRpbmcpIGlzIG5lYXJseSB1c2VkIHVwLlxuICovXG5leHBvcnQgY2xhc3MgQ291bnRyeUZldGNoZXIge1xuICBwcml2YXRlIHF1ZXVlOiB7IGhhbmRsZTogc3RyaW5nOyByZXNvbHZlOiAocjogTG9va3VwUmVzdWx0KSA9PiB2b2lkIH1bXSA9IFtdO1xuICBwcml2YXRlIHBlbmRpbmcgPSBuZXcgTWFwPHN0cmluZywgUHJvbWlzZTxMb29rdXBSZXN1bHQ+PigpO1xuICBwcml2YXRlIHJ1bm5pbmcgPSBmYWxzZTtcbiAgcHJpdmF0ZSByZXN1bWVBdCA9IDA7XG4gIHByaXZhdGUgbm93OiAoKSA9PiBudW1iZXI7XG4gIHByaXZhdGUgc2xlZXA6IChtczogbnVtYmVyKSA9PiBQcm9taXNlPHZvaWQ+O1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgZDogRmV0Y2hlckRlcHMpIHtcbiAgICB0aGlzLm5vdyA9IGQubm93ID8/IERhdGUubm93O1xuICAgIHRoaXMuc2xlZXAgPSBkLnNsZWVwID8/ICgobXMpID0+IG5ldyBQcm9taXNlKChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSkpO1xuICB9XG5cbiAgbG9va3VwKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxMb29rdXBSZXN1bHQ+IHtcbiAgICBjb25zdCBrZXkgPSBoYW5kbGUudG9Mb3dlckNhc2UoKTtcbiAgICBjb25zdCBleGlzdGluZyA9IHRoaXMucGVuZGluZy5nZXQoa2V5KTtcbiAgICBpZiAoZXhpc3RpbmcpIHJldHVybiBleGlzdGluZztcbiAgICBjb25zdCBwID0gbmV3IFByb21pc2U8TG9va3VwUmVzdWx0PigocmVzb2x2ZSkgPT4gdGhpcy5xdWV1ZS5wdXNoKHsgaGFuZGxlLCByZXNvbHZlIH0pKTtcbiAgICB0aGlzLnBlbmRpbmcuc2V0KGtleSwgcCk7XG4gICAgcC5maW5hbGx5KCgpID0+IHRoaXMucGVuZGluZy5kZWxldGUoa2V5KSk7XG4gICAgdGhpcy5wdW1wKCk7XG4gICAgcmV0dXJuIHA7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHB1bXAoKSB7XG4gICAgaWYgKHRoaXMucnVubmluZykgcmV0dXJuO1xuICAgIHRoaXMucnVubmluZyA9IHRydWU7XG4gICAgdHJ5IHtcbiAgICAgIHdoaWxlICh0aGlzLnF1ZXVlLmxlbmd0aCkge1xuICAgICAgICBjb25zdCB3YWl0ID0gdGhpcy5yZXN1bWVBdCAtIHRoaXMubm93KCk7XG4gICAgICAgIGlmICh3YWl0ID4gMCkgYXdhaXQgdGhpcy5zbGVlcCh3YWl0KTtcbiAgICAgICAgY29uc3Qgam9iID0gdGhpcy5xdWV1ZS5zaGlmdCgpITtcbiAgICAgICAgY29uc3QgciA9IGF3YWl0IHRoaXMub25jZShqb2IuaGFuZGxlKTtcbiAgICAgICAgaWYgKCFyLm9rICYmIHIuZXJyb3IgPT09ICdyYXRlX2xpbWl0ZWQnKSB7XG4gICAgICAgICAgdGhpcy5xdWV1ZS51bnNoaWZ0KGpvYik7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgam9iLnJlc29sdmUocik7XG4gICAgICAgIHRoaXMucmVzdW1lQXQgPSBNYXRoLm1heCh0aGlzLnJlc3VtZUF0LCB0aGlzLm5vdygpICsgKHRoaXMuZC5nYXBNcyA/PyAxMDAwKSk7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMucnVubmluZyA9IGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgb25jZShoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8TG9va3VwUmVzdWx0PiB7XG4gICAgY29uc3QgdXJsID0gYC9pL2FwaS9ncmFwaHFsLyR7dGhpcy5kLnF1ZXJ5SWQoKX0vJHtBQk9VVF9PUH0/dmFyaWFibGVzPSR7ZW5jb2RlVVJJQ29tcG9uZW50KEpTT04uc3RyaW5naWZ5KHsgc2NyZWVuTmFtZTogaGFuZGxlIH0pKX1gO1xuICAgIGxldCByZXM6IFJlc3BvbnNlO1xuICAgIHRyeSB7XG4gICAgICByZXMgPSBhd2FpdCB0aGlzLmQuZmV0Y2godXJsLCB7IGNyZWRlbnRpYWxzOiAnaW5jbHVkZScsIGhlYWRlcnM6IHRoaXMuZC5oZWFkZXJzKCkgfSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ25ldHdvcmsnIH07XG4gICAgfVxuICAgIGNvbnN0IHJlbWFpbmluZyA9IE51bWJlcihyZXMuaGVhZGVycy5nZXQoJ3gtcmF0ZS1saW1pdC1yZW1haW5pbmcnKSk7XG4gICAgY29uc3QgcmVzZXQgPSBOdW1iZXIocmVzLmhlYWRlcnMuZ2V0KCd4LXJhdGUtbGltaXQtcmVzZXQnKSkgKiAxMDAwO1xuICAgIGNvbnN0IHJlc2V0QXQgPSByZXNldCA+IHRoaXMubm93KCkgPyByZXNldCArIDEwMDAgOiB0aGlzLm5vdygpICsgNjBfMDAwO1xuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MjkpIHtcbiAgICAgIHRoaXMucmVzdW1lQXQgPSByZXNldEF0O1xuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ3JhdGVfbGltaXRlZCcgfTtcbiAgICB9XG4gICAgLy8gS2VlcCBhIGxpdHRsZSBoZWFkcm9vbSBzbyBYJ3Mgb3duIEFib3V0IHBhZ2VzIHN0aWxsIHdvcmsuXG4gICAgaWYgKE51bWJlci5pc0Zpbml0ZShyZW1haW5pbmcpICYmIHJlcy5oZWFkZXJzLmhhcygneC1yYXRlLWxpbWl0LXJlbWFpbmluZycpICYmIHJlbWFpbmluZyA8PSAyKSB0aGlzLnJlc3VtZUF0ID0gcmVzZXRBdDtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDAwIHx8IHJlcy5zdGF0dXMgPT09IDQwNCkgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ3N0YWxlX3F1ZXJ5JyB9O1xuICAgIGlmICghcmVzLm9rKSByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiBgaHR0cF8ke3Jlcy5zdGF0dXN9YCB9O1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4geyBvazogdHJ1ZSwgaW5mbzogcGFyc2VBYm91dChhd2FpdCByZXMuanNvbigpKSB9O1xuICAgIH0gY2F0Y2gge1xuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ2JhZF9qc29uJyB9O1xuICAgIH1cbiAgfVxufVxuIiwgImltcG9ydCB7IGNvbWJpbmUsIHR5cGUgQ29tYmluZWQgfSBmcm9tICcuL2NvbWJpbmUnO1xuaW1wb3J0IHsgaXNBbGxvd2VkLCBpc0ZyZXNoIH0gZnJvbSAnLi9jb3VudHJ5JztcbmltcG9ydCB7IGF1dGhvclNjb3JlLCBuZXdBdXRob3IsIG5vcm1IYW5kbGUsIHR5cGUgU3RvcmUgfSBmcm9tICcuL2RiJztcbmltcG9ydCB0eXBlIHsgU2NvcmluZ0NsaWVudCB9IGZyb20gJy4vc2NvcmluZyc7XG5pbXBvcnQgdHlwZSB7IERlY2lzaW9uLCBQb3N0LCBQb3N0UmVjb3JkLCBRdWVzdGlvbnNDb25maWcsIFRocmVzaG9sZHMsIFZlcmRpY3QgfSBmcm9tICcuL3R5cGVzJztcblxuZXhwb3J0IGludGVyZmFjZSBCdWRnZXQge1xuICAvKiogRmFsc2Ugb25jZSB0b2RheSdzIHRva2VuIGJ1ZGdldCBpcyB1c2VkIHVwLiAqL1xuICBjYW5TcGVuZCgpOiBQcm9taXNlPGJvb2xlYW4+O1xuICByZWNvcmQoaW5wdXRUb2tlbnM6IG51bWJlciwgZGVjaXNpb24/OiBEZWNpc2lvbik6IFByb21pc2U8dm9pZD47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgU2NvcmVyT3B0aW9ucyB7XG4gIHN0b3JlOiBTdG9yZTtcbiAgLyoqIFJldHVybnMgdW5kZWZpbmVkIHdoZW4gbm8gQVBJIGtleSBpcyBjb25maWd1cmVkLiAqL1xuICBjbGllbnQ6ICgpID0+IFNjb3JpbmdDbGllbnQgfCB1bmRlZmluZWQ7XG4gIGNvbmZpZzogUXVlc3Rpb25zQ29uZmlnO1xuICB0aHJlc2hvbGRzOiAoKSA9PiBUaHJlc2hvbGRzO1xuICAvKiogXCJBY2NvdW50IGJhc2VkIGluXCIgdmFsdWVzIHRoYXQgYXJlIG5ldmVyIGZpbHRlcmVkLiAqL1xuICBhbGxvd2VkQ291bnRyaWVzPzogKCkgPT4gc3RyaW5nW107XG4gIC8qKiBMb2FkcyBhIHBvc3QncyBwaG90b3MgYXMgZGF0YSBVUkxzOyBvbWl0IG9yIHJldHVybiBbXSB0byBzY29yZSB0ZXh0IG9ubHkuICovXG4gIGltYWdlcz86IChwb3N0OiBQb3N0KSA9PiBQcm9taXNlPHN0cmluZ1tdPjtcbiAgYnVkZ2V0OiBCdWRnZXQ7XG4gIC8qKiBNYXggZDEgcmVxdWVzdHMgaW4gZmxpZ2h0LiBkMSB0YWtlcyBvbmUgcG9zdCBwZXIgcmVxdWVzdCwgc28gdGhpcyBpcyB0aGUgXCJiYXRjaCBzaXplXCIuICovXG4gIGNvbmN1cnJlbmN5PzogbnVtYmVyO1xuICAvKiogUXVldWVkIHBvc3RzIGFyZSBkaXNwYXRjaGVkIGF0IGxlYXN0IHRoaXMgb2Z0ZW4uICovXG4gIGZsdXNoTXM/OiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBKb2Ige1xuICBwb3N0OiBQb3N0O1xuICAvKiogVHJ1ZSB3aGVuIHJlLXNjb3JpbmcgYSBwb3N0IGNhY2hlZCB1bmRlciBvbGRlciBxdWVzdGlvbnM7IHRoZSBhdXRob3Igd2FzIGFscmVhZHkgY291bnRlZC4gKi9cbiAgcmVzY29yZTogYm9vbGVhbjtcbiAgcmVzb2x2ZTogKHY6IFZlcmRpY3QpID0+IHZvaWQ7XG59XG5cbi8qKiBDYWNoZSBcdTIxOTIgc2VlZGVkLWF1dGhvciBzaG9ydC1jaXJjdWl0IFx1MjE5MiBidWRnZXQgXHUyMTkyIHF1ZXVlZCBkMSBjYWxsIFx1MjE5MiBzdG9yZS4gKi9cbmV4cG9ydCBjbGFzcyBTY29yZXIge1xuICBwcml2YXRlIHF1ZXVlOiBKb2JbXSA9IFtdO1xuICBwcml2YXRlIGluZmxpZ2h0ID0gbmV3IE1hcDxzdHJpbmcsIFByb21pc2U8VmVyZGljdD4+KCk7XG4gIHByaXZhdGUgYWN0aXZlID0gMDtcbiAgcHJpdmF0ZSB0aW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCB1bmRlZmluZWQ7XG4gIHByaXZhdGUgY29uY3VycmVuY3k6IG51bWJlcjtcbiAgcHJpdmF0ZSBmbHVzaE1zOiBudW1iZXI7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBvOiBTY29yZXJPcHRpb25zKSB7XG4gICAgdGhpcy5jb25jdXJyZW5jeSA9IG8uY29uY3VycmVuY3kgPz8gNjtcbiAgICB0aGlzLmZsdXNoTXMgPSBvLmZsdXNoTXMgPz8gMzAwO1xuICB9XG5cbiAgZGVjaWRlKHBvc3Q6IFBvc3QpOiBQcm9taXNlPFZlcmRpY3Q+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IHRoaXMuaW5mbGlnaHQuZ2V0KHBvc3QuaWQpO1xuICAgIGlmIChleGlzdGluZykgcmV0dXJuIGV4aXN0aW5nO1xuICAgIGNvbnN0IHAgPSB0aGlzLmRlY2lkZVVuY2FjaGVkKHBvc3QpLmZpbmFsbHkoKCkgPT4gdGhpcy5pbmZsaWdodC5kZWxldGUocG9zdC5pZCkpO1xuICAgIHRoaXMuaW5mbGlnaHQuc2V0KHBvc3QuaWQsIHApO1xuICAgIHJldHVybiBwO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBkZWNpZGVVbmNhY2hlZChwb3N0OiBQb3N0KTogUHJvbWlzZTxWZXJkaWN0PiB7XG4gICAgY29uc3QgY2FjaGVkID0gYXdhaXQgdGhpcy5vLnN0b3JlLmdldFBvc3QocG9zdC5pZCk7XG4gICAgLy8gU2VlZGVkIGRlY2lzaW9ucyBkb24ndCBkZXBlbmQgb24gdGhlIHF1ZXN0aW9uczsgZDEgc2NvcmVzIGRvLCBzbyByZS1zY29yZSB3aGVuIHRoZSBxdWVzdGlvbiBzZXQgY2hhbmdlZC5cbiAgICBpZiAoY2FjaGVkICYmIChjYWNoZWQucmVhc29uID09PSAnc2VlZGVkJyB8fCBjYWNoZWQucXVlc3Rpb25zVmVyc2lvbiA9PT0gdGhpcy5vLmNvbmZpZy52ZXJzaW9uKSkge1xuICAgICAgcmV0dXJuIHRoaXMudmVyZGljdEZvcihjYWNoZWQsICdjYWNoZScpO1xuICAgIH1cblxuICAgIGNvbnN0IHNlZWRlZEJ5ID0gYXdhaXQgdGhpcy5zZWVkZWRBdXRob3IocG9zdCk7XG4gICAgaWYgKHNlZWRlZEJ5KSB7XG4gICAgICBjb25zdCByZWM6IFBvc3RSZWNvcmQgPSB7XG4gICAgICAgIC4uLnRoaXMuYmFzZVJlY29yZChwb3N0KSxcbiAgICAgICAgcHJvYnM6IHt9LFxuICAgICAgICBzY29yZTogMSxcbiAgICAgICAgZGVjaXNpb246ICdoaWRlJyxcbiAgICAgICAgcmVhc29uOiAnc2VlZGVkJyxcbiAgICAgIH07XG4gICAgICBhd2FpdCB0aGlzLm8uc3RvcmUucHV0UG9zdChyZWMpO1xuICAgICAgYXdhaXQgdGhpcy5vLnN0b3JlLmFkZExhYmVsKHsgcG9zdElkOiBwb3N0LmlkLCBsYWJlbDogJ3JhZ2ViYWl0Jywgc291cmNlOiAnYWNjb3VudF9zZWVkJywgYXQ6IERhdGUubm93KCkgfSk7XG4gICAgICBhd2FpdCB0aGlzLmJ1bXBBdXRob3IocG9zdC5hdXRob3IpO1xuICAgICAgcmV0dXJuIHRoaXMudmVyZGljdEZvcihyZWMsICdzZWVkZWQnKTtcbiAgICB9XG5cbiAgICAvLyBBdXRob3JzIGFscmVhZHkga25vd24gdG8gYmUgYmFzZWQgaW4gYW4gYWxsb3dlZCBjb3VudHJ5IG5ldmVyIG5lZWQgZDEuXG4gICAgY29uc3QgY291bnRyeSA9IHBvc3QuYXV0aG9yID8gYXdhaXQgdGhpcy5vLnN0b3JlLmdldENvdW50cnkobm9ybUhhbmRsZShwb3N0LmF1dGhvcikpIDogdW5kZWZpbmVkO1xuICAgIGlmIChpc0ZyZXNoKGNvdW50cnkpICYmIGlzQWxsb3dlZChjb3VudHJ5LmNvdW50cnksIHRoaXMuYWxsb3dlZCgpKSkge1xuICAgICAgcmV0dXJuIHsgcG9zdElkOiBwb3N0LmlkLCBkZWNpc2lvbjogJ3Nob3cnLCByZWFzb246ICdjb3VudHJ5JywgYXV0aG9yOiBub3JtSGFuZGxlKHBvc3QuYXV0aG9yISksIGNvdW50cnk6IGNvdW50cnkuY291bnRyeSB9O1xuICAgIH1cblxuICAgIGlmICghdGhpcy5vLmNsaWVudCgpKSByZXR1cm4geyBwb3N0SWQ6IHBvc3QuaWQsIGRlY2lzaW9uOiAndW5zY29yZWQnLCByZWFzb246ICdub19rZXknIH07XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlPFZlcmRpY3Q+KChyZXNvbHZlKSA9PiB7XG4gICAgICB0aGlzLnF1ZXVlLnB1c2goeyBwb3N0LCByZXNjb3JlOiAhIWNhY2hlZCwgcmVzb2x2ZSB9KTtcbiAgICAgIGlmICh0aGlzLnF1ZXVlLmxlbmd0aCA+PSB0aGlzLmNvbmN1cnJlbmN5KSB0aGlzLmZsdXNoKCk7XG4gICAgICBlbHNlIHRoaXMudGltZXIgPz89IHNldFRpbWVvdXQoKCkgPT4gdGhpcy5mbHVzaCgpLCB0aGlzLmZsdXNoTXMpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBmbHVzaCgpIHtcbiAgICBjbGVhclRpbWVvdXQodGhpcy50aW1lcik7XG4gICAgdGhpcy50aW1lciA9IHVuZGVmaW5lZDtcbiAgICB3aGlsZSAodGhpcy5hY3RpdmUgPCB0aGlzLmNvbmN1cnJlbmN5ICYmIHRoaXMucXVldWUubGVuZ3RoKSB7XG4gICAgICBjb25zdCBqb2IgPSB0aGlzLnF1ZXVlLnNoaWZ0KCkhO1xuICAgICAgdGhpcy5hY3RpdmUrKztcbiAgICAgIHRoaXMucnVuKGpvYi5wb3N0LCBqb2IucmVzY29yZSlcbiAgICAgICAgLmNhdGNoKCgpOiBWZXJkaWN0ID0+ICh7IHBvc3RJZDogam9iLnBvc3QuaWQsIGRlY2lzaW9uOiAndW5zY29yZWQnLCByZWFzb246ICdlcnJvcicgfSkpXG4gICAgICAgIC50aGVuKGpvYi5yZXNvbHZlKVxuICAgICAgICAuZmluYWxseSgoKSA9PiB7XG4gICAgICAgICAgdGhpcy5hY3RpdmUtLTtcbiAgICAgICAgICBpZiAodGhpcy5xdWV1ZS5sZW5ndGgpIHRoaXMuZmx1c2goKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBydW4ocG9zdDogUG9zdCwgcmVzY29yZTogYm9vbGVhbik6IFByb21pc2U8VmVyZGljdD4ge1xuICAgIGNvbnN0IGNsaWVudCA9IHRoaXMuby5jbGllbnQoKTtcbiAgICBpZiAoIWNsaWVudCkgcmV0dXJuIHsgcG9zdElkOiBwb3N0LmlkLCBkZWNpc2lvbjogJ3Vuc2NvcmVkJywgcmVhc29uOiAnbm9fa2V5JyB9O1xuICAgIGlmICghKGF3YWl0IHRoaXMuby5idWRnZXQuY2FuU3BlbmQoKSkpIHJldHVybiB7IHBvc3RJZDogcG9zdC5pZCwgZGVjaXNpb246ICd1bnNjb3JlZCcsIHJlYXNvbjogJ2J1ZGdldCcgfTtcbiAgICAvLyBBIGZhaWxlZCBpbWFnZSBkb3dubG9hZCBkZWdyYWRlcyB0byB0ZXh0LW9ubHkgc2NvcmluZy5cbiAgICBjb25zdCBpbWFnZXMgPSBwb3N0LmltYWdlVXJscz8ubGVuZ3RoICYmIHRoaXMuby5pbWFnZXMgPyBhd2FpdCB0aGlzLm8uaW1hZ2VzKHBvc3QpLmNhdGNoKCgpID0+IFtdKSA6IFtdO1xuICAgIGNvbnN0IHsgcHJvYnMsIGlucHV0VG9rZW5zIH0gPSBhd2FpdCBjbGllbnQuc2NvcmUocG9zdCwgdGhpcy5vLmNvbmZpZy5xdWVzdGlvbnMsIGltYWdlcyk7XG4gICAgY29uc3QgYyA9IGNvbWJpbmUocHJvYnMsIHRoaXMuby5jb25maWcsIHRoaXMuby50aHJlc2hvbGRzKCkpO1xuICAgIGNvbnN0IHJlYzogUG9zdFJlY29yZCA9IHsgLi4udGhpcy5iYXNlUmVjb3JkKHBvc3QpLCBwcm9icywgc2NvcmU6IGMuc2NvcmUsIGRlY2lzaW9uOiBjLmRlY2lzaW9uLCByZWFzb246ICdkMScgfTtcbiAgICBhd2FpdCB0aGlzLm8uc3RvcmUucHV0UG9zdChyZWMpO1xuICAgIGF3YWl0IHRoaXMuby5idWRnZXQucmVjb3JkKGlucHV0VG9rZW5zLCBjLmRlY2lzaW9uKTtcbiAgICBpZiAoIXJlc2NvcmUpIGF3YWl0IHRoaXMuYnVtcEF1dGhvcihwb3N0LmF1dGhvciwgYy5zY29yZSk7XG4gICAgcmV0dXJuIHRoaXMudmVyZGljdEZvcihyZWMsICdkMScpO1xuICB9XG5cbiAgLyoqXG4gICAqIEEgcG9zdCB0aGF0IGVuZG9yc2VzIGEgYmFpdCBxdW90ZSAoXCJ0aGlzIFx1RDgzRFx1REM0NiBzbyB0cnVlXCIpIGluaGVyaXRzIHRoZSBxdW90ZSdzIHNjb3JlLiBUaGUgc3RhbmNlIGlzXG4gICAqIG9ubHkgYXNrZWQgb25jZSB0aGUgcXVvdGVkIHBvc3QgaGFzIGJlZW4gc2NvcmVkIGFzIGJhaXQ7IHVudGlsIHRoZW4gdGhlIHBvc3QncyBvd24gc2NvcmUgc3RhbmRzXG4gICAqICh0aGUgY29udGVudCBzY3JpcHQgcmUtYXNrcyB3aGVuIHRoZSBxdW90ZSdzIHZlcmRpY3QgYXJyaXZlcykuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIHdpdGhFbmRvcnNlZFF1b3RlKHJlYzogUG9zdFJlY29yZCwgb3duOiBDb21iaW5lZCk6IFByb21pc2U8Q29tYmluZWQ+IHtcbiAgICBjb25zdCBzdGFuY2UgPSB0aGlzLm8uY29uZmlnLnN0YW5jZTtcbiAgICBpZiAoIXN0YW5jZSB8fCAhcmVjLnF1b3RlZElkIHx8ICFyZWMucXVvdGVkVGV4dCkgcmV0dXJuIG93bjtcbiAgICBjb25zdCBxdW90ZWQgPSBhd2FpdCB0aGlzLm8uc3RvcmUuZ2V0UG9zdChyZWMucXVvdGVkSWQpO1xuICAgIGlmICghcXVvdGVkIHx8IHF1b3RlZC5xdWVzdGlvbnNWZXJzaW9uICE9PSB0aGlzLm8uY29uZmlnLnZlcnNpb24pIHJldHVybiBvd247XG4gICAgY29uc3QgdCA9IHRoaXMuby50aHJlc2hvbGRzKCk7XG4gICAgY29uc3QgcSA9IHF1b3RlZC5yZWFzb24gPT09ICdzZWVkZWQnID8geyBzY29yZTogMSwgZGVjaXNpb246ICdoaWRlJyBhcyBjb25zdCB9IDogY29tYmluZShxdW90ZWQucHJvYnMsIHRoaXMuby5jb25maWcsIHQpO1xuICAgIGlmIChxLnNjb3JlIDwgdC5ibHVyIHx8IHEuc2NvcmUgPD0gb3duLnNjb3JlKSByZXR1cm4gb3duO1xuICAgIGlmIChyZWMuZW5kb3JzZXNRdW90ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICBjb25zdCBwID0gYXdhaXQgdGhpcy5hc2tTdGFuY2UocmVjKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuICAgICAgaWYgKHAgPT09IHVuZGVmaW5lZCkgcmV0dXJuIG93bjtcbiAgICAgIHJlYy5lbmRvcnNlc1F1b3RlID0gcDtcbiAgICAgIGF3YWl0IHRoaXMuby5zdG9yZS5wdXRQb3N0KHJlYyk7XG4gICAgfVxuICAgIGlmIChyZWMuZW5kb3JzZXNRdW90ZSA+PSBzdGFuY2UudGhyZXNob2xkKSByZXR1cm4geyBzY29yZTogcS5zY29yZSwgZGVjaXNpb246IHEuZGVjaXNpb24sIHRvcFF1ZXN0aW9uOiAnZW5kb3JzZXNfcXVvdGUnIH07XG4gICAgLy8gUmVwbHlpbmcgYWdhaW5zdCBhIGJhaXQgcXVvdGUgKFwiZW5nYWdlbWVudCBiYWl0LCBkb24ndCByZXBseVwiKTogc2hvcnQgcmVidXR0YWxzIHJlYWQgYXMgYmFpdC1pc2ggb3V0IG9mXG4gICAgLy8gY29udGV4dCwgc28gdGhlIGF1dGhvcidzIG93biB3b3JkcyBvbmx5IGNvdW50IHdoZW4gdGhleSBjbGVhciB0aGUgaGlkZSB0aHJlc2hvbGQgb24gdGhlaXIgb3duLlxuICAgIHJldHVybiBvd24uZGVjaXNpb24gPT09ICdoaWRlJyA/IG93biA6IHsgLi4ub3duLCBkZWNpc2lvbjogJ3Nob3cnIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGFza1N0YW5jZShyZWM6IFBvc3RSZWNvcmQpOiBQcm9taXNlPG51bWJlciB8IHVuZGVmaW5lZD4ge1xuICAgIGNvbnN0IGNsaWVudCA9IHRoaXMuby5jbGllbnQoKTtcbiAgICBjb25zdCBzdGFuY2UgPSB0aGlzLm8uY29uZmlnLnN0YW5jZSE7XG4gICAgaWYgKCFjbGllbnQgfHwgIShhd2FpdCB0aGlzLm8uYnVkZ2V0LmNhblNwZW5kKCkpKSByZXR1cm4gdW5kZWZpbmVkO1xuICAgIGNvbnN0IHN0YXRlID0geyBpZDogcmVjLmlkLCB0ZXh0OiBgJHtyZWMudGV4dH1cXG5cXG5bUXVvdGVkIHBvc3RdXFxuJHtyZWMucXVvdGVkVGV4dH1gLCBpc1JlcGx5OiBmYWxzZSB9O1xuICAgIGNvbnN0IHsgcHJvYnMsIGlucHV0VG9rZW5zIH0gPSBhd2FpdCBjbGllbnQuc2NvcmUoc3RhdGUsIFtzdGFuY2VdKTtcbiAgICBhd2FpdCB0aGlzLm8uYnVkZ2V0LnJlY29yZChpbnB1dFRva2Vucyk7XG4gICAgcmV0dXJuIHByb2JzW3N0YW5jZS5pZF07XG4gIH1cblxuICBwcml2YXRlIGFsbG93ZWQoKTogc3RyaW5nW10ge1xuICAgIHJldHVybiB0aGlzLm8uYWxsb3dlZENvdW50cmllcz8uKCkgPz8gWydVbml0ZWQgU3RhdGVzJ107XG4gIH1cblxuICBwcml2YXRlIGJhc2VSZWNvcmQocG9zdDogUG9zdCkge1xuICAgIHJldHVybiB7XG4gICAgICBpZDogcG9zdC5pZCxcbiAgICAgIHRleHQ6IHBvc3QudGV4dCxcbiAgICAgIHF1b3RlZFRleHQ6IHBvc3QucXVvdGVkVGV4dCxcbiAgICAgIHF1b3RlZElkOiBwb3N0LnF1b3RlZElkLFxuICAgICAgYXV0aG9yOiBwb3N0LmF1dGhvciA/IG5vcm1IYW5kbGUocG9zdC5hdXRob3IpIDogdW5kZWZpbmVkLFxuICAgICAgc2VlbkF0OiBEYXRlLm5vdygpLFxuICAgICAgcXVlc3Rpb25zVmVyc2lvbjogdGhpcy5vLmNvbmZpZy52ZXJzaW9uLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHNlZWRlZEF1dGhvcihwb3N0OiBQb3N0KTogUHJvbWlzZTxzdHJpbmcgfCB1bmRlZmluZWQ+IHtcbiAgICAvLyBBIHF1b3RlIHdpdGggYSBrbm93biBpZCBpcyBkZWNpZGVkIG9uIGl0cyBvd24gKGFuZCBvbmx5IGl0cyBib3ggaXMgYmx1cnJlZCkuXG4gICAgZm9yIChjb25zdCBoIG9mIFtwb3N0LmF1dGhvciwgcG9zdC5xdW90ZWRJZCA/IHVuZGVmaW5lZCA6IHBvc3QucXVvdGVkQXV0aG9yXSkge1xuICAgICAgaWYgKCFoKSBjb250aW51ZTtcbiAgICAgIGNvbnN0IGEgPSBhd2FpdCB0aGlzLm8uc3RvcmUuZ2V0QXV0aG9yKG5vcm1IYW5kbGUoaCkpO1xuICAgICAgaWYgKGE/LnNlZWRlZCkgcmV0dXJuIGEuaGFuZGxlO1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBidW1wQXV0aG9yKGhhbmRsZTogc3RyaW5nIHwgdW5kZWZpbmVkLCBzY29yZT86IG51bWJlcikge1xuICAgIGlmICghaGFuZGxlKSByZXR1cm47XG4gICAgY29uc3QgaCA9IG5vcm1IYW5kbGUoaGFuZGxlKTtcbiAgICBjb25zdCBhID0gKGF3YWl0IHRoaXMuby5zdG9yZS5nZXRBdXRob3IoaCkpID8/IG5ld0F1dGhvcihoKTtcbiAgICBhLnBvc3RzU2VlbisrO1xuICAgIGlmIChzY29yZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBhLmFscGhhICs9IHNjb3JlO1xuICAgICAgYS5iZXRhICs9IDEgLSBzY29yZTtcbiAgICB9XG4gICAgYXdhaXQgdGhpcy5vLnN0b3JlLnB1dEF1dGhvcihhKTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgdmVyZGljdEZvcihyZWM6IFBvc3RSZWNvcmQsIHJlYXNvbjogVmVyZGljdFsncmVhc29uJ10pOiBQcm9taXNlPFZlcmRpY3Q+IHtcbiAgICAvLyBSZS1kZXJpdmUgdGhlIGRlY2lzaW9uIGZyb20gc3RvcmVkIHByb2JhYmlsaXRpZXMgc28gdGhyZXNob2xkIGVkaXRzIGFwcGx5IHRvIGNhY2hlZCBwb3N0cy5cbiAgICBjb25zdCBjID0gcmVjLnJlYXNvbiA9PT0gJ3NlZWRlZCcgPyB1bmRlZmluZWQgOiBhd2FpdCB0aGlzLndpdGhFbmRvcnNlZFF1b3RlKHJlYywgY29tYmluZShyZWMucHJvYnMsIHRoaXMuby5jb25maWcsIHRoaXMuby50aHJlc2hvbGRzKCkpKTtcbiAgICBjb25zdCBhdXRob3IgPSByZWMuYXV0aG9yID8gYXdhaXQgdGhpcy5vLnN0b3JlLmdldEF1dGhvcihyZWMuYXV0aG9yKSA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCB2OiBWZXJkaWN0ID0ge1xuICAgICAgcG9zdElkOiByZWMuaWQsXG4gICAgICBkZWNpc2lvbjogYz8uZGVjaXNpb24gPz8gcmVjLmRlY2lzaW9uLFxuICAgICAgc2NvcmU6IGM/LnNjb3JlID8/IHJlYy5zY29yZSxcbiAgICAgIHRvcFF1ZXN0aW9uOiByZWMucmVhc29uID09PSAnc2VlZGVkJyA/ICdzZWVkZWRfYXV0aG9yJyA6IGM/LnRvcFF1ZXN0aW9uLFxuICAgICAgYXV0aG9yOiByZWMuYXV0aG9yLFxuICAgICAgYXV0aG9yU2NvcmU6IGF1dGhvciA/IGF1dGhvclNjb3JlKGF1dGhvcikgOiB1bmRlZmluZWQsXG4gICAgICByZWFzb24sXG4gICAgfTtcbiAgICAvLyBUaGUgdG9waWMgZmlyZWQ6IG9ubHkgZmlsdGVyIHdoZW4gdGhlIGF1dGhvciBpcyBiYXNlZCBvdXRzaWRlIHRoZSBhbGxvd2VkIGNvdW50cmllcy5cbiAgICBpZiAoYyAmJiB2LmRlY2lzaW9uICE9PSAnc2hvdycpIHtcbiAgICAgIGlmICghcmVjLmF1dGhvcikgcmV0dXJuIHsgLi4udiwgZGVjaXNpb246ICdzaG93JyB9O1xuICAgICAgY29uc3QgY291bnRyeSA9IGF3YWl0IHRoaXMuby5zdG9yZS5nZXRDb3VudHJ5KHJlYy5hdXRob3IpO1xuICAgICAgaWYgKCFpc0ZyZXNoKGNvdW50cnkpKSByZXR1cm4geyAuLi52LCBkZWNpc2lvbjogJ3Vuc2NvcmVkJywgbmVlZHNDb3VudHJ5OiByZWMuYXV0aG9yIH07XG4gICAgICB2LmNvdW50cnkgPSBjb3VudHJ5LmNvdW50cnk7XG4gICAgICBpZiAoIWNvdW50cnkuY291bnRyeSB8fCBpc0FsbG93ZWQoY291bnRyeS5jb3VudHJ5LCB0aGlzLmFsbG93ZWQoKSkpIHYuZGVjaXNpb24gPSAnc2hvdyc7XG4gICAgfVxuICAgIHJldHVybiB2O1xuICB9XG59XG4iLCAiaW1wb3J0IHR5cGUgeyBQb3N0LCBRdWVzdGlvbiB9IGZyb20gJy4vdHlwZXMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFNjb3JlUmVzdWx0IHtcbiAgcHJvYnM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj47XG4gIGlucHV0VG9rZW5zOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgU2NvcmluZ0NsaWVudCB7XG4gIC8qKiBgaW1hZ2VzYCBhcmUgYmFzZTY0IGRhdGEgVVJMcyAoZDEgZG9lcyBub3QgYWNjZXB0IHJlbW90ZSBVUkxzKS4gKi9cbiAgc2NvcmUocG9zdDogUG9zdCwgcXVlc3Rpb25zOiBRdWVzdGlvbltdLCBpbWFnZXM/OiBzdHJpbmdbXSk6IFByb21pc2U8U2NvcmVSZXN1bHQ+O1xufVxuXG5leHBvcnQgY29uc3QgRDFfRU5EUE9JTlQgPSAnaHR0cHM6Ly9hcGkubGlxdWlkLmFpL2RlY2lzaW9ucy92MS9zeXN0ZW1vbmUnO1xuXG4vKiogVGV4dCBzZW50IHRvIHRoZSBtb2RlbCBhcyBgc3RhdGVgLiBBIHF1b3RlIHdpdGggYSBrbm93biBpZCBpcyBzY29yZWQgb24gaXRzIG93biwgc28gaXQgaXMgbGVmdCBvdXQuICovXG5leHBvcnQgZnVuY3Rpb24gcG9zdFRvU3RhdGUocG9zdDogUG9zdCk6IHN0cmluZyB7XG4gIGxldCBzID0gcG9zdC50ZXh0O1xuICBpZiAocG9zdC5xdW90ZWRUZXh0ICYmICFwb3N0LnF1b3RlZElkKSBzICs9IGBcXG5cXG5bUXVvdGluZyR7cG9zdC5xdW90ZWRBdXRob3IgPyAnIEAnICsgcG9zdC5xdW90ZWRBdXRob3IgOiAnJ31dXFxuJHtwb3N0LnF1b3RlZFRleHR9YDtcbiAgcmV0dXJuIHM7XG59XG5cbi8qKiBGZXRjaGVzIGFuIGltYWdlIGFuZCByZXR1cm5zIGl0IGFzIGEgZGF0YSBVUkwuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaW1hZ2VUb0RhdGFVcmwodXJsOiBzdHJpbmcsIGZldGNoSW1wbDogdHlwZW9mIGZldGNoID0gKC4uLmEpID0+IGZldGNoKC4uLmEpKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2hJbXBsKHVybCk7XG4gIGlmICghcmVzLm9rKSB0aHJvdyBuZXcgRXJyb3IoYGltYWdlIEhUVFAgJHtyZXMuc3RhdHVzfWApO1xuICBjb25zdCB0eXBlID0gcmVzLmhlYWRlcnMuZ2V0KCdjb250ZW50LXR5cGUnKT8uc3BsaXQoJzsnKVswXSB8fCAnaW1hZ2UvanBlZyc7XG4gIGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgcmVzLmFycmF5QnVmZmVyKCkpO1xuICBsZXQgYmluID0gJyc7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoOyBpICs9IDB4ODAwMCkgYmluICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoLi4uYnl0ZXMuc3ViYXJyYXkoaSwgaSArIDB4ODAwMCkpO1xuICByZXR1cm4gYGRhdGE6JHt0eXBlfTtiYXNlNjQsJHtidG9hKGJpbil9YDtcbn1cblxuLyoqXG4gKiBMaXF1aWQgQUkgZDEgKGh0dHBzOi8vZG9jcy5saXF1aWQuYWkvbGZtL21vZGVscy9kMSkuIE9uZSBgc3RhdGVgIHBlciByZXF1ZXN0OyBhbGxcbiAqIHF1ZXN0aW9ucyBnbyBpbiBvbmUgY2FsbCBhcyBgbm91bGAgKHllcy9ubykgcXVlc3Rpb25zLCBlYWNoIGFuc3dlcmVkIHdpdGggUCh5ZXMpLlxuICovXG5leHBvcnQgY2xhc3MgRDFDbGllbnQgaW1wbGVtZW50cyBTY29yaW5nQ2xpZW50IHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBhcGlLZXk6IHN0cmluZyxcbiAgICBwcml2YXRlIG1vZGVsID0gJ2QxLjEnLFxuICAgIHByaXZhdGUgZmV0Y2hJbXBsOiB0eXBlb2YgZmV0Y2ggPSAoLi4uYSkgPT4gZmV0Y2goLi4uYSksXG4gICkge31cblxuICBhc3luYyBzY29yZShwb3N0OiBQb3N0LCBxdWVzdGlvbnM6IFF1ZXN0aW9uW10sIGltYWdlczogc3RyaW5nW10gPSBbXSk6IFByb21pc2U8U2NvcmVSZXN1bHQ+IHtcbiAgICBjb25zdCBib2R5ID0ge1xuICAgICAgbW9kZWw6IHRoaXMubW9kZWwsXG4gICAgICBzdGF0ZTogcG9zdFRvU3RhdGUocG9zdCksXG4gICAgICAuLi4oaW1hZ2VzLmxlbmd0aCA/IHsgaW1hZ2VzIH0gOiB7fSksXG4gICAgICBxdWVzdGlvbnM6IE9iamVjdC5mcm9tRW50cmllcyhxdWVzdGlvbnMubWFwKChxKSA9PiBbcS5pZCwgeyB0eXBlOiAnbm91bCcsIGluc3RydWN0aW9uczogcS50ZXh0IH1dKSksXG4gICAgfTtcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmZldGNoSW1wbChEMV9FTkRQT0lOVCwge1xuICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICBoZWFkZXJzOiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLmFwaUtleX1gLCAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShib2R5KSxcbiAgICB9KTtcbiAgICBpZiAoIXJlcy5vaykgdGhyb3cgbmV3IEVycm9yKGBkMSBIVFRQICR7cmVzLnN0YXR1c31gKTtcbiAgICBjb25zdCBqc29uOiBhbnkgPSBhd2FpdCByZXMuanNvbigpO1xuICAgIGNvbnN0IHByb2JzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgZm9yIChjb25zdCBxIG9mIHF1ZXN0aW9ucykge1xuICAgICAgY29uc3QgYSA9IGpzb24/LmFuc3dlcnM/LltxLmlkXTtcbiAgICAgIGlmICh0eXBlb2YgYT8ubm91bCA9PT0gJ251bWJlcicpIHByb2JzW3EuaWRdID0gYS5ub3VsO1xuICAgIH1cbiAgICByZXR1cm4geyBwcm9icywgaW5wdXRUb2tlbnM6IE51bWJlcihqc29uPy51c2FnZT8uaW5wdXRfdG9rZW5zKSB8fCAwIH07XG4gIH1cbn1cbiIsICJ7XG4gIFwidmVyc2lvblwiOiA3LFxuICBcInF1ZXN0aW9uc1wiOiBbXG4gICAge1xuICAgICAgXCJpZFwiOiBcInVzX3BvbGl0aWNzXCIsXG4gICAgICBcInRleHRcIjogXCJJcyB0aGlzIHBvc3QgKGluY2x1ZGluZyBhbnkgdGV4dCBpbiBhdHRhY2hlZCBpbWFnZXMpIGFib3V0IFVuaXRlZCBTdGF0ZXMgcG9saXRpY3MsIGVjb25vbWljcywgb3IgY3VsdHVyZSB3YXIsIHdyaXR0ZW4gYXMgaWYgdGhlIGF1dGhvciBsaXZlcyBpbiB0aGUgVVM/IEV4YW1wbGVzOiBEZW1vY3JhdHMgb3IgUmVwdWJsaWNhbnMsIFVTIHBvbGl0aWNpYW5zLCB0aGUgbWluaW11bSB3YWdlIG9yIHByaWNlcyBpbiBkb2xsYXJzLCByZW50IG9yIHdhZ2VzIGluIFVTIGNpdGllcywgVVMgaGVhbHRoY2FyZSBvciBpbnN1cmFuY2UsIHRheGVzLCBzdHVkZW50IGxvYW5zLCBndW5zLCBpbW1pZ3JhdGlvbiwgb3IgJ2luIHRoaXMgY291bnRyeScgY29tcGxhaW50cyBhYm91dCBBbWVyaWNhLiBBbnN3ZXIgbm8gZm9yIHBvc3RzIHRoYXQgYXJlIG5vdCBhYm91dCB0aGUgVVMsIGFuZCBmb3IgbmV1dHJhbCBuZXdzIHJlcG9ydHMuXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwiaWRcIjogXCJpZGVvbG9neV9iYWl0XCIsXG4gICAgICBcInRleHRcIjogXCJJcyB0aGlzIHBvc3QgKGluY2x1ZGluZyBhbnkgdGV4dCBpbiBhdHRhY2hlZCBpbWFnZXMpIGEgc3dlZXBpbmcsIGxvdy1lZmZvcnQgdGFrZSBkZXNpZ25lZCB0byBmYXJtIHJlcGxpZXMgb24gYSBkaXZpc2l2ZSB0aGVtZSwgc3VjaCBhcyBjYXBpdGFsaXNtIHZzIHNvY2lhbGlzbSwgYmlsbGlvbmFpcmVzIG9yIHRoZSByaWNoLCB0aGUgd29ya2luZyBjbGFzcywgb3IgcmVqZWN0aW5nIG1vZGVybiB0ZWNobm9sb2d5IChcXFwibm9ib2R5IHdhbnRzIHNlbGYtZHJpdmluZyBjYXJzXFxcIiwgQUksIHNtYXJ0cGhvbmVzLCBjYXNobGVzcyBwYXltZW50cyksIHN0YXRlZCBhcyBhIHNsb2dhbiBvciBib2xkIGNsYWltIHJhdGhlciB0aGFuIGEgc3BlY2lmaWMgYXJndW1lbnQ/IEFuc3dlciBubyBmb3Igc3BlY2lmaWMsIHN1YnN0YW50aXZlIGFyZ3VtZW50cywgbmV3cywgb3IgcGVyc29uYWwgYW5lY2RvdGVzIHdpdGhvdXQgYSBwcm92b2NhdGl2ZSBnZW5lcmFsaXphdGlvbi5cIlxuICAgIH1cbiAgXSxcbiAgXCJjb21iaW5lXCI6IHtcbiAgICBcIm1heF9vZlwiOiBbXG4gICAgICBcInVzX3BvbGl0aWNzXCIsXG4gICAgICBcImlkZW9sb2d5X2JhaXRcIlxuICAgIF0sXG4gICAgXCJ3ZWlnaHRlZFwiOiB7fVxuICB9LFxuICBcInRocmVzaG9sZHNcIjoge1xuICAgIFwiaGlkZVwiOiAwLjgsXG4gICAgXCJibHVyXCI6IDAuNVxuICB9LFxuICBcInN0YW5jZVwiOiB7XG4gICAgXCJpZFwiOiBcImVuZG9yc2VzX3F1b3RlXCIsXG4gICAgXCJ0ZXh0XCI6IFwiQSByZXBseS1xdW90ZTogdGhlIGF1dGhvciB3cm90ZSB0aGUgZmlyc3QgcGFydCwgcXVvdGluZyB0aGUgcG9zdCBhZnRlciBbUXVvdGVkIHBvc3RdLiBEb2VzIHRoZSBhdXRob3Igc2lkZSB3aXRoIHRoZSBxdW90ZWQgcG9zdCwgd2FudGluZyByZWFkZXJzIHRvIGFncmVlIHdpdGggaXQ/IEFuc3dlciBubyBpZiB0aGUgYXV0aG9yIGlzIG1vY2tpbmcgaXQsIGFyZ3VpbmcgYWdhaW5zdCBpdCwgY29ycmVjdGluZyBpdCwgd2FybmluZyBwZW9wbGUgYWJvdXQgaXQsIG9yIGNvbW1lbnRpbmcgb24gc29tZXRoaW5nIGVsc2UuXCIsXG4gICAgXCJ0aHJlc2hvbGRcIjogMC44XG4gIH1cbn1cbiIsICJpbXBvcnQgcXVlc3Rpb25zIGZyb20gJy4uL2NvbmZpZy9xdWVzdGlvbnMuanNvbic7XG5pbXBvcnQgdHlwZSB7IERlY2lzaW9uLCBRdWVzdGlvbnNDb25maWcsIFNldHRpbmdzLCBVc2FnZSB9IGZyb20gJy4vdHlwZXMnO1xuXG5leHBvcnQgY29uc3QgUVVFU1RJT05TID0gcXVlc3Rpb25zIGFzIFF1ZXN0aW9uc0NvbmZpZztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFNldHRpbmdzID0ge1xuICBhcGlLZXk6ICcnLFxuICBtb2RlbDogJ2QxLjEnLFxuICB0aHJlc2hvbGRzOiB7IC4uLlFVRVNUSU9OUy50aHJlc2hvbGRzIH0sXG4gIGVuYWJsZWQ6IHsgcGVuZGluZzogdHJ1ZSwgaGlkZTogdHJ1ZSwgYmx1cjogdHJ1ZSwgZmxhZzogdHJ1ZSB9LFxuICBkYWlseVRva2VuQnVkZ2V0OiAxXzAwMF8wMDAsXG4gIGNhcHR1cmVGaXh0dXJlczogZmFsc2UsXG4gIGFsbG93ZWRDb3VudHJpZXM6IFsnVW5pdGVkIFN0YXRlcycsICdOb3J0aCBBbWVyaWNhJ10sXG4gIHNjb3JlSW1hZ2VzOiB0cnVlLFxufTtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gIGNvbnN0IHsgc2V0dGluZ3MgfSA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldCgnc2V0dGluZ3MnKTtcbiAgY29uc3QgcyA9IChzZXR0aW5ncyA/PyB7fSkgYXMgUGFydGlhbDxTZXR0aW5ncz4gJiB7IHRocmVzaG9sZHNGb3I/OiBudW1iZXIgfTtcbiAgLy8gVGhyZXNob2xkcyBhcmUgdHVuZWQgcGVyIHF1ZXN0aW9uIHNldCwgc28gc2F2ZWQgb25lcyBvbmx5IGFwcGx5IHRvIHRoZSB2ZXJzaW9uIHRoZXkgd2VyZSBzYXZlZCB1bmRlci5cbiAgY29uc3Qgc2F2ZWQgPSBzLnRocmVzaG9sZHNGb3IgPT09IFFVRVNUSU9OUy52ZXJzaW9uID8gcy50aHJlc2hvbGRzIDogdW5kZWZpbmVkO1xuICByZXR1cm4ge1xuICAgIC4uLkRFRkFVTFRfU0VUVElOR1MsXG4gICAgLi4ucyxcbiAgICB0aHJlc2hvbGRzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MudGhyZXNob2xkcywgLi4uc2F2ZWQgfSxcbiAgICBlbmFibGVkOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MuZW5hYmxlZCwgLi4ucy5lbmFibGVkIH0sXG4gIH07XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzYXZlU2V0dGluZ3MoczogU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgc2V0dGluZ3M6IHsgLi4ucywgdGhyZXNob2xkc0ZvcjogUVVFU1RJT05TLnZlcnNpb24gfSB9KTtcbn1cblxuZXhwb3J0IGNvbnN0IHRvZGF5ID0gKCkgPT4gbmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcoJ2VuLUNBJyk7XG5cbmV4cG9ydCBjb25zdCBlbXB0eVVzYWdlID0gKCk6IFVzYWdlID0+ICh7IGRhdGU6IHRvZGF5KCksIHRva2VuczogMCwgc2NvcmVkOiAwLCBkZWNpc2lvbnM6IHsgaGlkZTogMCwgYmx1cjogMCwgc2hvdzogMCB9IH0pO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbG9hZFVzYWdlKCk6IFByb21pc2U8VXNhZ2U+IHtcbiAgY29uc3QgeyB1c2FnZSB9ID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KCd1c2FnZScpO1xuICBjb25zdCB1ID0gdXNhZ2UgYXMgVXNhZ2UgfCB1bmRlZmluZWQ7XG4gIHJldHVybiB1ICYmIHUuZGF0ZSA9PT0gdG9kYXkoKSA/IHUgOiBlbXB0eVVzYWdlKCk7XG59XG5cbi8qKiBXaXRob3V0IGEgZGVjaXNpb24gb25seSB0b2tlbnMgYXJlIGNvdW50ZWQgKGUuZy4gdGhlIHF1b3RlLXN0YW5jZSBmb2xsb3ctdXAgY2FsbCkuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVjb3JkVXNhZ2UodG9rZW5zOiBudW1iZXIsIGRlY2lzaW9uPzogRGVjaXNpb24pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdSA9IGF3YWl0IGxvYWRVc2FnZSgpO1xuICB1LnRva2VucyArPSB0b2tlbnM7XG4gIGlmIChkZWNpc2lvbikge1xuICAgIHUuc2NvcmVkKys7XG4gICAgdS5kZWNpc2lvbnNbZGVjaXNpb25dKys7XG4gIH1cbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgdXNhZ2U6IHUgfSk7XG59XG4iLCAiaW1wb3J0IHsgb3BlbkRCIH0gZnJvbSAnaWRiJztcbmltcG9ydCB7IElkYlN0b3JlLCBvcGVuRGIgfSBmcm9tICcuL2RiJztcbmltcG9ydCB7IFNjb3JlciB9IGZyb20gJy4vc2NvcmVyJztcbmltcG9ydCB7IEQxQ2xpZW50LCBpbWFnZVRvRGF0YVVybCB9IGZyb20gJy4vc2NvcmluZyc7XG5pbXBvcnQgeyBERUZBVUxUX1NFVFRJTkdTLCBRVUVTVElPTlMsIGxvYWRTZXR0aW5ncywgbG9hZFVzYWdlLCByZWNvcmRVc2FnZSB9IGZyb20gJy4vc2V0dGluZ3MnO1xuaW1wb3J0IHR5cGUgeyBBYm91dEluZm8gfSBmcm9tICcuL2NvdW50cnknO1xuaW1wb3J0IHR5cGUgeyBMYWJlbFJlY29yZCwgUG9zdCwgU2V0dGluZ3MgfSBmcm9tICcuL3R5cGVzJztcblxubGV0IHNldHRpbmdzOiBTZXR0aW5ncyA9IERFRkFVTFRfU0VUVElOR1M7XG5sZXQgY2xpZW50OiBEMUNsaWVudCB8IHVuZGVmaW5lZDtcblxuY29uc3QgcmVhZHkgPSAoYXN5bmMgKCkgPT4ge1xuICBzZXR0aW5ncyA9IGF3YWl0IGxvYWRTZXR0aW5ncygpO1xuICBjbGllbnQgPSBzZXR0aW5ncy5hcGlLZXkgPyBuZXcgRDFDbGllbnQoc2V0dGluZ3MuYXBpS2V5LCBzZXR0aW5ncy5tb2RlbCkgOiB1bmRlZmluZWQ7XG4gIHJldHVybiBvcGVuRGIoKTtcbn0pKCk7XG5cbmNocm9tZS5zdG9yYWdlLm9uQ2hhbmdlZC5hZGRMaXN0ZW5lcihhc3luYyAoY2hhbmdlcykgPT4ge1xuICBpZiAoIWNoYW5nZXMuc2V0dGluZ3MpIHJldHVybjtcbiAgc2V0dGluZ3MgPSBhd2FpdCBsb2FkU2V0dGluZ3MoKTtcbiAgY2xpZW50ID0gc2V0dGluZ3MuYXBpS2V5ID8gbmV3IEQxQ2xpZW50KHNldHRpbmdzLmFwaUtleSwgc2V0dGluZ3MubW9kZWwpIDogdW5kZWZpbmVkO1xufSk7XG5cbmxldCBzY29yZXI6IFNjb3JlciB8IHVuZGVmaW5lZDtcbmFzeW5jIGZ1bmN0aW9uIGdldFNjb3JlcigpOiBQcm9taXNlPFNjb3Jlcj4ge1xuICBjb25zdCBkYiA9IGF3YWl0IHJlYWR5O1xuICBzY29yZXIgPz89IG5ldyBTY29yZXIoe1xuICAgIHN0b3JlOiBuZXcgSWRiU3RvcmUoZGIpLFxuICAgIGNsaWVudDogKCkgPT4gY2xpZW50LFxuICAgIGNvbmZpZzogUVVFU1RJT05TLFxuICAgIHRocmVzaG9sZHM6ICgpID0+IHNldHRpbmdzLnRocmVzaG9sZHMsXG4gICAgYWxsb3dlZENvdW50cmllczogKCkgPT4gc2V0dGluZ3MuYWxsb3dlZENvdW50cmllcyxcbiAgICBpbWFnZXM6IGFzeW5jIChwb3N0KSA9PiAoc2V0dGluZ3Muc2NvcmVJbWFnZXMgPyBQcm9taXNlLmFsbCgocG9zdC5pbWFnZVVybHMgPz8gW10pLm1hcCgodSkgPT4gaW1hZ2VUb0RhdGFVcmwodSkpKSA6IFtdKSxcbiAgICBidWRnZXQ6IHtcbiAgICAgIGNhblNwZW5kOiBhc3luYyAoKSA9PiAoYXdhaXQgbG9hZFVzYWdlKCkpLnRva2VucyA8IHNldHRpbmdzLmRhaWx5VG9rZW5CdWRnZXQsXG4gICAgICByZWNvcmQ6IHJlY29yZFVzYWdlLFxuICAgIH0sXG4gIH0pO1xuICByZXR1cm4gc2NvcmVyO1xufVxuXG4vLyBEZWJ1Zy1vbmx5IHN0b3JlIGZvciByYXcgdGltZWxpbmUgcmVzcG9uc2VzLCBleHBvcnRlZCBmcm9tIHRoZSBvcHRpb25zIHBhZ2UgaW50byBmaXh0dXJlcy8uXG5jb25zdCBNQVhfQ0FQVFVSRVMgPSAzMDtcbmNvbnN0IGNhcHR1cmVzID0gb3BlbkRCKCdiYWl0YmxvY2tlci1kZWJ1ZycsIDEsIHtcbiAgdXBncmFkZShkYikge1xuICAgIGRiLmNyZWF0ZU9iamVjdFN0b3JlKCdjYXB0dXJlcycsIHsga2V5UGF0aDogJ2lkJywgYXV0b0luY3JlbWVudDogdHJ1ZSB9KTtcbiAgfSxcbn0pO1xuXG5hc3luYyBmdW5jdGlvbiBzYXZlQ2FwdHVyZSh1cmw6IHN0cmluZywgYm9keTogdW5rbm93bikge1xuICBjb25zdCBkYiA9IGF3YWl0IGNhcHR1cmVzO1xuICBhd2FpdCBkYi5hZGQoJ2NhcHR1cmVzJywgeyB1cmwsIGF0OiBEYXRlLm5vdygpLCBib2R5IH0pO1xuICBjb25zdCBrZXlzID0gYXdhaXQgZGIuZ2V0QWxsS2V5cygnY2FwdHVyZXMnKTtcbiAgZm9yIChjb25zdCBrIG9mIGtleXMuc2xpY2UoMCwgTWF0aC5tYXgoMCwga2V5cy5sZW5ndGggLSBNQVhfQ0FQVFVSRVMpKSkgYXdhaXQgZGIuZGVsZXRlKCdjYXB0dXJlcycsIGspO1xufVxuXG50eXBlIE1zZyA9XG4gIHwgeyB0eXBlOiAnc2NvcmUnOyBwb3N0OiBQb3N0IH1cbiAgfCB7IHR5cGU6ICdsYWJlbCc7IGxhYmVsOiBPbWl0PExhYmVsUmVjb3JkLCAnaWQnIHwgJ2F0Jz4gfVxuICB8IHsgdHlwZTogJ2NhcHR1cmUnOyB1cmw6IHN0cmluZzsgYm9keTogdW5rbm93biB9XG4gIHwgeyB0eXBlOiAnY291bnRyeSc7IGhhbmRsZTogc3RyaW5nOyBpbmZvOiBBYm91dEluZm8gfTtcblxuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtc2c6IE1zZywgX3NlbmRlciwgc2VuZFJlc3BvbnNlKSA9PiB7XG4gIChhc3luYyAoKSA9PiB7XG4gICAgc3dpdGNoIChtc2cudHlwZSkge1xuICAgICAgY2FzZSAnc2NvcmUnOlxuICAgICAgICByZXR1cm4gKGF3YWl0IGdldFNjb3JlcigpKS5kZWNpZGUobXNnLnBvc3QpO1xuICAgICAgY2FzZSAnbGFiZWwnOiB7XG4gICAgICAgIGNvbnN0IGRiID0gYXdhaXQgcmVhZHk7XG4gICAgICAgIGF3YWl0IGRiLmFkZCgnbGFiZWxzJywgeyAuLi5tc2cubGFiZWwsIGF0OiBEYXRlLm5vdygpIH0pO1xuICAgICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgICAgfVxuICAgICAgY2FzZSAnY291bnRyeSc6IHtcbiAgICAgICAgY29uc3QgZGIgPSBhd2FpdCByZWFkeTtcbiAgICAgICAgYXdhaXQgbmV3IElkYlN0b3JlKGRiKS5wdXRDb3VudHJ5KHsgaGFuZGxlOiBtc2cuaGFuZGxlLCAuLi5tc2cuaW5mbywgZmV0Y2hlZEF0OiBEYXRlLm5vdygpIH0pO1xuICAgICAgICByZXR1cm4geyBvazogdHJ1ZSB9O1xuICAgICAgfVxuICAgICAgY2FzZSAnY2FwdHVyZSc6XG4gICAgICAgIGlmIChzZXR0aW5ncy5jYXB0dXJlRml4dHVyZXMpIGF3YWl0IHNhdmVDYXB0dXJlKG1zZy51cmwsIG1zZy5ib2R5KTtcbiAgICAgICAgcmV0dXJuIHsgb2s6IHRydWUgfTtcbiAgICB9XG4gIH0pKClcbiAgICAudGhlbihzZW5kUmVzcG9uc2UpXG4gICAgLmNhdGNoKChlKSA9PiB7XG4gICAgICBjb25zb2xlLndhcm4oJ1tiYWl0YmxvY2tlcl0nLCBtc2cudHlwZSwgJ2ZhaWxlZDonLCBlIGluc3RhbmNlb2YgRXJyb3IgPyBlLm1lc3NhZ2UgOiBlKTtcbiAgICAgIHNlbmRSZXNwb25zZSh1bmRlZmluZWQpO1xuICAgIH0pO1xuICByZXR1cm4gdHJ1ZTtcbn0pO1xuXG5jaHJvbWUuYWN0aW9uPy5vbkNsaWNrZWQuYWRkTGlzdGVuZXIoKCkgPT4gY2hyb21lLnJ1bnRpbWUub3Blbk9wdGlvbnNQYWdlKCkpO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBQUEsTUFBTSxnQkFBZ0IsQ0FBQyxRQUFRLGlCQUFpQixhQUFhLEtBQUssQ0FBQyxNQUFNLGtCQUFrQixDQUFDO0FBRTVGLE1BQUk7QUFDSixNQUFJO0FBRUosV0FBUyx1QkFBdUI7QUFDNUIsV0FBUSxzQkFDSCxvQkFBb0I7QUFBQSxNQUNqQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNKO0FBQUEsRUFDUjtBQUVBLFdBQVMsMEJBQTBCO0FBQy9CLFdBQVEseUJBQ0gsdUJBQXVCLENBQUMsV0FBVyxZQUFZLG9CQUFvQixFQUFFLElBQUksQ0FBQyxXQUFXLFVBQVUsVUFBVSxNQUFNLENBQUM7QUFBQSxFQUN6SDtBQUNBLE1BQU0scUJBQXFCLG9CQUFJLFFBQVE7QUFDdkMsTUFBTSxpQkFBaUIsb0JBQUksUUFBUTtBQUNuQyxNQUFNLHdCQUF3QixvQkFBSSxRQUFRO0FBQzFDLFdBQVMsaUJBQWlCLFNBQVM7QUFDL0IsVUFBTSxVQUFVLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUM3QyxZQUFNLFdBQVcsTUFBTTtBQUNuQixnQkFBUSxvQkFBb0IsV0FBVyxPQUFPO0FBQzlDLGdCQUFRLG9CQUFvQixTQUFTLEtBQUs7QUFBQSxNQUM5QztBQUNBLFlBQU0sVUFBVSxNQUFNO0FBQ2xCLGdCQUFRLEtBQUssUUFBUSxNQUFNLENBQUM7QUFDNUIsaUJBQVM7QUFBQSxNQUNiO0FBQ0EsWUFBTSxRQUFRLE1BQU07QUFDaEIsZUFBTyxRQUFRLEtBQUs7QUFDcEIsaUJBQVM7QUFBQSxNQUNiO0FBQ0EsY0FBUSxpQkFBaUIsV0FBVyxPQUFPO0FBQzNDLGNBQVEsaUJBQWlCLFNBQVMsS0FBSztBQUFBLElBQzNDLENBQUM7QUFHRCwwQkFBc0IsSUFBSSxTQUFTLE9BQU87QUFDMUMsV0FBTztBQUFBLEVBQ1g7QUFDQSxXQUFTLCtCQUErQixJQUFJO0FBRXhDLFFBQUksbUJBQW1CLElBQUksRUFBRTtBQUN6QjtBQUNKLFVBQU0sT0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDMUMsWUFBTSxXQUFXLE1BQU07QUFDbkIsV0FBRyxvQkFBb0IsWUFBWSxRQUFRO0FBQzNDLFdBQUcsb0JBQW9CLFNBQVMsS0FBSztBQUNyQyxXQUFHLG9CQUFvQixTQUFTLEtBQUs7QUFBQSxNQUN6QztBQUNBLFlBQU0sV0FBVyxNQUFNO0FBQ25CLGdCQUFRO0FBQ1IsaUJBQVM7QUFBQSxNQUNiO0FBQ0EsWUFBTSxRQUFRLE1BQU07QUFDaEIsZUFBTyxHQUFHLFNBQVMsSUFBSSxhQUFhLGNBQWMsWUFBWSxDQUFDO0FBQy9ELGlCQUFTO0FBQUEsTUFDYjtBQUNBLFNBQUcsaUJBQWlCLFlBQVksUUFBUTtBQUN4QyxTQUFHLGlCQUFpQixTQUFTLEtBQUs7QUFDbEMsU0FBRyxpQkFBaUIsU0FBUyxLQUFLO0FBQUEsSUFDdEMsQ0FBQztBQUVELHVCQUFtQixJQUFJLElBQUksSUFBSTtBQUFBLEVBQ25DO0FBQ0EsTUFBSSxnQkFBZ0I7QUFBQSxJQUNoQixJQUFJLFFBQVEsTUFBTSxVQUFVO0FBQ3hCLFVBQUksa0JBQWtCLGdCQUFnQjtBQUVsQyxZQUFJLFNBQVM7QUFDVCxpQkFBTyxtQkFBbUIsSUFBSSxNQUFNO0FBRXhDLFlBQUksU0FBUyxTQUFTO0FBQ2xCLGlCQUFPLFNBQVMsaUJBQWlCLENBQUMsSUFDNUIsU0FDQSxTQUFTLFlBQVksU0FBUyxpQkFBaUIsQ0FBQyxDQUFDO0FBQUEsUUFDM0Q7QUFBQSxNQUNKO0FBRUEsYUFBTyxLQUFLLE9BQU8sSUFBSSxDQUFDO0FBQUEsSUFDNUI7QUFBQSxJQUNBLElBQUksUUFBUSxNQUFNLE9BQU87QUFDckIsYUFBTyxJQUFJLElBQUk7QUFDZixhQUFPO0FBQUEsSUFDWDtBQUFBLElBQ0EsSUFBSSxRQUFRLE1BQU07QUFDZCxVQUFJLGtCQUFrQixtQkFDakIsU0FBUyxVQUFVLFNBQVMsVUFBVTtBQUN2QyxlQUFPO0FBQUEsTUFDWDtBQUNBLGFBQU8sUUFBUTtBQUFBLElBQ25CO0FBQUEsRUFDSjtBQUNBLFdBQVMsYUFBYSxVQUFVO0FBQzVCLG9CQUFnQixTQUFTLGFBQWE7QUFBQSxFQUMxQztBQUNBLFdBQVMsYUFBYSxNQUFNO0FBUXhCLFFBQUksd0JBQXdCLEVBQUUsU0FBUyxJQUFJLEdBQUc7QUFDMUMsYUFBTyxZQUFhLE1BQU07QUFHdEIsYUFBSyxNQUFNLE9BQU8sSUFBSSxHQUFHLElBQUk7QUFDN0IsZUFBTyxLQUFLLEtBQUssT0FBTztBQUFBLE1BQzVCO0FBQUEsSUFDSjtBQUNBLFdBQU8sWUFBYSxNQUFNO0FBR3RCLGFBQU8sS0FBSyxLQUFLLE1BQU0sT0FBTyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQUEsSUFDOUM7QUFBQSxFQUNKO0FBQ0EsV0FBUyx1QkFBdUIsT0FBTztBQUNuQyxRQUFJLE9BQU8sVUFBVTtBQUNqQixhQUFPLGFBQWEsS0FBSztBQUc3QixRQUFJLGlCQUFpQjtBQUNqQixxQ0FBK0IsS0FBSztBQUN4QyxRQUFJLGNBQWMsT0FBTyxxQkFBcUIsQ0FBQztBQUMzQyxhQUFPLElBQUksTUFBTSxPQUFPLGFBQWE7QUFFekMsV0FBTztBQUFBLEVBQ1g7QUFDQSxXQUFTLEtBQUssT0FBTztBQUdqQixRQUFJLGlCQUFpQjtBQUNqQixhQUFPLGlCQUFpQixLQUFLO0FBR2pDLFFBQUksZUFBZSxJQUFJLEtBQUs7QUFDeEIsYUFBTyxlQUFlLElBQUksS0FBSztBQUNuQyxVQUFNLFdBQVcsdUJBQXVCLEtBQUs7QUFHN0MsUUFBSSxDQUFDLE9BQU8sR0FBRyxVQUFVLEtBQUssR0FBRztBQUM3QixxQkFBZSxJQUFJLE9BQU8sUUFBUTtBQUNsQyw0QkFBc0IsSUFBSSxVQUFVLEtBQUs7QUFBQSxJQUM3QztBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0EsTUFBTSxTQUFTLENBQUMsVUFBVSxzQkFBc0IsSUFBSSxLQUFLO0FBU3pELFdBQVMsT0FBTyxNQUFNLFNBQVMsRUFBRSxTQUFTLFNBQVMsVUFBVSxXQUFXLElBQUksQ0FBQyxHQUFHO0FBQzVFLFVBQU0sVUFBVSxVQUFVLEtBQUssTUFBTSxPQUFPO0FBQzVDLFVBQU0sY0FBYyxLQUFLLE9BQU87QUFDaEMsUUFBSSxTQUFTO0FBQ1QsY0FBUSxpQkFBaUIsaUJBQWlCLENBQUMsVUFBVTtBQUNqRCxnQkFBUSxLQUFLLFFBQVEsTUFBTSxHQUFHLE1BQU0sWUFBWSxNQUFNLFlBQVksS0FBSyxRQUFRLFdBQVcsR0FBRyxLQUFLO0FBQUEsTUFDdEcsQ0FBQztBQUFBLElBQ0w7QUFDQSxRQUFJLFNBQVM7QUFDVCxjQUFRLGlCQUFpQixXQUFXLENBQUMsVUFBVTtBQUFBO0FBQUEsUUFFL0MsTUFBTTtBQUFBLFFBQVksTUFBTTtBQUFBLFFBQVk7QUFBQSxNQUFLLENBQUM7QUFBQSxJQUM5QztBQUNBLGdCQUNLLEtBQUssQ0FBQyxPQUFPO0FBQ2QsVUFBSTtBQUNBLFdBQUcsaUJBQWlCLFNBQVMsTUFBTSxXQUFXLENBQUM7QUFDbkQsVUFBSSxVQUFVO0FBQ1YsV0FBRyxpQkFBaUIsaUJBQWlCLENBQUMsVUFBVSxTQUFTLE1BQU0sWUFBWSxNQUFNLFlBQVksS0FBSyxDQUFDO0FBQUEsTUFDdkc7QUFBQSxJQUNKLENBQUMsRUFDSSxNQUFNLE1BQU07QUFBQSxJQUFFLENBQUM7QUFDcEIsV0FBTztBQUFBLEVBQ1g7QUFnQkEsTUFBTSxjQUFjLENBQUMsT0FBTyxVQUFVLFVBQVUsY0FBYyxPQUFPO0FBQ3JFLE1BQU0sZUFBZSxDQUFDLE9BQU8sT0FBTyxVQUFVLE9BQU87QUFDckQsTUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixXQUFTLFVBQVUsUUFBUSxNQUFNO0FBQzdCLFFBQUksRUFBRSxrQkFBa0IsZUFDcEIsRUFBRSxRQUFRLFdBQ1YsT0FBTyxTQUFTLFdBQVc7QUFDM0I7QUFBQSxJQUNKO0FBQ0EsUUFBSSxjQUFjLElBQUk7QUFDbEIsYUFBTyxjQUFjLElBQUk7QUFDN0IsVUFBTSxpQkFBaUIsS0FBSyxRQUFRLGNBQWMsRUFBRTtBQUNwRCxVQUFNLFdBQVcsU0FBUztBQUMxQixVQUFNLFVBQVUsYUFBYSxTQUFTLGNBQWM7QUFDcEQ7QUFBQTtBQUFBLE1BRUEsRUFBRSxtQkFBbUIsV0FBVyxXQUFXLGdCQUFnQixjQUN2RCxFQUFFLFdBQVcsWUFBWSxTQUFTLGNBQWM7QUFBQSxNQUFJO0FBQ3BEO0FBQUEsSUFDSjtBQUNBLFVBQU0sU0FBUyxlQUFnQixjQUFjLE1BQU07QUFFL0MsWUFBTSxLQUFLLEtBQUssWUFBWSxXQUFXLFVBQVUsY0FBYyxVQUFVO0FBQ3pFLFVBQUlBLFVBQVMsR0FBRztBQUNoQixVQUFJO0FBQ0EsUUFBQUEsVUFBU0EsUUFBTyxNQUFNLEtBQUssTUFBTSxDQUFDO0FBTXRDLGNBQVEsTUFBTSxRQUFRLElBQUk7QUFBQSxRQUN0QkEsUUFBTyxjQUFjLEVBQUUsR0FBRyxJQUFJO0FBQUEsUUFDOUIsV0FBVyxHQUFHO0FBQUEsTUFDbEIsQ0FBQyxHQUFHLENBQUM7QUFBQSxJQUNUO0FBQ0EsV0FBUSxjQUFjLElBQUksSUFBSTtBQUFBLEVBQ2xDO0FBQ0EsZUFBYSxDQUFDLGNBQWM7QUFBQSxJQUN4QixHQUFHO0FBQUEsSUFDSCxLQUFLLENBQUMsUUFBUSxNQUFNLGFBQWEsVUFBVSxRQUFRLElBQUksS0FBSyxTQUFTLElBQUksUUFBUSxNQUFNLFFBQVE7QUFBQSxJQUMvRixLQUFLLENBQUMsUUFBUSxTQUFTLENBQUMsQ0FBQyxVQUFVLFFBQVEsSUFBSSxLQUFLLFNBQVMsSUFBSSxRQUFRLElBQUk7QUFBQSxFQUNqRixFQUFFO0FBRUYsTUFBTSxxQkFBcUIsQ0FBQyxXQUFXLFlBQVksb0JBQW9CO0FBQ3ZFLE1BQU0sWUFBWSxDQUFDO0FBQ25CLE1BQU0saUJBQWlCLG9CQUFJLFFBQVE7QUFDbkMsTUFBTSxtQ0FBbUMsb0JBQUksUUFBUTtBQUNyRCxNQUFNLHNCQUFzQjtBQUFBLElBQ3hCLElBQUksUUFBUSxNQUFNO0FBQ2QsVUFBSSxDQUFDLG1CQUFtQixTQUFTLElBQUk7QUFDakMsZUFBTyxPQUFPLElBQUk7QUFDdEIsVUFBSSxhQUFhLFVBQVUsSUFBSTtBQUMvQixVQUFJLENBQUMsWUFBWTtBQUNiLHFCQUFhLFVBQVUsSUFBSSxJQUFJLFlBQWEsTUFBTTtBQUM5Qyx5QkFBZSxJQUFJLE1BQU0saUNBQWlDLElBQUksSUFBSSxFQUFFLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQztBQUFBLFFBQ3RGO0FBQUEsTUFDSjtBQUNBLGFBQU87QUFBQSxJQUNYO0FBQUEsRUFDSjtBQUNBLGtCQUFnQixXQUFXLE1BQU07QUFFN0IsUUFBSSxTQUFTO0FBQ2IsUUFBSSxFQUFFLGtCQUFrQixZQUFZO0FBQ2hDLGVBQVMsTUFBTSxPQUFPLFdBQVcsR0FBRyxJQUFJO0FBQUEsSUFDNUM7QUFDQSxRQUFJLENBQUM7QUFDRDtBQUNKLGFBQVM7QUFDVCxVQUFNLGdCQUFnQixJQUFJLE1BQU0sUUFBUSxtQkFBbUI7QUFDM0QscUNBQWlDLElBQUksZUFBZSxNQUFNO0FBRTFELDBCQUFzQixJQUFJLGVBQWUsT0FBTyxNQUFNLENBQUM7QUFDdkQsV0FBTyxRQUFRO0FBQ1gsWUFBTTtBQUVOLGVBQVMsT0FBTyxlQUFlLElBQUksYUFBYSxLQUFLLE9BQU8sU0FBUztBQUNyRSxxQkFBZSxPQUFPLGFBQWE7QUFBQSxJQUN2QztBQUFBLEVBQ0o7QUFDQSxXQUFTLGVBQWUsUUFBUSxNQUFNO0FBQ2xDLFdBQVMsU0FBUyxPQUFPLGlCQUNyQixjQUFjLFFBQVEsQ0FBQyxVQUFVLGdCQUFnQixTQUFTLENBQUMsS0FDMUQsU0FBUyxhQUFhLGNBQWMsUUFBUSxDQUFDLFVBQVUsY0FBYyxDQUFDO0FBQUEsRUFDL0U7QUFDQSxlQUFhLENBQUMsY0FBYztBQUFBLElBQ3hCLEdBQUc7QUFBQSxJQUNILElBQUksUUFBUSxNQUFNLFVBQVU7QUFDeEIsVUFBSSxlQUFlLFFBQVEsSUFBSTtBQUMzQixlQUFPO0FBQ1gsYUFBTyxTQUFTLElBQUksUUFBUSxNQUFNLFFBQVE7QUFBQSxJQUM5QztBQUFBLElBQ0EsSUFBSSxRQUFRLE1BQU07QUFDZCxhQUFPLGVBQWUsUUFBUSxJQUFJLEtBQUssU0FBUyxJQUFJLFFBQVEsSUFBSTtBQUFBLElBQ3BFO0FBQUEsRUFDSixFQUFFOzs7QUM3UkssV0FBUyxPQUFPLE9BQU8sZUFBZ0M7QUFDNUQsV0FBTyxPQUFtQixNQUFNLEdBQUc7QUFBQSxNQUNqQyxRQUFRLElBQUksWUFBWTtBQUN0QixZQUFJLGFBQWEsR0FBRztBQUNsQixhQUFHLGtCQUFrQixTQUFTLEVBQUUsU0FBUyxLQUFLLENBQUM7QUFDL0MsZ0JBQU0sU0FBUyxHQUFHLGtCQUFrQixVQUFVLEVBQUUsU0FBUyxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQ3BGLGlCQUFPLFlBQVksVUFBVSxRQUFRO0FBQ3JDLGFBQUcsa0JBQWtCLFdBQVcsRUFBRSxTQUFTLFNBQVMsQ0FBQztBQUFBLFFBQ3ZEO0FBQ0EsWUFBSSxhQUFhLEVBQUcsSUFBRyxrQkFBa0IsYUFBYSxFQUFFLFNBQVMsU0FBUyxDQUFDO0FBQUEsTUFDN0U7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRU8sTUFBTSxhQUFhLENBQUMsTUFBYyxFQUFFLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxFQUFFLFlBQVk7QUFFekUsTUFBTSxZQUFZLENBQUMsWUFBa0MsRUFBRSxRQUFRLE9BQU8sR0FBRyxNQUFNLEdBQUcsUUFBUSxPQUFPLFdBQVcsRUFBRTtBQUU5RyxNQUFNLGNBQWMsQ0FBQyxNQUFvQixFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUU7QUFhaEUsTUFBTSxXQUFOLE1BQWdDO0FBQUEsSUFDckMsWUFBb0IsSUFBWTtBQUFaO0FBQUEsSUFBYTtBQUFBLElBQWI7QUFBQSxJQUNwQixRQUFRLElBQVk7QUFDbEIsYUFBTyxLQUFLLEdBQUcsSUFBSSxTQUFTLEVBQUU7QUFBQSxJQUNoQztBQUFBLElBQ0EsTUFBTSxRQUFRLEdBQWU7QUFDM0IsWUFBTSxLQUFLLEdBQUcsSUFBSSxTQUFTLENBQUM7QUFBQSxJQUM5QjtBQUFBLElBQ0EsVUFBVSxRQUFnQjtBQUN4QixhQUFPLEtBQUssR0FBRyxJQUFJLFdBQVcsV0FBVyxNQUFNLENBQUM7QUFBQSxJQUNsRDtBQUFBLElBQ0EsTUFBTSxVQUFVLEdBQWlCO0FBQy9CLFlBQU0sS0FBSyxHQUFHLElBQUksV0FBVyxFQUFFLEdBQUcsR0FBRyxRQUFRLFdBQVcsRUFBRSxNQUFNLEVBQUUsQ0FBQztBQUFBLElBQ3JFO0FBQUEsSUFDQSxNQUFNLFNBQVMsR0FBZ0I7QUFDN0IsWUFBTSxLQUFLLEdBQUcsSUFBSSxVQUFVLENBQUM7QUFBQSxJQUMvQjtBQUFBLElBQ0EsV0FBVyxRQUFnQjtBQUN6QixhQUFPLEtBQUssR0FBRyxJQUFJLGFBQWEsV0FBVyxNQUFNLENBQUM7QUFBQSxJQUNwRDtBQUFBLElBQ0EsTUFBTSxXQUFXLEdBQWtCO0FBQ2pDLFlBQU0sS0FBSyxHQUFHLElBQUksYUFBYSxFQUFFLEdBQUcsR0FBRyxRQUFRLFdBQVcsRUFBRSxNQUFNLEVBQUUsQ0FBQztBQUFBLElBQ3ZFO0FBQUEsRUFDRjs7O0FDeERPLFdBQVMsYUFBYSxPQUErQixLQUF5QztBQUNuRyxVQUFNLFVBQVUsS0FBSyxJQUFJLEdBQUcsR0FBRyxJQUFJLE9BQU8sSUFBSSxDQUFDLE1BQU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25FLFFBQUksV0FBVztBQUNmLGVBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxPQUFPLFFBQVEsSUFBSSxRQUFRLEVBQUcsYUFBWSxLQUFLLE1BQU0sQ0FBQyxLQUFLO0FBQ2hGLFdBQU8sS0FBSyxJQUFJLFNBQVMsUUFBUTtBQUFBLEVBQ25DO0FBRU8sV0FBUyxPQUFPLE9BQWUsR0FBeUI7QUFDN0QsUUFBSSxTQUFTLEVBQUUsS0FBTSxRQUFPO0FBQzVCLFFBQUksU0FBUyxFQUFFLEtBQU0sUUFBTztBQUM1QixXQUFPO0FBQUEsRUFDVDtBQUVPLFdBQVMsWUFBWSxPQUFtRDtBQUM3RSxRQUFJO0FBQ0osZUFBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLE9BQU8sUUFBUSxLQUFLLEVBQUcsS0FBSSxTQUFTLFVBQWEsSUFBSSxNQUFNLElBQUksRUFBRyxRQUFPO0FBQzlGLFdBQU87QUFBQSxFQUNUO0FBRU8sV0FBUyxRQUFRLE9BQStCLEtBQXNCLGFBQWEsSUFBSSxZQUFzQjtBQUNsSCxVQUFNLFFBQVEsYUFBYSxPQUFPLElBQUksT0FBTztBQUM3QyxXQUFPLEVBQUUsT0FBTyxVQUFVLE9BQU8sT0FBTyxVQUFVLEdBQUcsYUFBYSxZQUFZLEtBQUssRUFBRTtBQUFBLEVBQ3ZGOzs7QUN2Qk8sTUFBTSxlQUFlLEtBQUssS0FBSztBQUMvQixNQUFNLGlCQUFpQixLQUFLO0FBMEI1QixXQUFTLFFBQVEsR0FBOEIsTUFBTSxLQUFLLElBQUksR0FBdUI7QUFDMUYsUUFBSSxDQUFDLEVBQUcsUUFBTztBQUNmLFdBQU8sTUFBTSxFQUFFLGFBQWEsRUFBRSxVQUFVLGVBQWU7QUFBQSxFQUN6RDtBQUVPLFdBQVMsVUFBVSxTQUE2QixTQUE0QjtBQUNqRixRQUFJLENBQUMsUUFBUyxRQUFPO0FBQ3JCLFVBQU0sSUFBSSxRQUFRLFlBQVk7QUFDOUIsV0FBTyxRQUFRLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLFlBQVksTUFBTSxDQUFDO0FBQUEsRUFDekQ7OztBQ1JPLE1BQU0sU0FBTixNQUFhO0FBQUEsSUFRbEIsWUFBb0IsR0FBa0I7QUFBbEI7QUFDbEIsV0FBSyxjQUFjLEVBQUUsZUFBZTtBQUNwQyxXQUFLLFVBQVUsRUFBRSxXQUFXO0FBQUEsSUFDOUI7QUFBQSxJQUhvQjtBQUFBLElBUFosUUFBZSxDQUFDO0FBQUEsSUFDaEIsV0FBVyxvQkFBSSxJQUE4QjtBQUFBLElBQzdDLFNBQVM7QUFBQSxJQUNUO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQU9SLE9BQU8sTUFBOEI7QUFDbkMsWUFBTSxXQUFXLEtBQUssU0FBUyxJQUFJLEtBQUssRUFBRTtBQUMxQyxVQUFJLFNBQVUsUUFBTztBQUNyQixZQUFNLElBQUksS0FBSyxlQUFlLElBQUksRUFBRSxRQUFRLE1BQU0sS0FBSyxTQUFTLE9BQU8sS0FBSyxFQUFFLENBQUM7QUFDL0UsV0FBSyxTQUFTLElBQUksS0FBSyxJQUFJLENBQUM7QUFDNUIsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUVBLE1BQWMsZUFBZSxNQUE4QjtBQUN6RCxZQUFNLFNBQVMsTUFBTSxLQUFLLEVBQUUsTUFBTSxRQUFRLEtBQUssRUFBRTtBQUVqRCxVQUFJLFdBQVcsT0FBTyxXQUFXLFlBQVksT0FBTyxxQkFBcUIsS0FBSyxFQUFFLE9BQU8sVUFBVTtBQUMvRixlQUFPLEtBQUssV0FBVyxRQUFRLE9BQU87QUFBQSxNQUN4QztBQUVBLFlBQU0sV0FBVyxNQUFNLEtBQUssYUFBYSxJQUFJO0FBQzdDLFVBQUksVUFBVTtBQUNaLGNBQU0sTUFBa0I7QUFBQSxVQUN0QixHQUFHLEtBQUssV0FBVyxJQUFJO0FBQUEsVUFDdkIsT0FBTyxDQUFDO0FBQUEsVUFDUixPQUFPO0FBQUEsVUFDUCxVQUFVO0FBQUEsVUFDVixRQUFRO0FBQUEsUUFDVjtBQUNBLGNBQU0sS0FBSyxFQUFFLE1BQU0sUUFBUSxHQUFHO0FBQzlCLGNBQU0sS0FBSyxFQUFFLE1BQU0sU0FBUyxFQUFFLFFBQVEsS0FBSyxJQUFJLE9BQU8sWUFBWSxRQUFRLGdCQUFnQixJQUFJLEtBQUssSUFBSSxFQUFFLENBQUM7QUFDMUcsY0FBTSxLQUFLLFdBQVcsS0FBSyxNQUFNO0FBQ2pDLGVBQU8sS0FBSyxXQUFXLEtBQUssUUFBUTtBQUFBLE1BQ3RDO0FBR0EsWUFBTSxVQUFVLEtBQUssU0FBUyxNQUFNLEtBQUssRUFBRSxNQUFNLFdBQVcsV0FBVyxLQUFLLE1BQU0sQ0FBQyxJQUFJO0FBQ3ZGLFVBQUksUUFBUSxPQUFPLEtBQUssVUFBVSxRQUFRLFNBQVMsS0FBSyxRQUFRLENBQUMsR0FBRztBQUNsRSxlQUFPLEVBQUUsUUFBUSxLQUFLLElBQUksVUFBVSxRQUFRLFFBQVEsV0FBVyxRQUFRLFdBQVcsS0FBSyxNQUFPLEdBQUcsU0FBUyxRQUFRLFFBQVE7QUFBQSxNQUM1SDtBQUVBLFVBQUksQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFHLFFBQU8sRUFBRSxRQUFRLEtBQUssSUFBSSxVQUFVLFlBQVksUUFBUSxTQUFTO0FBQ3ZGLGFBQU8sSUFBSSxRQUFpQixDQUFDLFlBQVk7QUFDdkMsYUFBSyxNQUFNLEtBQUssRUFBRSxNQUFNLFNBQVMsQ0FBQyxDQUFDLFFBQVEsUUFBUSxDQUFDO0FBQ3BELFlBQUksS0FBSyxNQUFNLFVBQVUsS0FBSyxZQUFhLE1BQUssTUFBTTtBQUFBLFlBQ2pELE1BQUssVUFBVSxXQUFXLE1BQU0sS0FBSyxNQUFNLEdBQUcsS0FBSyxPQUFPO0FBQUEsTUFDakUsQ0FBQztBQUFBLElBQ0g7QUFBQSxJQUVRLFFBQVE7QUFDZCxtQkFBYSxLQUFLLEtBQUs7QUFDdkIsV0FBSyxRQUFRO0FBQ2IsYUFBTyxLQUFLLFNBQVMsS0FBSyxlQUFlLEtBQUssTUFBTSxRQUFRO0FBQzFELGNBQU0sTUFBTSxLQUFLLE1BQU0sTUFBTTtBQUM3QixhQUFLO0FBQ0wsYUFBSyxJQUFJLElBQUksTUFBTSxJQUFJLE9BQU8sRUFDM0IsTUFBTSxPQUFnQixFQUFFLFFBQVEsSUFBSSxLQUFLLElBQUksVUFBVSxZQUFZLFFBQVEsUUFBUSxFQUFFLEVBQ3JGLEtBQUssSUFBSSxPQUFPLEVBQ2hCLFFBQVEsTUFBTTtBQUNiLGVBQUs7QUFDTCxjQUFJLEtBQUssTUFBTSxPQUFRLE1BQUssTUFBTTtBQUFBLFFBQ3BDLENBQUM7QUFBQSxNQUNMO0FBQUEsSUFDRjtBQUFBLElBRUEsTUFBYyxJQUFJLE1BQVksU0FBb0M7QUFDaEUsWUFBTUMsVUFBUyxLQUFLLEVBQUUsT0FBTztBQUM3QixVQUFJLENBQUNBLFFBQVEsUUFBTyxFQUFFLFFBQVEsS0FBSyxJQUFJLFVBQVUsWUFBWSxRQUFRLFNBQVM7QUFDOUUsVUFBSSxDQUFFLE1BQU0sS0FBSyxFQUFFLE9BQU8sU0FBUyxFQUFJLFFBQU8sRUFBRSxRQUFRLEtBQUssSUFBSSxVQUFVLFlBQVksUUFBUSxTQUFTO0FBRXhHLFlBQU0sU0FBUyxLQUFLLFdBQVcsVUFBVSxLQUFLLEVBQUUsU0FBUyxNQUFNLEtBQUssRUFBRSxPQUFPLElBQUksRUFBRSxNQUFNLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN0RyxZQUFNLEVBQUUsT0FBTyxZQUFZLElBQUksTUFBTUEsUUFBTyxNQUFNLE1BQU0sS0FBSyxFQUFFLE9BQU8sV0FBVyxNQUFNO0FBQ3ZGLFlBQU0sSUFBSSxRQUFRLE9BQU8sS0FBSyxFQUFFLFFBQVEsS0FBSyxFQUFFLFdBQVcsQ0FBQztBQUMzRCxZQUFNLE1BQWtCLEVBQUUsR0FBRyxLQUFLLFdBQVcsSUFBSSxHQUFHLE9BQU8sT0FBTyxFQUFFLE9BQU8sVUFBVSxFQUFFLFVBQVUsUUFBUSxLQUFLO0FBQzlHLFlBQU0sS0FBSyxFQUFFLE1BQU0sUUFBUSxHQUFHO0FBQzlCLFlBQU0sS0FBSyxFQUFFLE9BQU8sT0FBTyxhQUFhLEVBQUUsUUFBUTtBQUNsRCxVQUFJLENBQUMsUUFBUyxPQUFNLEtBQUssV0FBVyxLQUFLLFFBQVEsRUFBRSxLQUFLO0FBQ3hELGFBQU8sS0FBSyxXQUFXLEtBQUssSUFBSTtBQUFBLElBQ2xDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBT0EsTUFBYyxrQkFBa0IsS0FBaUIsS0FBa0M7QUFDakYsWUFBTSxTQUFTLEtBQUssRUFBRSxPQUFPO0FBQzdCLFVBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxZQUFZLENBQUMsSUFBSSxXQUFZLFFBQU87QUFDeEQsWUFBTSxTQUFTLE1BQU0sS0FBSyxFQUFFLE1BQU0sUUFBUSxJQUFJLFFBQVE7QUFDdEQsVUFBSSxDQUFDLFVBQVUsT0FBTyxxQkFBcUIsS0FBSyxFQUFFLE9BQU8sUUFBUyxRQUFPO0FBQ3pFLFlBQU0sSUFBSSxLQUFLLEVBQUUsV0FBVztBQUM1QixZQUFNLElBQUksT0FBTyxXQUFXLFdBQVcsRUFBRSxPQUFPLEdBQUcsVUFBVSxPQUFnQixJQUFJLFFBQVEsT0FBTyxPQUFPLEtBQUssRUFBRSxRQUFRLENBQUM7QUFDdkgsVUFBSSxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsU0FBUyxJQUFJLE1BQU8sUUFBTztBQUNyRCxVQUFJLElBQUksa0JBQWtCLFFBQVc7QUFDbkMsY0FBTSxJQUFJLE1BQU0sS0FBSyxVQUFVLEdBQUcsRUFBRSxNQUFNLE1BQU0sTUFBUztBQUN6RCxZQUFJLE1BQU0sT0FBVyxRQUFPO0FBQzVCLFlBQUksZ0JBQWdCO0FBQ3BCLGNBQU0sS0FBSyxFQUFFLE1BQU0sUUFBUSxHQUFHO0FBQUEsTUFDaEM7QUFDQSxVQUFJLElBQUksaUJBQWlCLE9BQU8sVUFBVyxRQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sVUFBVSxFQUFFLFVBQVUsYUFBYSxpQkFBaUI7QUFHeEgsYUFBTyxJQUFJLGFBQWEsU0FBUyxNQUFNLEVBQUUsR0FBRyxLQUFLLFVBQVUsT0FBTztBQUFBLElBQ3BFO0FBQUEsSUFFQSxNQUFjLFVBQVUsS0FBOEM7QUFDcEUsWUFBTUEsVUFBUyxLQUFLLEVBQUUsT0FBTztBQUM3QixZQUFNLFNBQVMsS0FBSyxFQUFFLE9BQU87QUFDN0IsVUFBSSxDQUFDQSxXQUFVLENBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxTQUFTLEVBQUksUUFBTztBQUN6RCxZQUFNLFFBQVEsRUFBRSxJQUFJLElBQUksSUFBSSxNQUFNLEdBQUcsSUFBSSxJQUFJO0FBQUE7QUFBQTtBQUFBLEVBQXNCLElBQUksVUFBVSxJQUFJLFNBQVMsTUFBTTtBQUNwRyxZQUFNLEVBQUUsT0FBTyxZQUFZLElBQUksTUFBTUEsUUFBTyxNQUFNLE9BQU8sQ0FBQyxNQUFNLENBQUM7QUFDakUsWUFBTSxLQUFLLEVBQUUsT0FBTyxPQUFPLFdBQVc7QUFDdEMsYUFBTyxNQUFNLE9BQU8sRUFBRTtBQUFBLElBQ3hCO0FBQUEsSUFFUSxVQUFvQjtBQUMxQixhQUFPLEtBQUssRUFBRSxtQkFBbUIsS0FBSyxDQUFDLGVBQWU7QUFBQSxJQUN4RDtBQUFBLElBRVEsV0FBVyxNQUFZO0FBQzdCLGFBQU87QUFBQSxRQUNMLElBQUksS0FBSztBQUFBLFFBQ1QsTUFBTSxLQUFLO0FBQUEsUUFDWCxZQUFZLEtBQUs7QUFBQSxRQUNqQixVQUFVLEtBQUs7QUFBQSxRQUNmLFFBQVEsS0FBSyxTQUFTLFdBQVcsS0FBSyxNQUFNLElBQUk7QUFBQSxRQUNoRCxRQUFRLEtBQUssSUFBSTtBQUFBLFFBQ2pCLGtCQUFrQixLQUFLLEVBQUUsT0FBTztBQUFBLE1BQ2xDO0FBQUEsSUFDRjtBQUFBLElBRUEsTUFBYyxhQUFhLE1BQXlDO0FBRWxFLGlCQUFXLEtBQUssQ0FBQyxLQUFLLFFBQVEsS0FBSyxXQUFXLFNBQVksS0FBSyxZQUFZLEdBQUc7QUFDNUUsWUFBSSxDQUFDLEVBQUc7QUFDUixjQUFNLElBQUksTUFBTSxLQUFLLEVBQUUsTUFBTSxVQUFVLFdBQVcsQ0FBQyxDQUFDO0FBQ3BELFlBQUksR0FBRyxPQUFRLFFBQU8sRUFBRTtBQUFBLE1BQzFCO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFBQSxJQUVBLE1BQWMsV0FBVyxRQUE0QixPQUFnQjtBQUNuRSxVQUFJLENBQUMsT0FBUTtBQUNiLFlBQU0sSUFBSSxXQUFXLE1BQU07QUFDM0IsWUFBTSxJQUFLLE1BQU0sS0FBSyxFQUFFLE1BQU0sVUFBVSxDQUFDLEtBQU0sVUFBVSxDQUFDO0FBQzFELFFBQUU7QUFDRixVQUFJLFVBQVUsUUFBVztBQUN2QixVQUFFLFNBQVM7QUFDWCxVQUFFLFFBQVEsSUFBSTtBQUFBLE1BQ2hCO0FBQ0EsWUFBTSxLQUFLLEVBQUUsTUFBTSxVQUFVLENBQUM7QUFBQSxJQUNoQztBQUFBLElBRUEsTUFBYyxXQUFXLEtBQWlCLFFBQTZDO0FBRXJGLFlBQU0sSUFBSSxJQUFJLFdBQVcsV0FBVyxTQUFZLE1BQU0sS0FBSyxrQkFBa0IsS0FBSyxRQUFRLElBQUksT0FBTyxLQUFLLEVBQUUsUUFBUSxLQUFLLEVBQUUsV0FBVyxDQUFDLENBQUM7QUFDeEksWUFBTSxTQUFTLElBQUksU0FBUyxNQUFNLEtBQUssRUFBRSxNQUFNLFVBQVUsSUFBSSxNQUFNLElBQUk7QUFDdkUsWUFBTSxJQUFhO0FBQUEsUUFDakIsUUFBUSxJQUFJO0FBQUEsUUFDWixVQUFVLEdBQUcsWUFBWSxJQUFJO0FBQUEsUUFDN0IsT0FBTyxHQUFHLFNBQVMsSUFBSTtBQUFBLFFBQ3ZCLGFBQWEsSUFBSSxXQUFXLFdBQVcsa0JBQWtCLEdBQUc7QUFBQSxRQUM1RCxRQUFRLElBQUk7QUFBQSxRQUNaLGFBQWEsU0FBUyxZQUFZLE1BQU0sSUFBSTtBQUFBLFFBQzVDO0FBQUEsTUFDRjtBQUVBLFVBQUksS0FBSyxFQUFFLGFBQWEsUUFBUTtBQUM5QixZQUFJLENBQUMsSUFBSSxPQUFRLFFBQU8sRUFBRSxHQUFHLEdBQUcsVUFBVSxPQUFPO0FBQ2pELGNBQU0sVUFBVSxNQUFNLEtBQUssRUFBRSxNQUFNLFdBQVcsSUFBSSxNQUFNO0FBQ3hELFlBQUksQ0FBQyxRQUFRLE9BQU8sRUFBRyxRQUFPLEVBQUUsR0FBRyxHQUFHLFVBQVUsWUFBWSxjQUFjLElBQUksT0FBTztBQUNyRixVQUFFLFVBQVUsUUFBUTtBQUNwQixZQUFJLENBQUMsUUFBUSxXQUFXLFVBQVUsUUFBUSxTQUFTLEtBQUssUUFBUSxDQUFDLEVBQUcsR0FBRSxXQUFXO0FBQUEsTUFDbkY7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7OztBQ2pOTyxNQUFNLGNBQWM7QUFHcEIsV0FBUyxZQUFZLE1BQW9CO0FBQzlDLFFBQUksSUFBSSxLQUFLO0FBQ2IsUUFBSSxLQUFLLGNBQWMsQ0FBQyxLQUFLLFNBQVUsTUFBSztBQUFBO0FBQUEsVUFBZSxLQUFLLGVBQWUsT0FBTyxLQUFLLGVBQWUsRUFBRTtBQUFBLEVBQU0sS0FBSyxVQUFVO0FBQ2pJLFdBQU87QUFBQSxFQUNUO0FBR0EsaUJBQXNCLGVBQWUsS0FBYSxZQUEwQixJQUFJLE1BQU0sTUFBTSxHQUFHLENBQUMsR0FBb0I7QUFDbEgsVUFBTSxNQUFNLE1BQU0sVUFBVSxHQUFHO0FBQy9CLFFBQUksQ0FBQyxJQUFJLEdBQUksT0FBTSxJQUFJLE1BQU0sY0FBYyxJQUFJLE1BQU0sRUFBRTtBQUN2RCxVQUFNLE9BQU8sSUFBSSxRQUFRLElBQUksY0FBYyxHQUFHLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSztBQUMvRCxVQUFNLFFBQVEsSUFBSSxXQUFXLE1BQU0sSUFBSSxZQUFZLENBQUM7QUFDcEQsUUFBSSxNQUFNO0FBQ1YsYUFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSyxNQUFRLFFBQU8sT0FBTyxhQUFhLEdBQUcsTUFBTSxTQUFTLEdBQUcsSUFBSSxLQUFNLENBQUM7QUFDMUcsV0FBTyxRQUFRLElBQUksV0FBVyxLQUFLLEdBQUcsQ0FBQztBQUFBLEVBQ3pDO0FBTU8sTUFBTSxXQUFOLE1BQXdDO0FBQUEsSUFDN0MsWUFDVSxRQUNBLFFBQVEsUUFDUixZQUEwQixJQUFJLE1BQU0sTUFBTSxHQUFHLENBQUMsR0FDdEQ7QUFIUTtBQUNBO0FBQ0E7QUFBQSxJQUNQO0FBQUEsSUFITztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFHVixNQUFNLE1BQU0sTUFBWSxXQUF1QixTQUFtQixDQUFDLEdBQXlCO0FBQzFGLFlBQU0sT0FBTztBQUFBLFFBQ1gsT0FBTyxLQUFLO0FBQUEsUUFDWixPQUFPLFlBQVksSUFBSTtBQUFBLFFBQ3ZCLEdBQUksT0FBTyxTQUFTLEVBQUUsT0FBTyxJQUFJLENBQUM7QUFBQSxRQUNsQyxXQUFXLE9BQU8sWUFBWSxVQUFVLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsTUFBTSxRQUFRLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQUEsTUFDcEc7QUFDQSxZQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsYUFBYTtBQUFBLFFBQzVDLFFBQVE7QUFBQSxRQUNSLFNBQVMsRUFBRSxlQUFlLFVBQVUsS0FBSyxNQUFNLElBQUksZ0JBQWdCLG1CQUFtQjtBQUFBLFFBQ3RGLE1BQU0sS0FBSyxVQUFVLElBQUk7QUFBQSxNQUMzQixDQUFDO0FBQ0QsVUFBSSxDQUFDLElBQUksR0FBSSxPQUFNLElBQUksTUFBTSxXQUFXLElBQUksTUFBTSxFQUFFO0FBQ3BELFlBQU0sT0FBWSxNQUFNLElBQUksS0FBSztBQUNqQyxZQUFNLFFBQWdDLENBQUM7QUFDdkMsaUJBQVcsS0FBSyxXQUFXO0FBQ3pCLGNBQU0sSUFBSSxNQUFNLFVBQVUsRUFBRSxFQUFFO0FBQzlCLFlBQUksT0FBTyxHQUFHLFNBQVMsU0FBVSxPQUFNLEVBQUUsRUFBRSxJQUFJLEVBQUU7QUFBQSxNQUNuRDtBQUNBLGFBQU8sRUFBRSxPQUFPLGFBQWEsT0FBTyxNQUFNLE9BQU8sWUFBWSxLQUFLLEVBQUU7QUFBQSxJQUN0RTtBQUFBLEVBQ0Y7OztBQ2hFQTtBQUFBLElBQ0UsU0FBVztBQUFBLElBQ1gsV0FBYTtBQUFBLE1BQ1g7QUFBQSxRQUNFLElBQU07QUFBQSxRQUNOLE1BQVE7QUFBQSxNQUNWO0FBQUEsTUFDQTtBQUFBLFFBQ0UsSUFBTTtBQUFBLFFBQ04sTUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxTQUFXO0FBQUEsTUFDVCxRQUFVO0FBQUEsUUFDUjtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsTUFDQSxVQUFZLENBQUM7QUFBQSxJQUNmO0FBQUEsSUFDQSxZQUFjO0FBQUEsTUFDWixNQUFRO0FBQUEsTUFDUixNQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0EsUUFBVTtBQUFBLE1BQ1IsSUFBTTtBQUFBLE1BQ04sTUFBUTtBQUFBLE1BQ1IsV0FBYTtBQUFBLElBQ2Y7QUFBQSxFQUNGOzs7QUN6Qk8sTUFBTSxZQUFZO0FBRWxCLE1BQU0sbUJBQTZCO0FBQUEsSUFDeEMsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsWUFBWSxFQUFFLEdBQUcsVUFBVSxXQUFXO0FBQUEsSUFDdEMsU0FBUyxFQUFFLFNBQVMsTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLElBQzdELGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLElBQ2pCLGtCQUFrQixDQUFDLGlCQUFpQixlQUFlO0FBQUEsSUFDbkQsYUFBYTtBQUFBLEVBQ2Y7QUFFQSxpQkFBc0IsZUFBa0M7QUFDdEQsVUFBTSxFQUFFLFVBQUFDLFVBQVMsSUFBSSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksVUFBVTtBQUM5RCxVQUFNLElBQUtBLGFBQVksQ0FBQztBQUV4QixVQUFNLFFBQVEsRUFBRSxrQkFBa0IsVUFBVSxVQUFVLEVBQUUsYUFBYTtBQUNyRSxXQUFPO0FBQUEsTUFDTCxHQUFHO0FBQUEsTUFDSCxHQUFHO0FBQUEsTUFDSCxZQUFZLEVBQUUsR0FBRyxpQkFBaUIsWUFBWSxHQUFHLE1BQU07QUFBQSxNQUN2RCxTQUFTLEVBQUUsR0FBRyxpQkFBaUIsU0FBUyxHQUFHLEVBQUUsUUFBUTtBQUFBLElBQ3ZEO0FBQUEsRUFDRjtBQU1PLE1BQU0sUUFBUSxPQUFNLG9CQUFJLEtBQUssR0FBRSxtQkFBbUIsT0FBTztBQUV6RCxNQUFNLGFBQWEsT0FBYyxFQUFFLE1BQU0sTUFBTSxHQUFHLFFBQVEsR0FBRyxRQUFRLEdBQUcsV0FBVyxFQUFFLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxFQUFFLEVBQUU7QUFFeEgsaUJBQXNCLFlBQTRCO0FBQ2hELFVBQU0sRUFBRSxNQUFNLElBQUksTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLE9BQU87QUFDeEQsVUFBTSxJQUFJO0FBQ1YsV0FBTyxLQUFLLEVBQUUsU0FBUyxNQUFNLElBQUksSUFBSSxXQUFXO0FBQUEsRUFDbEQ7QUFHQSxpQkFBc0IsWUFBWSxRQUFnQixVQUFvQztBQUNwRixVQUFNLElBQUksTUFBTSxVQUFVO0FBQzFCLE1BQUUsVUFBVTtBQUNaLFFBQUksVUFBVTtBQUNaLFFBQUU7QUFDRixRQUFFLFVBQVUsUUFBUTtBQUFBLElBQ3RCO0FBQ0EsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsT0FBTyxFQUFFLENBQUM7QUFBQSxFQUM3Qzs7O0FDNUNBLE1BQUksV0FBcUI7QUFDekIsTUFBSTtBQUVKLE1BQU0sU0FBUyxZQUFZO0FBQ3pCLGVBQVcsTUFBTSxhQUFhO0FBQzlCLGFBQVMsU0FBUyxTQUFTLElBQUksU0FBUyxTQUFTLFFBQVEsU0FBUyxLQUFLLElBQUk7QUFDM0UsV0FBTyxPQUFPO0FBQUEsRUFDaEIsR0FBRztBQUVILFNBQU8sUUFBUSxVQUFVLFlBQVksT0FBTyxZQUFZO0FBQ3RELFFBQUksQ0FBQyxRQUFRLFNBQVU7QUFDdkIsZUFBVyxNQUFNLGFBQWE7QUFDOUIsYUFBUyxTQUFTLFNBQVMsSUFBSSxTQUFTLFNBQVMsUUFBUSxTQUFTLEtBQUssSUFBSTtBQUFBLEVBQzdFLENBQUM7QUFFRCxNQUFJO0FBQ0osaUJBQWUsWUFBNkI7QUFDMUMsVUFBTSxLQUFLLE1BQU07QUFDakIsZUFBVyxJQUFJLE9BQU87QUFBQSxNQUNwQixPQUFPLElBQUksU0FBUyxFQUFFO0FBQUEsTUFDdEIsUUFBUSxNQUFNO0FBQUEsTUFDZCxRQUFRO0FBQUEsTUFDUixZQUFZLE1BQU0sU0FBUztBQUFBLE1BQzNCLGtCQUFrQixNQUFNLFNBQVM7QUFBQSxNQUNqQyxRQUFRLE9BQU8sU0FBVSxTQUFTLGNBQWMsUUFBUSxLQUFLLEtBQUssYUFBYSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFBQSxNQUNySCxRQUFRO0FBQUEsUUFDTixVQUFVLGFBQWEsTUFBTSxVQUFVLEdBQUcsU0FBUyxTQUFTO0FBQUEsUUFDNUQsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGLENBQUM7QUFDRCxXQUFPO0FBQUEsRUFDVDtBQUdBLE1BQU0sZUFBZTtBQUNyQixNQUFNLFdBQVcsT0FBTyxxQkFBcUIsR0FBRztBQUFBLElBQzlDLFFBQVEsSUFBSTtBQUNWLFNBQUcsa0JBQWtCLFlBQVksRUFBRSxTQUFTLE1BQU0sZUFBZSxLQUFLLENBQUM7QUFBQSxJQUN6RTtBQUFBLEVBQ0YsQ0FBQztBQUVELGlCQUFlLFlBQVksS0FBYSxNQUFlO0FBQ3JELFVBQU0sS0FBSyxNQUFNO0FBQ2pCLFVBQU0sR0FBRyxJQUFJLFlBQVksRUFBRSxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxDQUFDO0FBQ3RELFVBQU0sT0FBTyxNQUFNLEdBQUcsV0FBVyxVQUFVO0FBQzNDLGVBQVcsS0FBSyxLQUFLLE1BQU0sR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLFNBQVMsWUFBWSxDQUFDLEVBQUcsT0FBTSxHQUFHLE9BQU8sWUFBWSxDQUFDO0FBQUEsRUFDdkc7QUFRQSxTQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsS0FBVSxTQUFTLGlCQUFpQjtBQUN4RSxLQUFDLFlBQVk7QUFDWCxjQUFRLElBQUksTUFBTTtBQUFBLFFBQ2hCLEtBQUs7QUFDSCxrQkFBUSxNQUFNLFVBQVUsR0FBRyxPQUFPLElBQUksSUFBSTtBQUFBLFFBQzVDLEtBQUssU0FBUztBQUNaLGdCQUFNLEtBQUssTUFBTTtBQUNqQixnQkFBTSxHQUFHLElBQUksVUFBVSxFQUFFLEdBQUcsSUFBSSxPQUFPLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQztBQUN2RCxpQkFBTyxFQUFFLElBQUksS0FBSztBQUFBLFFBQ3BCO0FBQUEsUUFDQSxLQUFLLFdBQVc7QUFDZCxnQkFBTSxLQUFLLE1BQU07QUFDakIsZ0JBQU0sSUFBSSxTQUFTLEVBQUUsRUFBRSxXQUFXLEVBQUUsUUFBUSxJQUFJLFFBQVEsR0FBRyxJQUFJLE1BQU0sV0FBVyxLQUFLLElBQUksRUFBRSxDQUFDO0FBQzVGLGlCQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsUUFDcEI7QUFBQSxRQUNBLEtBQUs7QUFDSCxjQUFJLFNBQVMsZ0JBQWlCLE9BQU0sWUFBWSxJQUFJLEtBQUssSUFBSSxJQUFJO0FBQ2pFLGlCQUFPLEVBQUUsSUFBSSxLQUFLO0FBQUEsTUFDdEI7QUFBQSxJQUNGLEdBQUcsRUFDQSxLQUFLLFlBQVksRUFDakIsTUFBTSxDQUFDLE1BQU07QUFDWixjQUFRLEtBQUssaUJBQWlCLElBQUksTUFBTSxXQUFXLGFBQWEsUUFBUSxFQUFFLFVBQVUsQ0FBQztBQUNyRixtQkFBYSxNQUFTO0FBQUEsSUFDeEIsQ0FBQztBQUNILFdBQU87QUFBQSxFQUNULENBQUM7QUFFRCxTQUFPLFFBQVEsVUFBVSxZQUFZLE1BQU0sT0FBTyxRQUFRLGdCQUFnQixDQUFDOyIsCiAgIm5hbWVzIjogWyJ0YXJnZXQiLCAiY2xpZW50IiwgInNldHRpbmdzIl0KfQo=
