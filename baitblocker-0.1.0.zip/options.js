"use strict";
(() => {
  // node_modules/idb/build/index.js
  var instanceOfAny = (object, constructors) => constructors.some((c) => object instanceof c);
  var idbProxyableTypes;
  var cursorAdvanceMethods;
  function getIdbProxyableTypes() {
    return idbProxyableTypes || (idbProxyableTypes = [
      IDBIndex,
      IDBObjectStore,
      IDBCursor,
      IDBDatabase,
      IDBTransaction
    ]);
  }
  function getCursorAdvanceMethods() {
    return cursorAdvanceMethods || (cursorAdvanceMethods = ["advance", "continue", "continuePrimaryKey"].map((method) => IDBCursor.prototype[method]));
  }
  var transactionDoneMap = /* @__PURE__ */ new WeakMap();
  var transformCache = /* @__PURE__ */ new WeakMap();
  var reverseTransformCache = /* @__PURE__ */ new WeakMap();
  function promisifyRequest(request) {
    const promise = new Promise((resolve, reject) => {
      const unlisten = () => {
        request.removeEventListener("success", success);
        request.removeEventListener("error", error);
      };
      const success = () => {
        resolve(wrap(request.result));
        unlisten();
      };
      const error = () => {
        reject(request.error);
        unlisten();
      };
      request.addEventListener("success", success);
      request.addEventListener("error", error);
    });
    reverseTransformCache.set(promise, request);
    return promise;
  }
  function cacheDonePromiseForTransaction(tx) {
    if (transactionDoneMap.has(tx))
      return;
    const done = new Promise((resolve, reject) => {
      const unlisten = () => {
        tx.removeEventListener("complete", complete);
        tx.removeEventListener("error", error);
        tx.removeEventListener("abort", error);
      };
      const complete = () => {
        resolve();
        unlisten();
      };
      const error = () => {
        reject(tx.error || new DOMException("AbortError", "AbortError"));
        unlisten();
      };
      tx.addEventListener("complete", complete);
      tx.addEventListener("error", error);
      tx.addEventListener("abort", error);
    });
    transactionDoneMap.set(tx, done);
  }
  var idbProxyTraps = {
    get(target, prop, receiver) {
      if (target instanceof IDBTransaction) {
        if (prop === "done")
          return transactionDoneMap.get(target);
        if (prop === "store") {
          return receiver.objectStoreNames[1] ? void 0 : receiver.objectStore(receiver.objectStoreNames[0]);
        }
      }
      return wrap(target[prop]);
    },
    set(target, prop, value) {
      target[prop] = value;
      return true;
    },
    has(target, prop) {
      if (target instanceof IDBTransaction && (prop === "done" || prop === "store")) {
        return true;
      }
      return prop in target;
    }
  };
  function replaceTraps(callback) {
    idbProxyTraps = callback(idbProxyTraps);
  }
  function wrapFunction(func) {
    if (getCursorAdvanceMethods().includes(func)) {
      return function(...args) {
        func.apply(unwrap(this), args);
        return wrap(this.request);
      };
    }
    return function(...args) {
      return wrap(func.apply(unwrap(this), args));
    };
  }
  function transformCachableValue(value) {
    if (typeof value === "function")
      return wrapFunction(value);
    if (value instanceof IDBTransaction)
      cacheDonePromiseForTransaction(value);
    if (instanceOfAny(value, getIdbProxyableTypes()))
      return new Proxy(value, idbProxyTraps);
    return value;
  }
  function wrap(value) {
    if (value instanceof IDBRequest)
      return promisifyRequest(value);
    if (transformCache.has(value))
      return transformCache.get(value);
    const newValue = transformCachableValue(value);
    if (!Object.is(newValue, value)) {
      transformCache.set(value, newValue);
      reverseTransformCache.set(newValue, value);
    }
    return newValue;
  }
  var unwrap = (value) => reverseTransformCache.get(value);
  function openDB(name, version, { blocked, upgrade, blocking, terminated } = {}) {
    const request = indexedDB.open(name, version);
    const openPromise = wrap(request);
    if (upgrade) {
      request.addEventListener("upgradeneeded", (event) => {
        upgrade(wrap(request.result), event.oldVersion, event.newVersion, wrap(request.transaction), event);
      });
    }
    if (blocked) {
      request.addEventListener("blocked", (event) => blocked(
        // Casting due to https://github.com/microsoft/TypeScript-DOM-lib-generator/pull/1405
        event.oldVersion,
        event.newVersion,
        event
      ));
    }
    openPromise.then((db) => {
      if (terminated)
        db.addEventListener("close", () => terminated());
      if (blocking) {
        db.addEventListener("versionchange", (event) => blocking(event.oldVersion, event.newVersion, event));
      }
    }).catch(() => {
    });
    return openPromise;
  }
  var readMethods = ["get", "getKey", "getAll", "getAllKeys", "count"];
  var writeMethods = ["put", "add", "delete", "clear"];
  var cachedMethods = {};
  function getMethod(target, prop) {
    if (!(target instanceof IDBDatabase && !(prop in target) && typeof prop === "string")) {
      return;
    }
    if (cachedMethods[prop])
      return cachedMethods[prop];
    const targetFuncName = prop.replace(/FromIndex$/, "");
    const useIndex = prop !== targetFuncName;
    const isWrite = writeMethods.includes(targetFuncName);
    if (
      // Bail if the target doesn't exist on the target. Eg, getAll isn't in Edge.
      !(targetFuncName in (useIndex ? IDBIndex : IDBObjectStore).prototype) || !(isWrite || readMethods.includes(targetFuncName))
    ) {
      return;
    }
    const method = async function(storeName, ...args) {
      const tx = this.transaction(storeName, isWrite ? "readwrite" : "readonly");
      let target2 = tx.store;
      if (useIndex)
        target2 = target2.index(args.shift());
      return (await Promise.all([
        target2[targetFuncName](...args),
        isWrite && tx.done
      ]))[0];
    };
    return cachedMethods[prop] = method;
  }
  replaceTraps((oldTraps) => ({
    ...oldTraps,
    get: (target, prop, receiver) => getMethod(target, prop) || oldTraps.get(target, prop, receiver),
    has: (target, prop) => !!getMethod(target, prop) || oldTraps.has(target, prop)
  }));
  var advanceMethodProps = ["advance", "continue", "continuePrimaryKey"];
  var methodMap = {};
  var advanceResults = /* @__PURE__ */ new WeakMap();
  var ittrProxiedCursorToOriginalProxy = /* @__PURE__ */ new WeakMap();
  var cursorIteratorTraps = {
    get(target, prop) {
      if (!advanceMethodProps.includes(prop))
        return target[prop];
      let cachedFunc = methodMap[prop];
      if (!cachedFunc) {
        cachedFunc = methodMap[prop] = function(...args) {
          advanceResults.set(this, ittrProxiedCursorToOriginalProxy.get(this)[prop](...args));
        };
      }
      return cachedFunc;
    }
  };
  async function* iterate(...args) {
    let cursor = this;
    if (!(cursor instanceof IDBCursor)) {
      cursor = await cursor.openCursor(...args);
    }
    if (!cursor)
      return;
    cursor = cursor;
    const proxiedCursor = new Proxy(cursor, cursorIteratorTraps);
    ittrProxiedCursorToOriginalProxy.set(proxiedCursor, cursor);
    reverseTransformCache.set(proxiedCursor, unwrap(cursor));
    while (cursor) {
      yield proxiedCursor;
      cursor = await (advanceResults.get(proxiedCursor) || cursor.continue());
      advanceResults.delete(proxiedCursor);
    }
  }
  function isIteratorProp(target, prop) {
    return prop === Symbol.asyncIterator && instanceOfAny(target, [IDBIndex, IDBObjectStore, IDBCursor]) || prop === "iterate" && instanceOfAny(target, [IDBIndex, IDBObjectStore]);
  }
  replaceTraps((oldTraps) => ({
    ...oldTraps,
    get(target, prop, receiver) {
      if (isIteratorProp(target, prop))
        return iterate;
      return oldTraps.get(target, prop, receiver);
    },
    has(target, prop) {
      return isIteratorProp(target, prop) || oldTraps.has(target, prop);
    }
  }));

  // src/csv.ts
  function parseCsv(input) {
    const rows = [];
    let row = [];
    let field = "";
    let quoted = false;
    const s = input.replace(/^﻿/, "");
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (quoted) {
        if (c === '"') {
          if (s[i + 1] === '"') {
            field += '"';
            i++;
          } else quoted = false;
        } else field += c;
      } else if (c === '"') quoted = true;
      else if (c === ",") {
        row.push(field);
        field = "";
      } else if (c === "\n" || c === "\r") {
        if (c === "\r" && s[i + 1] === "\n") i++;
        row.push(field);
        rows.push(row);
        row = [];
        field = "";
      } else field += c;
    }
    if (field || row.length) {
      row.push(field);
      rows.push(row);
    }
    return rows.filter((r) => r.some((f) => f !== ""));
  }
  function csvToSeeds(input) {
    const [header, ...rows] = parseCsv(input);
    if (!header) return [];
    const hi = header.indexOf("account_handle");
    const di = header.indexOf("description");
    if (hi < 0) throw new Error("CSV has no account_handle column");
    return rows.filter((r) => r[hi]).map((r) => ({ handle: r[hi], text: di >= 0 ? r[di] ?? "" : "" }));
  }

  // src/db.ts
  function openDb(name = "baitblocker") {
    return openDB(name, 2, {
      upgrade(db, oldVersion) {
        if (oldVersion < 1) {
          db.createObjectStore("posts", { keyPath: "id" });
          const labels = db.createObjectStore("labels", { keyPath: "id", autoIncrement: true });
          labels.createIndex("postId", "postId");
          db.createObjectStore("authors", { keyPath: "handle" });
        }
        if (oldVersion < 2) db.createObjectStore("countries", { keyPath: "handle" });
      }
    });
  }
  var normHandle = (h) => h.trim().replace(/^@/, "").toLowerCase();
  var newAuthor = (handle) => ({ handle, alpha: 1, beta: 1, seeded: false, postsSeen: 0 });
  var authorScore = (a) => a.alpha / (a.alpha + a.beta);
  async function importSeeds(db, seeds) {
    const tx = db.transaction("authors", "readwrite");
    let n = 0;
    for (const s of seeds) {
      if (!s?.handle) continue;
      const handle = normHandle(s.handle);
      if (!handle) continue;
      const existing = await tx.store.get(handle) ?? newAuthor(handle);
      await tx.store.put({ ...existing, seeded: true, seedText: s.text ?? existing.seedText });
      n++;
    }
    await tx.done;
    return n;
  }
  async function exportLabels(db) {
    const labels = await db.getAll("labels");
    const lines = [];
    for (const l of labels) lines.push(JSON.stringify({ ...l, post: await db.get("posts", l.postId) ?? null }));
    return lines.join("\n") + (lines.length ? "\n" : "");
  }
  async function exportAuthors(db) {
    const authors = await db.getAll("authors");
    return authors.map((a) => JSON.stringify({ ...a, score: authorScore(a) })).join("\n") + (authors.length ? "\n" : "");
  }

  // config/questions.json
  var questions_default = {
    version: 7,
    questions: [
      {
        id: "us_politics",
        text: "Is this post (including any text in attached images) about United States politics, economics, or culture war, written as if the author lives in the US? Examples: Democrats or Republicans, US politicians, the minimum wage or prices in dollars, rent or wages in US cities, US healthcare or insurance, taxes, student loans, guns, immigration, or 'in this country' complaints about America. Answer no for posts that are not about the US, and for neutral news reports."
      },
      {
        id: "ideology_bait",
        text: 'Is this post (including any text in attached images) a sweeping, low-effort take designed to farm replies on a divisive theme, such as capitalism vs socialism, billionaires or the rich, the working class, or rejecting modern technology ("nobody wants self-driving cars", AI, smartphones, cashless payments), stated as a slogan or bold claim rather than a specific argument? Answer no for specific, substantive arguments, news, or personal anecdotes without a provocative generalization.'
      }
    ],
    combine: {
      max_of: [
        "us_politics",
        "ideology_bait"
      ],
      weighted: {}
    },
    thresholds: {
      hide: 0.8,
      blur: 0.5
    },
    stance: {
      id: "endorses_quote",
      text: "A reply-quote: the author wrote the first part, quoting the post after [Quoted post]. Does the author side with the quoted post, wanting readers to agree with it? Answer no if the author is mocking it, arguing against it, correcting it, warning people about it, or commenting on something else.",
      threshold: 0.8
    }
  };

  // src/settings.ts
  var QUESTIONS = questions_default;
  var DEFAULT_SETTINGS = {
    apiKey: "",
    model: "d1.1",
    thresholds: { ...QUESTIONS.thresholds },
    enabled: { pending: true, hide: true, blur: true, flag: true },
    dailyTokenBudget: 1e6,
    captureFixtures: false,
    allowedCountries: ["United States", "North America"],
    scoreImages: true
  };
  async function loadSettings() {
    const { settings } = await chrome.storage.local.get("settings");
    const s = settings ?? {};
    const saved = s.thresholdsFor === QUESTIONS.version ? s.thresholds : void 0;
    return {
      ...DEFAULT_SETTINGS,
      ...s,
      thresholds: { ...DEFAULT_SETTINGS.thresholds, ...saved },
      enabled: { ...DEFAULT_SETTINGS.enabled, ...s.enabled }
    };
  }
  async function saveSettings(s) {
    await chrome.storage.local.set({ settings: { ...s, thresholdsFor: QUESTIONS.version } });
  }
  var today = () => (/* @__PURE__ */ new Date()).toLocaleDateString("en-CA");
  var emptyUsage = () => ({ date: today(), tokens: 0, scored: 0, decisions: { hide: 0, blur: 0, show: 0 } });
  async function loadUsage() {
    const { usage } = await chrome.storage.local.get("usage");
    const u = usage;
    return u && u.date === today() ? u : emptyUsage();
  }

  // src/options.ts
  var $ = (id) => document.getElementById(id);
  var dbP = openDb();
  function status(id, msg, ok = true) {
    const n = $(id);
    n.textContent = msg;
    n.className = `status ${ok ? "ok" : "err"}`;
  }
  async function fill() {
    const s = await loadSettings();
    $("apiKey").value = s.apiKey;
    $("model").value = s.model;
    $("budget").value = String(s.dailyTokenBudget);
    $("tHide").value = String(s.thresholds.hide);
    $("tBlur").value = String(s.thresholds.blur);
    $("enPending").checked = s.enabled.pending;
    $("enHide").checked = s.enabled.hide;
    $("enBlur").checked = s.enabled.blur;
    $("enFlag").checked = s.enabled.flag;
    $("capture").checked = s.captureFixtures;
    $("allowed").value = s.allowedCountries.join(", ");
    $("scoreImages").checked = s.scoreImages;
  }
  $("save").addEventListener("click", async () => {
    const hide = Number($("tHide").value);
    const blur = Number($("tBlur").value);
    if (!(blur >= 0 && hide <= 1 && blur <= hide)) return status("saveStatus", "Need 0 \u2264 blur \u2264 hide \u2264 1", false);
    const s = await loadSettings();
    await saveSettings({
      ...s,
      apiKey: $("apiKey").value.trim(),
      model: $("model").value,
      dailyTokenBudget: Number($("budget").value) || 0,
      thresholds: { hide, blur },
      enabled: { pending: $("enPending").checked, hide: $("enHide").checked, blur: $("enBlur").checked, flag: $("enFlag").checked },
      captureFixtures: $("capture").checked,
      scoreImages: $("scoreImages").checked,
      allowedCountries: $("allowed").value.split(",").map((c) => c.trim()).filter(Boolean)
    });
    status("saveStatus", "Saved");
  });
  async function doImport(seeds) {
    const n = await importSeeds(await dbP, seeds);
    status("seedStatus", `Imported ${n} accounts`);
    stats();
  }
  $("importJson").addEventListener("click", async () => {
    try {
      const data = JSON.parse($("seedJson").value);
      if (!Array.isArray(data)) throw new Error("Expected a JSON array");
      await doImport(data);
    } catch (e) {
      status("seedStatus", e.message, false);
    }
  });
  $("seedCsv").addEventListener("change", async () => {
    const file = $("seedCsv").files?.[0];
    if (!file) return;
    try {
      await doImport(csvToSeeds(await file.text()));
    } catch (e) {
      status("seedStatus", e.message, false);
    }
  });
  function download(name, text, type = "application/x-ndjson") {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1e3);
  }
  $("exportLabels").addEventListener("click", async () => download("labels.jsonl", await exportLabels(await dbP)));
  $("exportAuthors").addEventListener("click", async () => download("authors.jsonl", await exportAuthors(await dbP)));
  $("exportCaptures").addEventListener("click", async () => {
    const db = await openDB("baitblocker-debug", 1, {
      upgrade(d) {
        d.createObjectStore("captures", { keyPath: "id", autoIncrement: true });
      }
    });
    const all = await db.getAll("captures");
    if (!all.length) return status("exportStatus", "No captures yet: enable capture, save, and browse x.com", false);
    download("captures.json", JSON.stringify(all, null, 1), "application/json");
    status("exportStatus", `${all.length} responses`);
  });
  async function stats() {
    const db = await dbP;
    const u = await loadUsage();
    const authors = await db.getAll("authors");
    const rows = [
      ["Posts scored today", u.scored],
      ["Input tokens today", u.tokens.toLocaleString()],
      ["Today hide / blur / show", `${u.decisions.hide} / ${u.decisions.blur} / ${u.decisions.show}`],
      ["Cached posts (all time)", await db.count("posts")],
      ["Labels", await db.count("labels")],
      ["Countries cached", await db.count("countries")],
      ["Authors tracked / seeded", `${authors.length} / ${authors.filter((a) => a.seeded).length}`]
    ];
    const t = $("stats");
    t.replaceChildren(
      ...rows.map(([k, v]) => {
        const tr = document.createElement("tr");
        const a = document.createElement("td");
        const b = document.createElement("td");
        a.textContent = k;
        b.textContent = String(v);
        tr.append(a, b);
        return tr;
      })
    );
  }
  $("refresh").addEventListener("click", stats);
  fill();
  stats();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vbm9kZV9tb2R1bGVzL2lkYi9idWlsZC9pbmRleC5qcyIsICIuLi9zcmMvY3N2LnRzIiwgIi4uL3NyYy9kYi50cyIsICIuLi9jb25maWcvcXVlc3Rpb25zLmpzb24iLCAiLi4vc3JjL3NldHRpbmdzLnRzIiwgIi4uL3NyYy9vcHRpb25zLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJjb25zdCBpbnN0YW5jZU9mQW55ID0gKG9iamVjdCwgY29uc3RydWN0b3JzKSA9PiBjb25zdHJ1Y3RvcnMuc29tZSgoYykgPT4gb2JqZWN0IGluc3RhbmNlb2YgYyk7XG5cbmxldCBpZGJQcm94eWFibGVUeXBlcztcbmxldCBjdXJzb3JBZHZhbmNlTWV0aG9kcztcbi8vIFRoaXMgaXMgYSBmdW5jdGlvbiB0byBwcmV2ZW50IGl0IHRocm93aW5nIHVwIGluIG5vZGUgZW52aXJvbm1lbnRzLlxuZnVuY3Rpb24gZ2V0SWRiUHJveHlhYmxlVHlwZXMoKSB7XG4gICAgcmV0dXJuIChpZGJQcm94eWFibGVUeXBlcyB8fFxuICAgICAgICAoaWRiUHJveHlhYmxlVHlwZXMgPSBbXG4gICAgICAgICAgICBJREJJbmRleCxcbiAgICAgICAgICAgIElEQk9iamVjdFN0b3JlLFxuICAgICAgICAgICAgSURCQ3Vyc29yLFxuICAgICAgICAgICAgSURCRGF0YWJhc2UsXG4gICAgICAgICAgICBJREJUcmFuc2FjdGlvbixcbiAgICAgICAgXSkpO1xufVxuLy8gVGhpcyBpcyBhIGZ1bmN0aW9uIHRvIHByZXZlbnQgaXQgdGhyb3dpbmcgdXAgaW4gbm9kZSBlbnZpcm9ubWVudHMuXG5mdW5jdGlvbiBnZXRDdXJzb3JBZHZhbmNlTWV0aG9kcygpIHtcbiAgICByZXR1cm4gKGN1cnNvckFkdmFuY2VNZXRob2RzIHx8XG4gICAgICAgIChjdXJzb3JBZHZhbmNlTWV0aG9kcyA9IFsnYWR2YW5jZScsICdjb250aW51ZScsICdjb250aW51ZVByaW1hcnlLZXknXS5tYXAoKG1ldGhvZCkgPT4gSURCQ3Vyc29yLnByb3RvdHlwZVttZXRob2RdKSkpO1xufVxuY29uc3QgdHJhbnNhY3Rpb25Eb25lTWFwID0gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IHRyYW5zZm9ybUNhY2hlID0gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IHJldmVyc2VUcmFuc2Zvcm1DYWNoZSA9IG5ldyBXZWFrTWFwKCk7XG5mdW5jdGlvbiBwcm9taXNpZnlSZXF1ZXN0KHJlcXVlc3QpIHtcbiAgICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBjb25zdCB1bmxpc3RlbiA9ICgpID0+IHtcbiAgICAgICAgICAgIHJlcXVlc3QucmVtb3ZlRXZlbnRMaXN0ZW5lcignc3VjY2VzcycsIHN1Y2Nlc3MpO1xuICAgICAgICAgICAgcmVxdWVzdC5yZW1vdmVFdmVudExpc3RlbmVyKCdlcnJvcicsIGVycm9yKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3Qgc3VjY2VzcyA9ICgpID0+IHtcbiAgICAgICAgICAgIHJlc29sdmUod3JhcChyZXF1ZXN0LnJlc3VsdCkpO1xuICAgICAgICAgICAgdW5saXN0ZW4oKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgZXJyb3IgPSAoKSA9PiB7XG4gICAgICAgICAgICByZWplY3QocmVxdWVzdC5lcnJvcik7XG4gICAgICAgICAgICB1bmxpc3RlbigpO1xuICAgICAgICB9O1xuICAgICAgICByZXF1ZXN0LmFkZEV2ZW50TGlzdGVuZXIoJ3N1Y2Nlc3MnLCBzdWNjZXNzKTtcbiAgICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKCdlcnJvcicsIGVycm9yKTtcbiAgICB9KTtcbiAgICAvLyBUaGlzIG1hcHBpbmcgZXhpc3RzIGluIHJldmVyc2VUcmFuc2Zvcm1DYWNoZSBidXQgZG9lc24ndCBleGlzdCBpbiB0cmFuc2Zvcm1DYWNoZS4gVGhpc1xuICAgIC8vIGlzIGJlY2F1c2Ugd2UgY3JlYXRlIG1hbnkgcHJvbWlzZXMgZnJvbSBhIHNpbmdsZSBJREJSZXF1ZXN0LlxuICAgIHJldmVyc2VUcmFuc2Zvcm1DYWNoZS5zZXQocHJvbWlzZSwgcmVxdWVzdCk7XG4gICAgcmV0dXJuIHByb21pc2U7XG59XG5mdW5jdGlvbiBjYWNoZURvbmVQcm9taXNlRm9yVHJhbnNhY3Rpb24odHgpIHtcbiAgICAvLyBFYXJseSBiYWlsIGlmIHdlJ3ZlIGFscmVhZHkgY3JlYXRlZCBhIGRvbmUgcHJvbWlzZSBmb3IgdGhpcyB0cmFuc2FjdGlvbi5cbiAgICBpZiAodHJhbnNhY3Rpb25Eb25lTWFwLmhhcyh0eCkpXG4gICAgICAgIHJldHVybjtcbiAgICBjb25zdCBkb25lID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBjb25zdCB1bmxpc3RlbiA9ICgpID0+IHtcbiAgICAgICAgICAgIHR4LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2NvbXBsZXRlJywgY29tcGxldGUpO1xuICAgICAgICAgICAgdHgucmVtb3ZlRXZlbnRMaXN0ZW5lcignZXJyb3InLCBlcnJvcik7XG4gICAgICAgICAgICB0eC5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIGVycm9yKTtcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgY29tcGxldGUgPSAoKSA9PiB7XG4gICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB1bmxpc3RlbigpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBlcnJvciA9ICgpID0+IHtcbiAgICAgICAgICAgIHJlamVjdCh0eC5lcnJvciB8fCBuZXcgRE9NRXhjZXB0aW9uKCdBYm9ydEVycm9yJywgJ0Fib3J0RXJyb3InKSk7XG4gICAgICAgICAgICB1bmxpc3RlbigpO1xuICAgICAgICB9O1xuICAgICAgICB0eC5hZGRFdmVudExpc3RlbmVyKCdjb21wbGV0ZScsIGNvbXBsZXRlKTtcbiAgICAgICAgdHguYWRkRXZlbnRMaXN0ZW5lcignZXJyb3InLCBlcnJvcik7XG4gICAgICAgIHR4LmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgZXJyb3IpO1xuICAgIH0pO1xuICAgIC8vIENhY2hlIGl0IGZvciBsYXRlciByZXRyaWV2YWwuXG4gICAgdHJhbnNhY3Rpb25Eb25lTWFwLnNldCh0eCwgZG9uZSk7XG59XG5sZXQgaWRiUHJveHlUcmFwcyA9IHtcbiAgICBnZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuICAgICAgICBpZiAodGFyZ2V0IGluc3RhbmNlb2YgSURCVHJhbnNhY3Rpb24pIHtcbiAgICAgICAgICAgIC8vIFNwZWNpYWwgaGFuZGxpbmcgZm9yIHRyYW5zYWN0aW9uLmRvbmUuXG4gICAgICAgICAgICBpZiAocHJvcCA9PT0gJ2RvbmUnKVxuICAgICAgICAgICAgICAgIHJldHVybiB0cmFuc2FjdGlvbkRvbmVNYXAuZ2V0KHRhcmdldCk7XG4gICAgICAgICAgICAvLyBNYWtlIHR4LnN0b3JlIHJldHVybiB0aGUgb25seSBzdG9yZSBpbiB0aGUgdHJhbnNhY3Rpb24sIG9yIHVuZGVmaW5lZCBpZiB0aGVyZSBhcmUgbWFueS5cbiAgICAgICAgICAgIGlmIChwcm9wID09PSAnc3RvcmUnKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlY2VpdmVyLm9iamVjdFN0b3JlTmFtZXNbMV1cbiAgICAgICAgICAgICAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICAgICAgOiByZWNlaXZlci5vYmplY3RTdG9yZShyZWNlaXZlci5vYmplY3RTdG9yZU5hbWVzWzBdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBFbHNlIHRyYW5zZm9ybSB3aGF0ZXZlciB3ZSBnZXQgYmFjay5cbiAgICAgICAgcmV0dXJuIHdyYXAodGFyZ2V0W3Byb3BdKTtcbiAgICB9LFxuICAgIHNldCh0YXJnZXQsIHByb3AsIHZhbHVlKSB7XG4gICAgICAgIHRhcmdldFtwcm9wXSA9IHZhbHVlO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuICAgIGhhcyh0YXJnZXQsIHByb3ApIHtcbiAgICAgICAgaWYgKHRhcmdldCBpbnN0YW5jZW9mIElEQlRyYW5zYWN0aW9uICYmXG4gICAgICAgICAgICAocHJvcCA9PT0gJ2RvbmUnIHx8IHByb3AgPT09ICdzdG9yZScpKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcHJvcCBpbiB0YXJnZXQ7XG4gICAgfSxcbn07XG5mdW5jdGlvbiByZXBsYWNlVHJhcHMoY2FsbGJhY2spIHtcbiAgICBpZGJQcm94eVRyYXBzID0gY2FsbGJhY2soaWRiUHJveHlUcmFwcyk7XG59XG5mdW5jdGlvbiB3cmFwRnVuY3Rpb24oZnVuYykge1xuICAgIC8vIER1ZSB0byBleHBlY3RlZCBvYmplY3QgZXF1YWxpdHkgKHdoaWNoIGlzIGVuZm9yY2VkIGJ5IHRoZSBjYWNoaW5nIGluIGB3cmFwYCksIHdlXG4gICAgLy8gb25seSBjcmVhdGUgb25lIG5ldyBmdW5jIHBlciBmdW5jLlxuICAgIC8vIEN1cnNvciBtZXRob2RzIGFyZSBzcGVjaWFsLCBhcyB0aGUgYmVoYXZpb3VyIGlzIGEgbGl0dGxlIG1vcmUgZGlmZmVyZW50IHRvIHN0YW5kYXJkIElEQi4gSW5cbiAgICAvLyBJREIsIHlvdSBhZHZhbmNlIHRoZSBjdXJzb3IgYW5kIHdhaXQgZm9yIGEgbmV3ICdzdWNjZXNzJyBvbiB0aGUgSURCUmVxdWVzdCB0aGF0IGdhdmUgeW91IHRoZVxuICAgIC8vIGN1cnNvci4gSXQncyBraW5kYSBsaWtlIGEgcHJvbWlzZSB0aGF0IGNhbiByZXNvbHZlIHdpdGggbWFueSB2YWx1ZXMuIFRoYXQgZG9lc24ndCBtYWtlIHNlbnNlXG4gICAgLy8gd2l0aCByZWFsIHByb21pc2VzLCBzbyBlYWNoIGFkdmFuY2UgbWV0aG9kcyByZXR1cm5zIGEgbmV3IHByb21pc2UgZm9yIHRoZSBjdXJzb3Igb2JqZWN0LCBvclxuICAgIC8vIHVuZGVmaW5lZCBpZiB0aGUgZW5kIG9mIHRoZSBjdXJzb3IgaGFzIGJlZW4gcmVhY2hlZC5cbiAgICBpZiAoZ2V0Q3Vyc29yQWR2YW5jZU1ldGhvZHMoKS5pbmNsdWRlcyhmdW5jKSkge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgICAgIC8vIENhbGxpbmcgdGhlIG9yaWdpbmFsIGZ1bmN0aW9uIHdpdGggdGhlIHByb3h5IGFzICd0aGlzJyBjYXVzZXMgSUxMRUdBTCBJTlZPQ0FUSU9OLCBzbyB3ZSB1c2VcbiAgICAgICAgICAgIC8vIHRoZSBvcmlnaW5hbCBvYmplY3QuXG4gICAgICAgICAgICBmdW5jLmFwcGx5KHVud3JhcCh0aGlzKSwgYXJncyk7XG4gICAgICAgICAgICByZXR1cm4gd3JhcCh0aGlzLnJlcXVlc3QpO1xuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgLy8gQ2FsbGluZyB0aGUgb3JpZ2luYWwgZnVuY3Rpb24gd2l0aCB0aGUgcHJveHkgYXMgJ3RoaXMnIGNhdXNlcyBJTExFR0FMIElOVk9DQVRJT04sIHNvIHdlIHVzZVxuICAgICAgICAvLyB0aGUgb3JpZ2luYWwgb2JqZWN0LlxuICAgICAgICByZXR1cm4gd3JhcChmdW5jLmFwcGx5KHVud3JhcCh0aGlzKSwgYXJncykpO1xuICAgIH07XG59XG5mdW5jdGlvbiB0cmFuc2Zvcm1DYWNoYWJsZVZhbHVlKHZhbHVlKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgcmV0dXJuIHdyYXBGdW5jdGlvbih2YWx1ZSk7XG4gICAgLy8gVGhpcyBkb2Vzbid0IHJldHVybiwgaXQganVzdCBjcmVhdGVzIGEgJ2RvbmUnIHByb21pc2UgZm9yIHRoZSB0cmFuc2FjdGlvbixcbiAgICAvLyB3aGljaCBpcyBsYXRlciByZXR1cm5lZCBmb3IgdHJhbnNhY3Rpb24uZG9uZSAoc2VlIGlkYk9iamVjdEhhbmRsZXIpLlxuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIElEQlRyYW5zYWN0aW9uKVxuICAgICAgICBjYWNoZURvbmVQcm9taXNlRm9yVHJhbnNhY3Rpb24odmFsdWUpO1xuICAgIGlmIChpbnN0YW5jZU9mQW55KHZhbHVlLCBnZXRJZGJQcm94eWFibGVUeXBlcygpKSlcbiAgICAgICAgcmV0dXJuIG5ldyBQcm94eSh2YWx1ZSwgaWRiUHJveHlUcmFwcyk7XG4gICAgLy8gUmV0dXJuIHRoZSBzYW1lIHZhbHVlIGJhY2sgaWYgd2UncmUgbm90IGdvaW5nIHRvIHRyYW5zZm9ybSBpdC5cbiAgICByZXR1cm4gdmFsdWU7XG59XG5mdW5jdGlvbiB3cmFwKHZhbHVlKSB7XG4gICAgLy8gV2Ugc29tZXRpbWVzIGdlbmVyYXRlIG11bHRpcGxlIHByb21pc2VzIGZyb20gYSBzaW5nbGUgSURCUmVxdWVzdCAoZWcgd2hlbiBjdXJzb3JpbmcpLCBiZWNhdXNlXG4gICAgLy8gSURCIGlzIHdlaXJkIGFuZCBhIHNpbmdsZSBJREJSZXF1ZXN0IGNhbiB5aWVsZCBtYW55IHJlc3BvbnNlcywgc28gdGhlc2UgY2FuJ3QgYmUgY2FjaGVkLlxuICAgIGlmICh2YWx1ZSBpbnN0YW5jZW9mIElEQlJlcXVlc3QpXG4gICAgICAgIHJldHVybiBwcm9taXNpZnlSZXF1ZXN0KHZhbHVlKTtcbiAgICAvLyBJZiB3ZSd2ZSBhbHJlYWR5IHRyYW5zZm9ybWVkIHRoaXMgdmFsdWUgYmVmb3JlLCByZXVzZSB0aGUgdHJhbnNmb3JtZWQgdmFsdWUuXG4gICAgLy8gVGhpcyBpcyBmYXN0ZXIsIGJ1dCBpdCBhbHNvIHByb3ZpZGVzIG9iamVjdCBlcXVhbGl0eS5cbiAgICBpZiAodHJhbnNmb3JtQ2FjaGUuaGFzKHZhbHVlKSlcbiAgICAgICAgcmV0dXJuIHRyYW5zZm9ybUNhY2hlLmdldCh2YWx1ZSk7XG4gICAgY29uc3QgbmV3VmFsdWUgPSB0cmFuc2Zvcm1DYWNoYWJsZVZhbHVlKHZhbHVlKTtcbiAgICAvLyBOb3QgYWxsIHR5cGVzIGFyZSB0cmFuc2Zvcm1lZC5cbiAgICAvLyBUaGVzZSBtYXkgYmUgcHJpbWl0aXZlIHR5cGVzLCBzbyB0aGV5IGNhbid0IGJlIFdlYWtNYXAga2V5cy5cbiAgICBpZiAoIU9iamVjdC5pcyhuZXdWYWx1ZSwgdmFsdWUpKSB7XG4gICAgICAgIHRyYW5zZm9ybUNhY2hlLnNldCh2YWx1ZSwgbmV3VmFsdWUpO1xuICAgICAgICByZXZlcnNlVHJhbnNmb3JtQ2FjaGUuc2V0KG5ld1ZhbHVlLCB2YWx1ZSk7XG4gICAgfVxuICAgIHJldHVybiBuZXdWYWx1ZTtcbn1cbmNvbnN0IHVud3JhcCA9ICh2YWx1ZSkgPT4gcmV2ZXJzZVRyYW5zZm9ybUNhY2hlLmdldCh2YWx1ZSk7XG5cbi8qKlxuICogT3BlbiBhIGRhdGFiYXNlLlxuICpcbiAqIEBwYXJhbSBuYW1lIE5hbWUgb2YgdGhlIGRhdGFiYXNlLlxuICogQHBhcmFtIHZlcnNpb24gU2NoZW1hIHZlcnNpb24uXG4gKiBAcGFyYW0gY2FsbGJhY2tzIEFkZGl0aW9uYWwgY2FsbGJhY2tzLlxuICovXG5mdW5jdGlvbiBvcGVuREIobmFtZSwgdmVyc2lvbiwgeyBibG9ja2VkLCB1cGdyYWRlLCBibG9ja2luZywgdGVybWluYXRlZCB9ID0ge30pIHtcbiAgICBjb25zdCByZXF1ZXN0ID0gaW5kZXhlZERCLm9wZW4obmFtZSwgdmVyc2lvbik7XG4gICAgY29uc3Qgb3BlblByb21pc2UgPSB3cmFwKHJlcXVlc3QpO1xuICAgIGlmICh1cGdyYWRlKSB7XG4gICAgICAgIHJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcigndXBncmFkZW5lZWRlZCcsIChldmVudCkgPT4ge1xuICAgICAgICAgICAgdXBncmFkZSh3cmFwKHJlcXVlc3QucmVzdWx0KSwgZXZlbnQub2xkVmVyc2lvbiwgZXZlbnQubmV3VmVyc2lvbiwgd3JhcChyZXF1ZXN0LnRyYW5zYWN0aW9uKSwgZXZlbnQpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgaWYgKGJsb2NrZWQpIHtcbiAgICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKCdibG9ja2VkJywgKGV2ZW50KSA9PiBibG9ja2VkKFxuICAgICAgICAvLyBDYXN0aW5nIGR1ZSB0byBodHRwczovL2dpdGh1Yi5jb20vbWljcm9zb2Z0L1R5cGVTY3JpcHQtRE9NLWxpYi1nZW5lcmF0b3IvcHVsbC8xNDA1XG4gICAgICAgIGV2ZW50Lm9sZFZlcnNpb24sIGV2ZW50Lm5ld1ZlcnNpb24sIGV2ZW50KSk7XG4gICAgfVxuICAgIG9wZW5Qcm9taXNlXG4gICAgICAgIC50aGVuKChkYikgPT4ge1xuICAgICAgICBpZiAodGVybWluYXRlZClcbiAgICAgICAgICAgIGRiLmFkZEV2ZW50TGlzdGVuZXIoJ2Nsb3NlJywgKCkgPT4gdGVybWluYXRlZCgpKTtcbiAgICAgICAgaWYgKGJsb2NraW5nKSB7XG4gICAgICAgICAgICBkYi5hZGRFdmVudExpc3RlbmVyKCd2ZXJzaW9uY2hhbmdlJywgKGV2ZW50KSA9PiBibG9ja2luZyhldmVudC5vbGRWZXJzaW9uLCBldmVudC5uZXdWZXJzaW9uLCBldmVudCkpO1xuICAgICAgICB9XG4gICAgfSlcbiAgICAgICAgLmNhdGNoKCgpID0+IHsgfSk7XG4gICAgcmV0dXJuIG9wZW5Qcm9taXNlO1xufVxuLyoqXG4gKiBEZWxldGUgYSBkYXRhYmFzZS5cbiAqXG4gKiBAcGFyYW0gbmFtZSBOYW1lIG9mIHRoZSBkYXRhYmFzZS5cbiAqL1xuZnVuY3Rpb24gZGVsZXRlREIobmFtZSwgeyBibG9ja2VkIH0gPSB7fSkge1xuICAgIGNvbnN0IHJlcXVlc3QgPSBpbmRleGVkREIuZGVsZXRlRGF0YWJhc2UobmFtZSk7XG4gICAgaWYgKGJsb2NrZWQpIHtcbiAgICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKCdibG9ja2VkJywgKGV2ZW50KSA9PiBibG9ja2VkKFxuICAgICAgICAvLyBDYXN0aW5nIGR1ZSB0byBodHRwczovL2dpdGh1Yi5jb20vbWljcm9zb2Z0L1R5cGVTY3JpcHQtRE9NLWxpYi1nZW5lcmF0b3IvcHVsbC8xNDA1XG4gICAgICAgIGV2ZW50Lm9sZFZlcnNpb24sIGV2ZW50KSk7XG4gICAgfVxuICAgIHJldHVybiB3cmFwKHJlcXVlc3QpLnRoZW4oKCkgPT4gdW5kZWZpbmVkKTtcbn1cblxuY29uc3QgcmVhZE1ldGhvZHMgPSBbJ2dldCcsICdnZXRLZXknLCAnZ2V0QWxsJywgJ2dldEFsbEtleXMnLCAnY291bnQnXTtcbmNvbnN0IHdyaXRlTWV0aG9kcyA9IFsncHV0JywgJ2FkZCcsICdkZWxldGUnLCAnY2xlYXInXTtcbmNvbnN0IGNhY2hlZE1ldGhvZHMgPSB7fTtcbmZ1bmN0aW9uIGdldE1ldGhvZCh0YXJnZXQsIHByb3ApIHtcbiAgICBpZiAoISh0YXJnZXQgaW5zdGFuY2VvZiBJREJEYXRhYmFzZSAmJlxuICAgICAgICAhKHByb3AgaW4gdGFyZ2V0KSAmJlxuICAgICAgICB0eXBlb2YgcHJvcCA9PT0gJ3N0cmluZycpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGNhY2hlZE1ldGhvZHNbcHJvcF0pXG4gICAgICAgIHJldHVybiBjYWNoZWRNZXRob2RzW3Byb3BdO1xuICAgIGNvbnN0IHRhcmdldEZ1bmNOYW1lID0gcHJvcC5yZXBsYWNlKC9Gcm9tSW5kZXgkLywgJycpO1xuICAgIGNvbnN0IHVzZUluZGV4ID0gcHJvcCAhPT0gdGFyZ2V0RnVuY05hbWU7XG4gICAgY29uc3QgaXNXcml0ZSA9IHdyaXRlTWV0aG9kcy5pbmNsdWRlcyh0YXJnZXRGdW5jTmFtZSk7XG4gICAgaWYgKFxuICAgIC8vIEJhaWwgaWYgdGhlIHRhcmdldCBkb2Vzbid0IGV4aXN0IG9uIHRoZSB0YXJnZXQuIEVnLCBnZXRBbGwgaXNuJ3QgaW4gRWRnZS5cbiAgICAhKHRhcmdldEZ1bmNOYW1lIGluICh1c2VJbmRleCA/IElEQkluZGV4IDogSURCT2JqZWN0U3RvcmUpLnByb3RvdHlwZSkgfHxcbiAgICAgICAgIShpc1dyaXRlIHx8IHJlYWRNZXRob2RzLmluY2x1ZGVzKHRhcmdldEZ1bmNOYW1lKSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBtZXRob2QgPSBhc3luYyBmdW5jdGlvbiAoc3RvcmVOYW1lLCAuLi5hcmdzKSB7XG4gICAgICAgIC8vIGlzV3JpdGUgPyAncmVhZHdyaXRlJyA6IHVuZGVmaW5lZCBnemlwcHMgYmV0dGVyLCBidXQgZmFpbHMgaW4gRWRnZSA6KFxuICAgICAgICBjb25zdCB0eCA9IHRoaXMudHJhbnNhY3Rpb24oc3RvcmVOYW1lLCBpc1dyaXRlID8gJ3JlYWR3cml0ZScgOiAncmVhZG9ubHknKTtcbiAgICAgICAgbGV0IHRhcmdldCA9IHR4LnN0b3JlO1xuICAgICAgICBpZiAodXNlSW5kZXgpXG4gICAgICAgICAgICB0YXJnZXQgPSB0YXJnZXQuaW5kZXgoYXJncy5zaGlmdCgpKTtcbiAgICAgICAgLy8gTXVzdCByZWplY3QgaWYgb3AgcmVqZWN0cy5cbiAgICAgICAgLy8gSWYgaXQncyBhIHdyaXRlIG9wZXJhdGlvbiwgbXVzdCByZWplY3QgaWYgdHguZG9uZSByZWplY3RzLlxuICAgICAgICAvLyBNdXN0IHJlamVjdCB3aXRoIG9wIHJlamVjdGlvbiBmaXJzdC5cbiAgICAgICAgLy8gTXVzdCByZXNvbHZlIHdpdGggb3AgdmFsdWUuXG4gICAgICAgIC8vIE11c3QgaGFuZGxlIGJvdGggcHJvbWlzZXMgKG5vIHVuaGFuZGxlZCByZWplY3Rpb25zKVxuICAgICAgICByZXR1cm4gKGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICAgIHRhcmdldFt0YXJnZXRGdW5jTmFtZV0oLi4uYXJncyksXG4gICAgICAgICAgICBpc1dyaXRlICYmIHR4LmRvbmUsXG4gICAgICAgIF0pKVswXTtcbiAgICB9O1xuICAgIHJldHVybiAoY2FjaGVkTWV0aG9kc1twcm9wXSA9IG1ldGhvZCk7XG59XG5yZXBsYWNlVHJhcHMoKG9sZFRyYXBzKSA9PiAoe1xuICAgIC4uLm9sZFRyYXBzLFxuICAgIGdldDogKHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpID0+IGdldE1ldGhvZCh0YXJnZXQsIHByb3ApIHx8IG9sZFRyYXBzLmdldCh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKSxcbiAgICBoYXM6ICh0YXJnZXQsIHByb3ApID0+ICEhZ2V0TWV0aG9kKHRhcmdldCwgcHJvcCkgfHwgb2xkVHJhcHMuaGFzKHRhcmdldCwgcHJvcCksXG59KSk7XG5cbmNvbnN0IGFkdmFuY2VNZXRob2RQcm9wcyA9IFsnYWR2YW5jZScsICdjb250aW51ZScsICdjb250aW51ZVByaW1hcnlLZXknXTtcbmNvbnN0IG1ldGhvZE1hcCA9IHt9O1xuY29uc3QgYWR2YW5jZVJlc3VsdHMgPSBuZXcgV2Vha01hcCgpO1xuY29uc3QgaXR0clByb3hpZWRDdXJzb3JUb09yaWdpbmFsUHJveHkgPSBuZXcgV2Vha01hcCgpO1xuY29uc3QgY3Vyc29ySXRlcmF0b3JUcmFwcyA9IHtcbiAgICBnZXQodGFyZ2V0LCBwcm9wKSB7XG4gICAgICAgIGlmICghYWR2YW5jZU1ldGhvZFByb3BzLmluY2x1ZGVzKHByb3ApKVxuICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtwcm9wXTtcbiAgICAgICAgbGV0IGNhY2hlZEZ1bmMgPSBtZXRob2RNYXBbcHJvcF07XG4gICAgICAgIGlmICghY2FjaGVkRnVuYykge1xuICAgICAgICAgICAgY2FjaGVkRnVuYyA9IG1ldGhvZE1hcFtwcm9wXSA9IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgICAgICAgICAgICAgYWR2YW5jZVJlc3VsdHMuc2V0KHRoaXMsIGl0dHJQcm94aWVkQ3Vyc29yVG9PcmlnaW5hbFByb3h5LmdldCh0aGlzKVtwcm9wXSguLi5hcmdzKSk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjYWNoZWRGdW5jO1xuICAgIH0sXG59O1xuYXN5bmMgZnVuY3Rpb24qIGl0ZXJhdGUoLi4uYXJncykge1xuICAgIC8vIHRzbGludDpkaXNhYmxlLW5leHQtbGluZTpuby10aGlzLWFzc2lnbm1lbnRcbiAgICBsZXQgY3Vyc29yID0gdGhpcztcbiAgICBpZiAoIShjdXJzb3IgaW5zdGFuY2VvZiBJREJDdXJzb3IpKSB7XG4gICAgICAgIGN1cnNvciA9IGF3YWl0IGN1cnNvci5vcGVuQ3Vyc29yKC4uLmFyZ3MpO1xuICAgIH1cbiAgICBpZiAoIWN1cnNvcilcbiAgICAgICAgcmV0dXJuO1xuICAgIGN1cnNvciA9IGN1cnNvcjtcbiAgICBjb25zdCBwcm94aWVkQ3Vyc29yID0gbmV3IFByb3h5KGN1cnNvciwgY3Vyc29ySXRlcmF0b3JUcmFwcyk7XG4gICAgaXR0clByb3hpZWRDdXJzb3JUb09yaWdpbmFsUHJveHkuc2V0KHByb3hpZWRDdXJzb3IsIGN1cnNvcik7XG4gICAgLy8gTWFwIHRoaXMgZG91YmxlLXByb3h5IGJhY2sgdG8gdGhlIG9yaWdpbmFsLCBzbyBvdGhlciBjdXJzb3IgbWV0aG9kcyB3b3JrLlxuICAgIHJldmVyc2VUcmFuc2Zvcm1DYWNoZS5zZXQocHJveGllZEN1cnNvciwgdW53cmFwKGN1cnNvcikpO1xuICAgIHdoaWxlIChjdXJzb3IpIHtcbiAgICAgICAgeWllbGQgcHJveGllZEN1cnNvcjtcbiAgICAgICAgLy8gSWYgb25lIG9mIHRoZSBhZHZhbmNpbmcgbWV0aG9kcyB3YXMgbm90IGNhbGxlZCwgY2FsbCBjb250aW51ZSgpLlxuICAgICAgICBjdXJzb3IgPSBhd2FpdCAoYWR2YW5jZVJlc3VsdHMuZ2V0KHByb3hpZWRDdXJzb3IpIHx8IGN1cnNvci5jb250aW51ZSgpKTtcbiAgICAgICAgYWR2YW5jZVJlc3VsdHMuZGVsZXRlKHByb3hpZWRDdXJzb3IpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGlzSXRlcmF0b3JQcm9wKHRhcmdldCwgcHJvcCkge1xuICAgIHJldHVybiAoKHByb3AgPT09IFN5bWJvbC5hc3luY0l0ZXJhdG9yICYmXG4gICAgICAgIGluc3RhbmNlT2ZBbnkodGFyZ2V0LCBbSURCSW5kZXgsIElEQk9iamVjdFN0b3JlLCBJREJDdXJzb3JdKSkgfHxcbiAgICAgICAgKHByb3AgPT09ICdpdGVyYXRlJyAmJiBpbnN0YW5jZU9mQW55KHRhcmdldCwgW0lEQkluZGV4LCBJREJPYmplY3RTdG9yZV0pKSk7XG59XG5yZXBsYWNlVHJhcHMoKG9sZFRyYXBzKSA9PiAoe1xuICAgIC4uLm9sZFRyYXBzLFxuICAgIGdldCh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG4gICAgICAgIGlmIChpc0l0ZXJhdG9yUHJvcCh0YXJnZXQsIHByb3ApKVxuICAgICAgICAgICAgcmV0dXJuIGl0ZXJhdGU7XG4gICAgICAgIHJldHVybiBvbGRUcmFwcy5nZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcik7XG4gICAgfSxcbiAgICBoYXModGFyZ2V0LCBwcm9wKSB7XG4gICAgICAgIHJldHVybiBpc0l0ZXJhdG9yUHJvcCh0YXJnZXQsIHByb3ApIHx8IG9sZFRyYXBzLmhhcyh0YXJnZXQsIHByb3ApO1xuICAgIH0sXG59KSk7XG5cbmV4cG9ydCB7IGRlbGV0ZURCLCBvcGVuREIsIHVud3JhcCwgd3JhcCB9O1xuIiwgIi8qKiBNaW5pbWFsIFJGQyA0MTgwIENTViBwYXJzZXIgKHF1b3RlZCBmaWVsZHMsIGVzY2FwZWQgcXVvdGVzLCBuZXdsaW5lcyBpbiBxdW90ZXMpLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlQ3N2KGlucHV0OiBzdHJpbmcpOiBzdHJpbmdbXVtdIHtcbiAgY29uc3Qgcm93czogc3RyaW5nW11bXSA9IFtdO1xuICBsZXQgcm93OiBzdHJpbmdbXSA9IFtdO1xuICBsZXQgZmllbGQgPSAnJztcbiAgbGV0IHF1b3RlZCA9IGZhbHNlO1xuICBjb25zdCBzID0gaW5wdXQucmVwbGFjZSgvXlx1RkVGRi8sICcnKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgYyA9IHNbaV07XG4gICAgaWYgKHF1b3RlZCkge1xuICAgICAgaWYgKGMgPT09ICdcIicpIHtcbiAgICAgICAgaWYgKHNbaSArIDFdID09PSAnXCInKSB7XG4gICAgICAgICAgZmllbGQgKz0gJ1wiJztcbiAgICAgICAgICBpKys7XG4gICAgICAgIH0gZWxzZSBxdW90ZWQgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSBmaWVsZCArPSBjO1xuICAgIH0gZWxzZSBpZiAoYyA9PT0gJ1wiJykgcXVvdGVkID0gdHJ1ZTtcbiAgICBlbHNlIGlmIChjID09PSAnLCcpIHtcbiAgICAgIHJvdy5wdXNoKGZpZWxkKTtcbiAgICAgIGZpZWxkID0gJyc7XG4gICAgfSBlbHNlIGlmIChjID09PSAnXFxuJyB8fCBjID09PSAnXFxyJykge1xuICAgICAgaWYgKGMgPT09ICdcXHInICYmIHNbaSArIDFdID09PSAnXFxuJykgaSsrO1xuICAgICAgcm93LnB1c2goZmllbGQpO1xuICAgICAgcm93cy5wdXNoKHJvdyk7XG4gICAgICByb3cgPSBbXTtcbiAgICAgIGZpZWxkID0gJyc7XG4gICAgfSBlbHNlIGZpZWxkICs9IGM7XG4gIH1cbiAgaWYgKGZpZWxkIHx8IHJvdy5sZW5ndGgpIHtcbiAgICByb3cucHVzaChmaWVsZCk7XG4gICAgcm93cy5wdXNoKHJvdyk7XG4gIH1cbiAgcmV0dXJuIHJvd3MuZmlsdGVyKChyKSA9PiByLnNvbWUoKGYpID0+IGYgIT09ICcnKSk7XG59XG5cbi8qKiBCbG9jay1saXN0IENTViAoYWNjb3VudF9oYW5kbGUsIGRlc2NyaXB0aW9uLCAuLi4pIFx1MjE5MiBzZWVkIGVudHJpZXMuICovXG5leHBvcnQgZnVuY3Rpb24gY3N2VG9TZWVkcyhpbnB1dDogc3RyaW5nKTogeyBoYW5kbGU6IHN0cmluZzsgdGV4dDogc3RyaW5nIH1bXSB7XG4gIGNvbnN0IFtoZWFkZXIsIC4uLnJvd3NdID0gcGFyc2VDc3YoaW5wdXQpO1xuICBpZiAoIWhlYWRlcikgcmV0dXJuIFtdO1xuICBjb25zdCBoaSA9IGhlYWRlci5pbmRleE9mKCdhY2NvdW50X2hhbmRsZScpO1xuICBjb25zdCBkaSA9IGhlYWRlci5pbmRleE9mKCdkZXNjcmlwdGlvbicpO1xuICBpZiAoaGkgPCAwKSB0aHJvdyBuZXcgRXJyb3IoJ0NTViBoYXMgbm8gYWNjb3VudF9oYW5kbGUgY29sdW1uJyk7XG4gIHJldHVybiByb3dzLmZpbHRlcigocikgPT4gcltoaV0pLm1hcCgocikgPT4gKHsgaGFuZGxlOiByW2hpXSwgdGV4dDogZGkgPj0gMCA/IChyW2RpXSA/PyAnJykgOiAnJyB9KSk7XG59XG4iLCAiaW1wb3J0IHsgb3BlbkRCLCB0eXBlIERCU2NoZW1hLCB0eXBlIElEQlBEYXRhYmFzZSB9IGZyb20gJ2lkYic7XG5pbXBvcnQgdHlwZSB7IEF1dGhvclJlY29yZCwgQ291bnRyeVJlY29yZCwgTGFiZWxSZWNvcmQsIFBvc3RSZWNvcmQgfSBmcm9tICcuL3R5cGVzJztcblxuaW50ZXJmYWNlIEJhaXRTY2hlbWEgZXh0ZW5kcyBEQlNjaGVtYSB7XG4gIHBvc3RzOiB7IGtleTogc3RyaW5nOyB2YWx1ZTogUG9zdFJlY29yZCB9O1xuICBsYWJlbHM6IHsga2V5OiBudW1iZXI7IHZhbHVlOiBMYWJlbFJlY29yZDsgaW5kZXhlczogeyBwb3N0SWQ6IHN0cmluZyB9IH07XG4gIGF1dGhvcnM6IHsga2V5OiBzdHJpbmc7IHZhbHVlOiBBdXRob3JSZWNvcmQgfTtcbiAgY291bnRyaWVzOiB7IGtleTogc3RyaW5nOyB2YWx1ZTogQ291bnRyeVJlY29yZCB9O1xufVxuXG5leHBvcnQgdHlwZSBCYWl0REIgPSBJREJQRGF0YWJhc2U8QmFpdFNjaGVtYT47XG5cbmV4cG9ydCBmdW5jdGlvbiBvcGVuRGIobmFtZSA9ICdiYWl0YmxvY2tlcicpOiBQcm9taXNlPEJhaXREQj4ge1xuICByZXR1cm4gb3BlbkRCPEJhaXRTY2hlbWE+KG5hbWUsIDIsIHtcbiAgICB1cGdyYWRlKGRiLCBvbGRWZXJzaW9uKSB7XG4gICAgICBpZiAob2xkVmVyc2lvbiA8IDEpIHtcbiAgICAgICAgZGIuY3JlYXRlT2JqZWN0U3RvcmUoJ3Bvc3RzJywgeyBrZXlQYXRoOiAnaWQnIH0pO1xuICAgICAgICBjb25zdCBsYWJlbHMgPSBkYi5jcmVhdGVPYmplY3RTdG9yZSgnbGFiZWxzJywgeyBrZXlQYXRoOiAnaWQnLCBhdXRvSW5jcmVtZW50OiB0cnVlIH0pO1xuICAgICAgICBsYWJlbHMuY3JlYXRlSW5kZXgoJ3Bvc3RJZCcsICdwb3N0SWQnKTtcbiAgICAgICAgZGIuY3JlYXRlT2JqZWN0U3RvcmUoJ2F1dGhvcnMnLCB7IGtleVBhdGg6ICdoYW5kbGUnIH0pO1xuICAgICAgfVxuICAgICAgaWYgKG9sZFZlcnNpb24gPCAyKSBkYi5jcmVhdGVPYmplY3RTdG9yZSgnY291bnRyaWVzJywgeyBrZXlQYXRoOiAnaGFuZGxlJyB9KTtcbiAgICB9LFxuICB9KTtcbn1cblxuZXhwb3J0IGNvbnN0IG5vcm1IYW5kbGUgPSAoaDogc3RyaW5nKSA9PiBoLnRyaW0oKS5yZXBsYWNlKC9eQC8sICcnKS50b0xvd2VyQ2FzZSgpO1xuXG5leHBvcnQgY29uc3QgbmV3QXV0aG9yID0gKGhhbmRsZTogc3RyaW5nKTogQXV0aG9yUmVjb3JkID0+ICh7IGhhbmRsZSwgYWxwaGE6IDEsIGJldGE6IDEsIHNlZWRlZDogZmFsc2UsIHBvc3RzU2VlbjogMCB9KTtcblxuZXhwb3J0IGNvbnN0IGF1dGhvclNjb3JlID0gKGE6IEF1dGhvclJlY29yZCkgPT4gYS5hbHBoYSAvIChhLmFscGhhICsgYS5iZXRhKTtcblxuLyoqIFN0b3JhZ2Ugb3BlcmF0aW9ucyB0aGUgc2NvcmVyIG5lZWRzOyBpbXBsZW1lbnRlZCBvdmVyIEluZGV4ZWREQiBoZXJlIGFuZCBtb2NrZWQgaW4gdGVzdHMuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0b3JlIHtcbiAgZ2V0UG9zdChpZDogc3RyaW5nKTogUHJvbWlzZTxQb3N0UmVjb3JkIHwgdW5kZWZpbmVkPjtcbiAgcHV0UG9zdChwOiBQb3N0UmVjb3JkKTogUHJvbWlzZTx2b2lkPjtcbiAgZ2V0QXV0aG9yKGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxBdXRob3JSZWNvcmQgfCB1bmRlZmluZWQ+O1xuICBwdXRBdXRob3IoYTogQXV0aG9yUmVjb3JkKTogUHJvbWlzZTx2b2lkPjtcbiAgYWRkTGFiZWwobDogTGFiZWxSZWNvcmQpOiBQcm9taXNlPHZvaWQ+O1xuICBnZXRDb3VudHJ5KGhhbmRsZTogc3RyaW5nKTogUHJvbWlzZTxDb3VudHJ5UmVjb3JkIHwgdW5kZWZpbmVkPjtcbiAgcHV0Q291bnRyeShjOiBDb3VudHJ5UmVjb3JkKTogUHJvbWlzZTx2b2lkPjtcbn1cblxuZXhwb3J0IGNsYXNzIElkYlN0b3JlIGltcGxlbWVudHMgU3RvcmUge1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGRiOiBCYWl0REIpIHt9XG4gIGdldFBvc3QoaWQ6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLmRiLmdldCgncG9zdHMnLCBpZCk7XG4gIH1cbiAgYXN5bmMgcHV0UG9zdChwOiBQb3N0UmVjb3JkKSB7XG4gICAgYXdhaXQgdGhpcy5kYi5wdXQoJ3Bvc3RzJywgcCk7XG4gIH1cbiAgZ2V0QXV0aG9yKGhhbmRsZTogc3RyaW5nKSB7XG4gICAgcmV0dXJuIHRoaXMuZGIuZ2V0KCdhdXRob3JzJywgbm9ybUhhbmRsZShoYW5kbGUpKTtcbiAgfVxuICBhc3luYyBwdXRBdXRob3IoYTogQXV0aG9yUmVjb3JkKSB7XG4gICAgYXdhaXQgdGhpcy5kYi5wdXQoJ2F1dGhvcnMnLCB7IC4uLmEsIGhhbmRsZTogbm9ybUhhbmRsZShhLmhhbmRsZSkgfSk7XG4gIH1cbiAgYXN5bmMgYWRkTGFiZWwobDogTGFiZWxSZWNvcmQpIHtcbiAgICBhd2FpdCB0aGlzLmRiLmFkZCgnbGFiZWxzJywgbCk7XG4gIH1cbiAgZ2V0Q291bnRyeShoYW5kbGU6IHN0cmluZykge1xuICAgIHJldHVybiB0aGlzLmRiLmdldCgnY291bnRyaWVzJywgbm9ybUhhbmRsZShoYW5kbGUpKTtcbiAgfVxuICBhc3luYyBwdXRDb3VudHJ5KGM6IENvdW50cnlSZWNvcmQpIHtcbiAgICBhd2FpdCB0aGlzLmRiLnB1dCgnY291bnRyaWVzJywgeyAuLi5jLCBoYW5kbGU6IG5vcm1IYW5kbGUoYy5oYW5kbGUpIH0pO1xuICB9XG59XG5cbi8qKiBVcHNlcnQgc2VlZCBlbnRyaWVzOyBleGlzdGluZyBhbHBoYS9iZXRhIGFyZSBrZXB0LiBSZXR1cm5zIHRoZSBudW1iZXIgaW1wb3J0ZWQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaW1wb3J0U2VlZHMoZGI6IEJhaXREQiwgc2VlZHM6IHsgaGFuZGxlOiBzdHJpbmc7IHRleHQ/OiBzdHJpbmcgfVtdKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgY29uc3QgdHggPSBkYi50cmFuc2FjdGlvbignYXV0aG9ycycsICdyZWFkd3JpdGUnKTtcbiAgbGV0IG4gPSAwO1xuICBmb3IgKGNvbnN0IHMgb2Ygc2VlZHMpIHtcbiAgICBpZiAoIXM/LmhhbmRsZSkgY29udGludWU7XG4gICAgY29uc3QgaGFuZGxlID0gbm9ybUhhbmRsZShzLmhhbmRsZSk7XG4gICAgaWYgKCFoYW5kbGUpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGV4aXN0aW5nID0gKGF3YWl0IHR4LnN0b3JlLmdldChoYW5kbGUpKSA/PyBuZXdBdXRob3IoaGFuZGxlKTtcbiAgICBhd2FpdCB0eC5zdG9yZS5wdXQoeyAuLi5leGlzdGluZywgc2VlZGVkOiB0cnVlLCBzZWVkVGV4dDogcy50ZXh0ID8/IGV4aXN0aW5nLnNlZWRUZXh0IH0pO1xuICAgIG4rKztcbiAgfVxuICBhd2FpdCB0eC5kb25lO1xuICByZXR1cm4gbjtcbn1cblxuLyoqIGxhYmVscy5qc29ubDogZWFjaCBsYWJlbCBqb2luZWQgd2l0aCBpdHMgcG9zdCByZWNvcmQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZXhwb3J0TGFiZWxzKGRiOiBCYWl0REIpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBsYWJlbHMgPSBhd2FpdCBkYi5nZXRBbGwoJ2xhYmVscycpO1xuICBjb25zdCBsaW5lczogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCBsIG9mIGxhYmVscykgbGluZXMucHVzaChKU09OLnN0cmluZ2lmeSh7IC4uLmwsIHBvc3Q6IChhd2FpdCBkYi5nZXQoJ3Bvc3RzJywgbC5wb3N0SWQpKSA/PyBudWxsIH0pKTtcbiAgcmV0dXJuIGxpbmVzLmpvaW4oJ1xcbicpICsgKGxpbmVzLmxlbmd0aCA/ICdcXG4nIDogJycpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZXhwb3J0QXV0aG9ycyhkYjogQmFpdERCKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgY29uc3QgYXV0aG9ycyA9IGF3YWl0IGRiLmdldEFsbCgnYXV0aG9ycycpO1xuICByZXR1cm4gYXV0aG9ycy5tYXAoKGEpID0+IEpTT04uc3RyaW5naWZ5KHsgLi4uYSwgc2NvcmU6IGF1dGhvclNjb3JlKGEpIH0pKS5qb2luKCdcXG4nKSArIChhdXRob3JzLmxlbmd0aCA/ICdcXG4nIDogJycpO1xufVxuIiwgIntcbiAgXCJ2ZXJzaW9uXCI6IDcsXG4gIFwicXVlc3Rpb25zXCI6IFtcbiAgICB7XG4gICAgICBcImlkXCI6IFwidXNfcG9saXRpY3NcIixcbiAgICAgIFwidGV4dFwiOiBcIklzIHRoaXMgcG9zdCAoaW5jbHVkaW5nIGFueSB0ZXh0IGluIGF0dGFjaGVkIGltYWdlcykgYWJvdXQgVW5pdGVkIFN0YXRlcyBwb2xpdGljcywgZWNvbm9taWNzLCBvciBjdWx0dXJlIHdhciwgd3JpdHRlbiBhcyBpZiB0aGUgYXV0aG9yIGxpdmVzIGluIHRoZSBVUz8gRXhhbXBsZXM6IERlbW9jcmF0cyBvciBSZXB1YmxpY2FucywgVVMgcG9saXRpY2lhbnMsIHRoZSBtaW5pbXVtIHdhZ2Ugb3IgcHJpY2VzIGluIGRvbGxhcnMsIHJlbnQgb3Igd2FnZXMgaW4gVVMgY2l0aWVzLCBVUyBoZWFsdGhjYXJlIG9yIGluc3VyYW5jZSwgdGF4ZXMsIHN0dWRlbnQgbG9hbnMsIGd1bnMsIGltbWlncmF0aW9uLCBvciAnaW4gdGhpcyBjb3VudHJ5JyBjb21wbGFpbnRzIGFib3V0IEFtZXJpY2EuIEFuc3dlciBubyBmb3IgcG9zdHMgdGhhdCBhcmUgbm90IGFib3V0IHRoZSBVUywgYW5kIGZvciBuZXV0cmFsIG5ld3MgcmVwb3J0cy5cIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJpZFwiOiBcImlkZW9sb2d5X2JhaXRcIixcbiAgICAgIFwidGV4dFwiOiBcIklzIHRoaXMgcG9zdCAoaW5jbHVkaW5nIGFueSB0ZXh0IGluIGF0dGFjaGVkIGltYWdlcykgYSBzd2VlcGluZywgbG93LWVmZm9ydCB0YWtlIGRlc2lnbmVkIHRvIGZhcm0gcmVwbGllcyBvbiBhIGRpdmlzaXZlIHRoZW1lLCBzdWNoIGFzIGNhcGl0YWxpc20gdnMgc29jaWFsaXNtLCBiaWxsaW9uYWlyZXMgb3IgdGhlIHJpY2gsIHRoZSB3b3JraW5nIGNsYXNzLCBvciByZWplY3RpbmcgbW9kZXJuIHRlY2hub2xvZ3kgKFxcXCJub2JvZHkgd2FudHMgc2VsZi1kcml2aW5nIGNhcnNcXFwiLCBBSSwgc21hcnRwaG9uZXMsIGNhc2hsZXNzIHBheW1lbnRzKSwgc3RhdGVkIGFzIGEgc2xvZ2FuIG9yIGJvbGQgY2xhaW0gcmF0aGVyIHRoYW4gYSBzcGVjaWZpYyBhcmd1bWVudD8gQW5zd2VyIG5vIGZvciBzcGVjaWZpYywgc3Vic3RhbnRpdmUgYXJndW1lbnRzLCBuZXdzLCBvciBwZXJzb25hbCBhbmVjZG90ZXMgd2l0aG91dCBhIHByb3ZvY2F0aXZlIGdlbmVyYWxpemF0aW9uLlwiXG4gICAgfVxuICBdLFxuICBcImNvbWJpbmVcIjoge1xuICAgIFwibWF4X29mXCI6IFtcbiAgICAgIFwidXNfcG9saXRpY3NcIixcbiAgICAgIFwiaWRlb2xvZ3lfYmFpdFwiXG4gICAgXSxcbiAgICBcIndlaWdodGVkXCI6IHt9XG4gIH0sXG4gIFwidGhyZXNob2xkc1wiOiB7XG4gICAgXCJoaWRlXCI6IDAuOCxcbiAgICBcImJsdXJcIjogMC41XG4gIH0sXG4gIFwic3RhbmNlXCI6IHtcbiAgICBcImlkXCI6IFwiZW5kb3JzZXNfcXVvdGVcIixcbiAgICBcInRleHRcIjogXCJBIHJlcGx5LXF1b3RlOiB0aGUgYXV0aG9yIHdyb3RlIHRoZSBmaXJzdCBwYXJ0LCBxdW90aW5nIHRoZSBwb3N0IGFmdGVyIFtRdW90ZWQgcG9zdF0uIERvZXMgdGhlIGF1dGhvciBzaWRlIHdpdGggdGhlIHF1b3RlZCBwb3N0LCB3YW50aW5nIHJlYWRlcnMgdG8gYWdyZWUgd2l0aCBpdD8gQW5zd2VyIG5vIGlmIHRoZSBhdXRob3IgaXMgbW9ja2luZyBpdCwgYXJndWluZyBhZ2FpbnN0IGl0LCBjb3JyZWN0aW5nIGl0LCB3YXJuaW5nIHBlb3BsZSBhYm91dCBpdCwgb3IgY29tbWVudGluZyBvbiBzb21ldGhpbmcgZWxzZS5cIixcbiAgICBcInRocmVzaG9sZFwiOiAwLjhcbiAgfVxufVxuIiwgImltcG9ydCBxdWVzdGlvbnMgZnJvbSAnLi4vY29uZmlnL3F1ZXN0aW9ucy5qc29uJztcbmltcG9ydCB0eXBlIHsgRGVjaXNpb24sIFF1ZXN0aW9uc0NvbmZpZywgU2V0dGluZ3MsIFVzYWdlIH0gZnJvbSAnLi90eXBlcyc7XG5cbmV4cG9ydCBjb25zdCBRVUVTVElPTlMgPSBxdWVzdGlvbnMgYXMgUXVlc3Rpb25zQ29uZmlnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIGFwaUtleTogJycsXG4gIG1vZGVsOiAnZDEuMScsXG4gIHRocmVzaG9sZHM6IHsgLi4uUVVFU1RJT05TLnRocmVzaG9sZHMgfSxcbiAgZW5hYmxlZDogeyBwZW5kaW5nOiB0cnVlLCBoaWRlOiB0cnVlLCBibHVyOiB0cnVlLCBmbGFnOiB0cnVlIH0sXG4gIGRhaWx5VG9rZW5CdWRnZXQ6IDFfMDAwXzAwMCxcbiAgY2FwdHVyZUZpeHR1cmVzOiBmYWxzZSxcbiAgYWxsb3dlZENvdW50cmllczogWydVbml0ZWQgU3RhdGVzJywgJ05vcnRoIEFtZXJpY2EnXSxcbiAgc2NvcmVJbWFnZXM6IHRydWUsXG59O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbG9hZFNldHRpbmdzKCk6IFByb21pc2U8U2V0dGluZ3M+IHtcbiAgY29uc3QgeyBzZXR0aW5ncyB9ID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KCdzZXR0aW5ncycpO1xuICBjb25zdCBzID0gKHNldHRpbmdzID8/IHt9KSBhcyBQYXJ0aWFsPFNldHRpbmdzPiAmIHsgdGhyZXNob2xkc0Zvcj86IG51bWJlciB9O1xuICAvLyBUaHJlc2hvbGRzIGFyZSB0dW5lZCBwZXIgcXVlc3Rpb24gc2V0LCBzbyBzYXZlZCBvbmVzIG9ubHkgYXBwbHkgdG8gdGhlIHZlcnNpb24gdGhleSB3ZXJlIHNhdmVkIHVuZGVyLlxuICBjb25zdCBzYXZlZCA9IHMudGhyZXNob2xkc0ZvciA9PT0gUVVFU1RJT05TLnZlcnNpb24gPyBzLnRocmVzaG9sZHMgOiB1bmRlZmluZWQ7XG4gIHJldHVybiB7XG4gICAgLi4uREVGQVVMVF9TRVRUSU5HUyxcbiAgICAuLi5zLFxuICAgIHRocmVzaG9sZHM6IHsgLi4uREVGQVVMVF9TRVRUSU5HUy50aHJlc2hvbGRzLCAuLi5zYXZlZCB9LFxuICAgIGVuYWJsZWQ6IHsgLi4uREVGQVVMVF9TRVRUSU5HUy5lbmFibGVkLCAuLi5zLmVuYWJsZWQgfSxcbiAgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBzZXR0aW5nczogeyAuLi5zLCB0aHJlc2hvbGRzRm9yOiBRVUVTVElPTlMudmVyc2lvbiB9IH0pO1xufVxuXG5leHBvcnQgY29uc3QgdG9kYXkgPSAoKSA9PiBuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tQ0EnKTtcblxuZXhwb3J0IGNvbnN0IGVtcHR5VXNhZ2UgPSAoKTogVXNhZ2UgPT4gKHsgZGF0ZTogdG9kYXkoKSwgdG9rZW5zOiAwLCBzY29yZWQ6IDAsIGRlY2lzaW9uczogeyBoaWRlOiAwLCBibHVyOiAwLCBzaG93OiAwIH0gfSk7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBsb2FkVXNhZ2UoKTogUHJvbWlzZTxVc2FnZT4ge1xuICBjb25zdCB7IHVzYWdlIH0gPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoJ3VzYWdlJyk7XG4gIGNvbnN0IHUgPSB1c2FnZSBhcyBVc2FnZSB8IHVuZGVmaW5lZDtcbiAgcmV0dXJuIHUgJiYgdS5kYXRlID09PSB0b2RheSgpID8gdSA6IGVtcHR5VXNhZ2UoKTtcbn1cblxuLyoqIFdpdGhvdXQgYSBkZWNpc2lvbiBvbmx5IHRva2VucyBhcmUgY291bnRlZCAoZS5nLiB0aGUgcXVvdGUtc3RhbmNlIGZvbGxvdy11cCBjYWxsKS4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWNvcmRVc2FnZSh0b2tlbnM6IG51bWJlciwgZGVjaXNpb24/OiBEZWNpc2lvbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCB1ID0gYXdhaXQgbG9hZFVzYWdlKCk7XG4gIHUudG9rZW5zICs9IHRva2VucztcbiAgaWYgKGRlY2lzaW9uKSB7XG4gICAgdS5zY29yZWQrKztcbiAgICB1LmRlY2lzaW9uc1tkZWNpc2lvbl0rKztcbiAgfVxuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyB1c2FnZTogdSB9KTtcbn1cbiIsICJpbXBvcnQgeyBvcGVuREIgfSBmcm9tICdpZGInO1xuaW1wb3J0IHsgY3N2VG9TZWVkcyB9IGZyb20gJy4vY3N2JztcbmltcG9ydCB7IGV4cG9ydEF1dGhvcnMsIGV4cG9ydExhYmVscywgaW1wb3J0U2VlZHMsIG9wZW5EYiB9IGZyb20gJy4vZGInO1xuaW1wb3J0IHsgbG9hZFNldHRpbmdzLCBsb2FkVXNhZ2UsIHNhdmVTZXR0aW5ncyB9IGZyb20gJy4vc2V0dGluZ3MnO1xuXG5jb25zdCAkID0gPFQgZXh0ZW5kcyBIVE1MRWxlbWVudCA9IEhUTUxJbnB1dEVsZW1lbnQ+KGlkOiBzdHJpbmcpID0+IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKSBhcyBUO1xuY29uc3QgZGJQID0gb3BlbkRiKCk7XG5cbmZ1bmN0aW9uIHN0YXR1cyhpZDogc3RyaW5nLCBtc2c6IHN0cmluZywgb2sgPSB0cnVlKSB7XG4gIGNvbnN0IG4gPSAkKGlkKTtcbiAgbi50ZXh0Q29udGVudCA9IG1zZztcbiAgbi5jbGFzc05hbWUgPSBgc3RhdHVzICR7b2sgPyAnb2snIDogJ2Vycid9YDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmlsbCgpIHtcbiAgY29uc3QgcyA9IGF3YWl0IGxvYWRTZXR0aW5ncygpO1xuICAkKCdhcGlLZXknKS52YWx1ZSA9IHMuYXBpS2V5O1xuICAkPEhUTUxTZWxlY3RFbGVtZW50PignbW9kZWwnKS52YWx1ZSA9IHMubW9kZWw7XG4gICQoJ2J1ZGdldCcpLnZhbHVlID0gU3RyaW5nKHMuZGFpbHlUb2tlbkJ1ZGdldCk7XG4gICQoJ3RIaWRlJykudmFsdWUgPSBTdHJpbmcocy50aHJlc2hvbGRzLmhpZGUpO1xuICAkKCd0Qmx1cicpLnZhbHVlID0gU3RyaW5nKHMudGhyZXNob2xkcy5ibHVyKTtcbiAgJCgnZW5QZW5kaW5nJykuY2hlY2tlZCA9IHMuZW5hYmxlZC5wZW5kaW5nO1xuICAkKCdlbkhpZGUnKS5jaGVja2VkID0gcy5lbmFibGVkLmhpZGU7XG4gICQoJ2VuQmx1cicpLmNoZWNrZWQgPSBzLmVuYWJsZWQuYmx1cjtcbiAgJCgnZW5GbGFnJykuY2hlY2tlZCA9IHMuZW5hYmxlZC5mbGFnO1xuICAkKCdjYXB0dXJlJykuY2hlY2tlZCA9IHMuY2FwdHVyZUZpeHR1cmVzO1xuICAkKCdhbGxvd2VkJykudmFsdWUgPSBzLmFsbG93ZWRDb3VudHJpZXMuam9pbignLCAnKTtcbiAgJCgnc2NvcmVJbWFnZXMnKS5jaGVja2VkID0gcy5zY29yZUltYWdlcztcbn1cblxuJCgnc2F2ZScpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICBjb25zdCBoaWRlID0gTnVtYmVyKCQoJ3RIaWRlJykudmFsdWUpO1xuICBjb25zdCBibHVyID0gTnVtYmVyKCQoJ3RCbHVyJykudmFsdWUpO1xuICBpZiAoIShibHVyID49IDAgJiYgaGlkZSA8PSAxICYmIGJsdXIgPD0gaGlkZSkpIHJldHVybiBzdGF0dXMoJ3NhdmVTdGF0dXMnLCAnTmVlZCAwIFx1MjI2NCBibHVyIFx1MjI2NCBoaWRlIFx1MjI2NCAxJywgZmFsc2UpO1xuICBjb25zdCBzID0gYXdhaXQgbG9hZFNldHRpbmdzKCk7XG4gIGF3YWl0IHNhdmVTZXR0aW5ncyh7XG4gICAgLi4ucyxcbiAgICBhcGlLZXk6ICQoJ2FwaUtleScpLnZhbHVlLnRyaW0oKSxcbiAgICBtb2RlbDogJDxIVE1MU2VsZWN0RWxlbWVudD4oJ21vZGVsJykudmFsdWUsXG4gICAgZGFpbHlUb2tlbkJ1ZGdldDogTnVtYmVyKCQoJ2J1ZGdldCcpLnZhbHVlKSB8fCAwLFxuICAgIHRocmVzaG9sZHM6IHsgaGlkZSwgYmx1ciB9LFxuICAgIGVuYWJsZWQ6IHsgcGVuZGluZzogJCgnZW5QZW5kaW5nJykuY2hlY2tlZCwgaGlkZTogJCgnZW5IaWRlJykuY2hlY2tlZCwgYmx1cjogJCgnZW5CbHVyJykuY2hlY2tlZCwgZmxhZzogJCgnZW5GbGFnJykuY2hlY2tlZCB9LFxuICAgIGNhcHR1cmVGaXh0dXJlczogJCgnY2FwdHVyZScpLmNoZWNrZWQsXG4gICAgc2NvcmVJbWFnZXM6ICQoJ3Njb3JlSW1hZ2VzJykuY2hlY2tlZCxcbiAgICBhbGxvd2VkQ291bnRyaWVzOiAkKCdhbGxvd2VkJykudmFsdWUuc3BsaXQoJywnKS5tYXAoKGMpID0+IGMudHJpbSgpKS5maWx0ZXIoQm9vbGVhbiksXG4gIH0pO1xuICBzdGF0dXMoJ3NhdmVTdGF0dXMnLCAnU2F2ZWQnKTtcbn0pO1xuXG5hc3luYyBmdW5jdGlvbiBkb0ltcG9ydChzZWVkczogeyBoYW5kbGU6IHN0cmluZzsgdGV4dD86IHN0cmluZyB9W10pIHtcbiAgY29uc3QgbiA9IGF3YWl0IGltcG9ydFNlZWRzKGF3YWl0IGRiUCwgc2VlZHMpO1xuICBzdGF0dXMoJ3NlZWRTdGF0dXMnLCBgSW1wb3J0ZWQgJHtufSBhY2NvdW50c2ApO1xuICBzdGF0cygpO1xufVxuXG4kKCdpbXBvcnRKc29uJykuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgZGF0YSA9IEpTT04ucGFyc2UoJDxIVE1MVGV4dEFyZWFFbGVtZW50Pignc2VlZEpzb24nKS52YWx1ZSk7XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KGRhdGEpKSB0aHJvdyBuZXcgRXJyb3IoJ0V4cGVjdGVkIGEgSlNPTiBhcnJheScpO1xuICAgIGF3YWl0IGRvSW1wb3J0KGRhdGEpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgc3RhdHVzKCdzZWVkU3RhdHVzJywgKGUgYXMgRXJyb3IpLm1lc3NhZ2UsIGZhbHNlKTtcbiAgfVxufSk7XG5cbiQoJ3NlZWRDc3YnKS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBhc3luYyAoKSA9PiB7XG4gIGNvbnN0IGZpbGUgPSAkKCdzZWVkQ3N2JykuZmlsZXM/LlswXTtcbiAgaWYgKCFmaWxlKSByZXR1cm47XG4gIHRyeSB7XG4gICAgYXdhaXQgZG9JbXBvcnQoY3N2VG9TZWVkcyhhd2FpdCBmaWxlLnRleHQoKSkpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgc3RhdHVzKCdzZWVkU3RhdHVzJywgKGUgYXMgRXJyb3IpLm1lc3NhZ2UsIGZhbHNlKTtcbiAgfVxufSk7XG5cbmZ1bmN0aW9uIGRvd25sb2FkKG5hbWU6IHN0cmluZywgdGV4dDogc3RyaW5nLCB0eXBlID0gJ2FwcGxpY2F0aW9uL3gtbmRqc29uJykge1xuICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICBhLmhyZWYgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKG5ldyBCbG9iKFt0ZXh0XSwgeyB0eXBlIH0pKTtcbiAgYS5kb3dubG9hZCA9IG5hbWU7XG4gIGEuY2xpY2soKTtcbiAgc2V0VGltZW91dCgoKSA9PiBVUkwucmV2b2tlT2JqZWN0VVJMKGEuaHJlZiksIDEwMDApO1xufVxuXG4kKCdleHBvcnRMYWJlbHMnKS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IGRvd25sb2FkKCdsYWJlbHMuanNvbmwnLCBhd2FpdCBleHBvcnRMYWJlbHMoYXdhaXQgZGJQKSkpO1xuJCgnZXhwb3J0QXV0aG9ycycpLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4gZG93bmxvYWQoJ2F1dGhvcnMuanNvbmwnLCBhd2FpdCBleHBvcnRBdXRob3JzKGF3YWl0IGRiUCkpKTtcbiQoJ2V4cG9ydENhcHR1cmVzJykuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gIGNvbnN0IGRiID0gYXdhaXQgb3BlbkRCKCdiYWl0YmxvY2tlci1kZWJ1ZycsIDEsIHtcbiAgICB1cGdyYWRlKGQpIHtcbiAgICAgIGQuY3JlYXRlT2JqZWN0U3RvcmUoJ2NhcHR1cmVzJywgeyBrZXlQYXRoOiAnaWQnLCBhdXRvSW5jcmVtZW50OiB0cnVlIH0pO1xuICAgIH0sXG4gIH0pO1xuICBjb25zdCBhbGwgPSBhd2FpdCBkYi5nZXRBbGwoJ2NhcHR1cmVzJyk7XG4gIGlmICghYWxsLmxlbmd0aCkgcmV0dXJuIHN0YXR1cygnZXhwb3J0U3RhdHVzJywgJ05vIGNhcHR1cmVzIHlldDogZW5hYmxlIGNhcHR1cmUsIHNhdmUsIGFuZCBicm93c2UgeC5jb20nLCBmYWxzZSk7XG4gIGRvd25sb2FkKCdjYXB0dXJlcy5qc29uJywgSlNPTi5zdHJpbmdpZnkoYWxsLCBudWxsLCAxKSwgJ2FwcGxpY2F0aW9uL2pzb24nKTtcbiAgc3RhdHVzKCdleHBvcnRTdGF0dXMnLCBgJHthbGwubGVuZ3RofSByZXNwb25zZXNgKTtcbn0pO1xuXG5hc3luYyBmdW5jdGlvbiBzdGF0cygpIHtcbiAgY29uc3QgZGIgPSBhd2FpdCBkYlA7XG4gIGNvbnN0IHUgPSBhd2FpdCBsb2FkVXNhZ2UoKTtcbiAgY29uc3QgYXV0aG9ycyA9IGF3YWl0IGRiLmdldEFsbCgnYXV0aG9ycycpO1xuICBjb25zdCByb3dzOiBbc3RyaW5nLCBzdHJpbmcgfCBudW1iZXJdW10gPSBbXG4gICAgWydQb3N0cyBzY29yZWQgdG9kYXknLCB1LnNjb3JlZF0sXG4gICAgWydJbnB1dCB0b2tlbnMgdG9kYXknLCB1LnRva2Vucy50b0xvY2FsZVN0cmluZygpXSxcbiAgICBbJ1RvZGF5IGhpZGUgLyBibHVyIC8gc2hvdycsIGAke3UuZGVjaXNpb25zLmhpZGV9IC8gJHt1LmRlY2lzaW9ucy5ibHVyfSAvICR7dS5kZWNpc2lvbnMuc2hvd31gXSxcbiAgICBbJ0NhY2hlZCBwb3N0cyAoYWxsIHRpbWUpJywgYXdhaXQgZGIuY291bnQoJ3Bvc3RzJyldLFxuICAgIFsnTGFiZWxzJywgYXdhaXQgZGIuY291bnQoJ2xhYmVscycpXSxcbiAgICBbJ0NvdW50cmllcyBjYWNoZWQnLCBhd2FpdCBkYi5jb3VudCgnY291bnRyaWVzJyldLFxuICAgIFsnQXV0aG9ycyB0cmFja2VkIC8gc2VlZGVkJywgYCR7YXV0aG9ycy5sZW5ndGh9IC8gJHthdXRob3JzLmZpbHRlcigoYSkgPT4gYS5zZWVkZWQpLmxlbmd0aH1gXSxcbiAgXTtcbiAgY29uc3QgdCA9ICQoJ3N0YXRzJyk7XG4gIHQucmVwbGFjZUNoaWxkcmVuKFxuICAgIC4uLnJvd3MubWFwKChbaywgdl0pID0+IHtcbiAgICAgIGNvbnN0IHRyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgndHInKTtcbiAgICAgIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCd0ZCcpO1xuICAgICAgY29uc3QgYiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3RkJyk7XG4gICAgICBhLnRleHRDb250ZW50ID0gaztcbiAgICAgIGIudGV4dENvbnRlbnQgPSBTdHJpbmcodik7XG4gICAgICB0ci5hcHBlbmQoYSwgYik7XG4gICAgICByZXR1cm4gdHI7XG4gICAgfSksXG4gICk7XG59XG5cbiQoJ3JlZnJlc2gnKS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIHN0YXRzKTtcbmZpbGwoKTtcbnN0YXRzKCk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFBQSxNQUFNLGdCQUFnQixDQUFDLFFBQVEsaUJBQWlCLGFBQWEsS0FBSyxDQUFDLE1BQU0sa0JBQWtCLENBQUM7QUFFNUYsTUFBSTtBQUNKLE1BQUk7QUFFSixXQUFTLHVCQUF1QjtBQUM1QixXQUFRLHNCQUNILG9CQUFvQjtBQUFBLE1BQ2pCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0o7QUFBQSxFQUNSO0FBRUEsV0FBUywwQkFBMEI7QUFDL0IsV0FBUSx5QkFDSCx1QkFBdUIsQ0FBQyxXQUFXLFlBQVksb0JBQW9CLEVBQUUsSUFBSSxDQUFDLFdBQVcsVUFBVSxVQUFVLE1BQU0sQ0FBQztBQUFBLEVBQ3pIO0FBQ0EsTUFBTSxxQkFBcUIsb0JBQUksUUFBUTtBQUN2QyxNQUFNLGlCQUFpQixvQkFBSSxRQUFRO0FBQ25DLE1BQU0sd0JBQXdCLG9CQUFJLFFBQVE7QUFDMUMsV0FBUyxpQkFBaUIsU0FBUztBQUMvQixVQUFNLFVBQVUsSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFXO0FBQzdDLFlBQU0sV0FBVyxNQUFNO0FBQ25CLGdCQUFRLG9CQUFvQixXQUFXLE9BQU87QUFDOUMsZ0JBQVEsb0JBQW9CLFNBQVMsS0FBSztBQUFBLE1BQzlDO0FBQ0EsWUFBTSxVQUFVLE1BQU07QUFDbEIsZ0JBQVEsS0FBSyxRQUFRLE1BQU0sQ0FBQztBQUM1QixpQkFBUztBQUFBLE1BQ2I7QUFDQSxZQUFNLFFBQVEsTUFBTTtBQUNoQixlQUFPLFFBQVEsS0FBSztBQUNwQixpQkFBUztBQUFBLE1BQ2I7QUFDQSxjQUFRLGlCQUFpQixXQUFXLE9BQU87QUFDM0MsY0FBUSxpQkFBaUIsU0FBUyxLQUFLO0FBQUEsSUFDM0MsQ0FBQztBQUdELDBCQUFzQixJQUFJLFNBQVMsT0FBTztBQUMxQyxXQUFPO0FBQUEsRUFDWDtBQUNBLFdBQVMsK0JBQStCLElBQUk7QUFFeEMsUUFBSSxtQkFBbUIsSUFBSSxFQUFFO0FBQ3pCO0FBQ0osVUFBTSxPQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUMxQyxZQUFNLFdBQVcsTUFBTTtBQUNuQixXQUFHLG9CQUFvQixZQUFZLFFBQVE7QUFDM0MsV0FBRyxvQkFBb0IsU0FBUyxLQUFLO0FBQ3JDLFdBQUcsb0JBQW9CLFNBQVMsS0FBSztBQUFBLE1BQ3pDO0FBQ0EsWUFBTSxXQUFXLE1BQU07QUFDbkIsZ0JBQVE7QUFDUixpQkFBUztBQUFBLE1BQ2I7QUFDQSxZQUFNLFFBQVEsTUFBTTtBQUNoQixlQUFPLEdBQUcsU0FBUyxJQUFJLGFBQWEsY0FBYyxZQUFZLENBQUM7QUFDL0QsaUJBQVM7QUFBQSxNQUNiO0FBQ0EsU0FBRyxpQkFBaUIsWUFBWSxRQUFRO0FBQ3hDLFNBQUcsaUJBQWlCLFNBQVMsS0FBSztBQUNsQyxTQUFHLGlCQUFpQixTQUFTLEtBQUs7QUFBQSxJQUN0QyxDQUFDO0FBRUQsdUJBQW1CLElBQUksSUFBSSxJQUFJO0FBQUEsRUFDbkM7QUFDQSxNQUFJLGdCQUFnQjtBQUFBLElBQ2hCLElBQUksUUFBUSxNQUFNLFVBQVU7QUFDeEIsVUFBSSxrQkFBa0IsZ0JBQWdCO0FBRWxDLFlBQUksU0FBUztBQUNULGlCQUFPLG1CQUFtQixJQUFJLE1BQU07QUFFeEMsWUFBSSxTQUFTLFNBQVM7QUFDbEIsaUJBQU8sU0FBUyxpQkFBaUIsQ0FBQyxJQUM1QixTQUNBLFNBQVMsWUFBWSxTQUFTLGlCQUFpQixDQUFDLENBQUM7QUFBQSxRQUMzRDtBQUFBLE1BQ0o7QUFFQSxhQUFPLEtBQUssT0FBTyxJQUFJLENBQUM7QUFBQSxJQUM1QjtBQUFBLElBQ0EsSUFBSSxRQUFRLE1BQU0sT0FBTztBQUNyQixhQUFPLElBQUksSUFBSTtBQUNmLGFBQU87QUFBQSxJQUNYO0FBQUEsSUFDQSxJQUFJLFFBQVEsTUFBTTtBQUNkLFVBQUksa0JBQWtCLG1CQUNqQixTQUFTLFVBQVUsU0FBUyxVQUFVO0FBQ3ZDLGVBQU87QUFBQSxNQUNYO0FBQ0EsYUFBTyxRQUFRO0FBQUEsSUFDbkI7QUFBQSxFQUNKO0FBQ0EsV0FBUyxhQUFhLFVBQVU7QUFDNUIsb0JBQWdCLFNBQVMsYUFBYTtBQUFBLEVBQzFDO0FBQ0EsV0FBUyxhQUFhLE1BQU07QUFReEIsUUFBSSx3QkFBd0IsRUFBRSxTQUFTLElBQUksR0FBRztBQUMxQyxhQUFPLFlBQWEsTUFBTTtBQUd0QixhQUFLLE1BQU0sT0FBTyxJQUFJLEdBQUcsSUFBSTtBQUM3QixlQUFPLEtBQUssS0FBSyxPQUFPO0FBQUEsTUFDNUI7QUFBQSxJQUNKO0FBQ0EsV0FBTyxZQUFhLE1BQU07QUFHdEIsYUFBTyxLQUFLLEtBQUssTUFBTSxPQUFPLElBQUksR0FBRyxJQUFJLENBQUM7QUFBQSxJQUM5QztBQUFBLEVBQ0o7QUFDQSxXQUFTLHVCQUF1QixPQUFPO0FBQ25DLFFBQUksT0FBTyxVQUFVO0FBQ2pCLGFBQU8sYUFBYSxLQUFLO0FBRzdCLFFBQUksaUJBQWlCO0FBQ2pCLHFDQUErQixLQUFLO0FBQ3hDLFFBQUksY0FBYyxPQUFPLHFCQUFxQixDQUFDO0FBQzNDLGFBQU8sSUFBSSxNQUFNLE9BQU8sYUFBYTtBQUV6QyxXQUFPO0FBQUEsRUFDWDtBQUNBLFdBQVMsS0FBSyxPQUFPO0FBR2pCLFFBQUksaUJBQWlCO0FBQ2pCLGFBQU8saUJBQWlCLEtBQUs7QUFHakMsUUFBSSxlQUFlLElBQUksS0FBSztBQUN4QixhQUFPLGVBQWUsSUFBSSxLQUFLO0FBQ25DLFVBQU0sV0FBVyx1QkFBdUIsS0FBSztBQUc3QyxRQUFJLENBQUMsT0FBTyxHQUFHLFVBQVUsS0FBSyxHQUFHO0FBQzdCLHFCQUFlLElBQUksT0FBTyxRQUFRO0FBQ2xDLDRCQUFzQixJQUFJLFVBQVUsS0FBSztBQUFBLElBQzdDO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDQSxNQUFNLFNBQVMsQ0FBQyxVQUFVLHNCQUFzQixJQUFJLEtBQUs7QUFTekQsV0FBUyxPQUFPLE1BQU0sU0FBUyxFQUFFLFNBQVMsU0FBUyxVQUFVLFdBQVcsSUFBSSxDQUFDLEdBQUc7QUFDNUUsVUFBTSxVQUFVLFVBQVUsS0FBSyxNQUFNLE9BQU87QUFDNUMsVUFBTSxjQUFjLEtBQUssT0FBTztBQUNoQyxRQUFJLFNBQVM7QUFDVCxjQUFRLGlCQUFpQixpQkFBaUIsQ0FBQyxVQUFVO0FBQ2pELGdCQUFRLEtBQUssUUFBUSxNQUFNLEdBQUcsTUFBTSxZQUFZLE1BQU0sWUFBWSxLQUFLLFFBQVEsV0FBVyxHQUFHLEtBQUs7QUFBQSxNQUN0RyxDQUFDO0FBQUEsSUFDTDtBQUNBLFFBQUksU0FBUztBQUNULGNBQVEsaUJBQWlCLFdBQVcsQ0FBQyxVQUFVO0FBQUE7QUFBQSxRQUUvQyxNQUFNO0FBQUEsUUFBWSxNQUFNO0FBQUEsUUFBWTtBQUFBLE1BQUssQ0FBQztBQUFBLElBQzlDO0FBQ0EsZ0JBQ0ssS0FBSyxDQUFDLE9BQU87QUFDZCxVQUFJO0FBQ0EsV0FBRyxpQkFBaUIsU0FBUyxNQUFNLFdBQVcsQ0FBQztBQUNuRCxVQUFJLFVBQVU7QUFDVixXQUFHLGlCQUFpQixpQkFBaUIsQ0FBQyxVQUFVLFNBQVMsTUFBTSxZQUFZLE1BQU0sWUFBWSxLQUFLLENBQUM7QUFBQSxNQUN2RztBQUFBLElBQ0osQ0FBQyxFQUNJLE1BQU0sTUFBTTtBQUFBLElBQUUsQ0FBQztBQUNwQixXQUFPO0FBQUEsRUFDWDtBQWdCQSxNQUFNLGNBQWMsQ0FBQyxPQUFPLFVBQVUsVUFBVSxjQUFjLE9BQU87QUFDckUsTUFBTSxlQUFlLENBQUMsT0FBTyxPQUFPLFVBQVUsT0FBTztBQUNyRCxNQUFNLGdCQUFnQixDQUFDO0FBQ3ZCLFdBQVMsVUFBVSxRQUFRLE1BQU07QUFDN0IsUUFBSSxFQUFFLGtCQUFrQixlQUNwQixFQUFFLFFBQVEsV0FDVixPQUFPLFNBQVMsV0FBVztBQUMzQjtBQUFBLElBQ0o7QUFDQSxRQUFJLGNBQWMsSUFBSTtBQUNsQixhQUFPLGNBQWMsSUFBSTtBQUM3QixVQUFNLGlCQUFpQixLQUFLLFFBQVEsY0FBYyxFQUFFO0FBQ3BELFVBQU0sV0FBVyxTQUFTO0FBQzFCLFVBQU0sVUFBVSxhQUFhLFNBQVMsY0FBYztBQUNwRDtBQUFBO0FBQUEsTUFFQSxFQUFFLG1CQUFtQixXQUFXLFdBQVcsZ0JBQWdCLGNBQ3ZELEVBQUUsV0FBVyxZQUFZLFNBQVMsY0FBYztBQUFBLE1BQUk7QUFDcEQ7QUFBQSxJQUNKO0FBQ0EsVUFBTSxTQUFTLGVBQWdCLGNBQWMsTUFBTTtBQUUvQyxZQUFNLEtBQUssS0FBSyxZQUFZLFdBQVcsVUFBVSxjQUFjLFVBQVU7QUFDekUsVUFBSUEsVUFBUyxHQUFHO0FBQ2hCLFVBQUk7QUFDQSxRQUFBQSxVQUFTQSxRQUFPLE1BQU0sS0FBSyxNQUFNLENBQUM7QUFNdEMsY0FBUSxNQUFNLFFBQVEsSUFBSTtBQUFBLFFBQ3RCQSxRQUFPLGNBQWMsRUFBRSxHQUFHLElBQUk7QUFBQSxRQUM5QixXQUFXLEdBQUc7QUFBQSxNQUNsQixDQUFDLEdBQUcsQ0FBQztBQUFBLElBQ1Q7QUFDQSxXQUFRLGNBQWMsSUFBSSxJQUFJO0FBQUEsRUFDbEM7QUFDQSxlQUFhLENBQUMsY0FBYztBQUFBLElBQ3hCLEdBQUc7QUFBQSxJQUNILEtBQUssQ0FBQyxRQUFRLE1BQU0sYUFBYSxVQUFVLFFBQVEsSUFBSSxLQUFLLFNBQVMsSUFBSSxRQUFRLE1BQU0sUUFBUTtBQUFBLElBQy9GLEtBQUssQ0FBQyxRQUFRLFNBQVMsQ0FBQyxDQUFDLFVBQVUsUUFBUSxJQUFJLEtBQUssU0FBUyxJQUFJLFFBQVEsSUFBSTtBQUFBLEVBQ2pGLEVBQUU7QUFFRixNQUFNLHFCQUFxQixDQUFDLFdBQVcsWUFBWSxvQkFBb0I7QUFDdkUsTUFBTSxZQUFZLENBQUM7QUFDbkIsTUFBTSxpQkFBaUIsb0JBQUksUUFBUTtBQUNuQyxNQUFNLG1DQUFtQyxvQkFBSSxRQUFRO0FBQ3JELE1BQU0sc0JBQXNCO0FBQUEsSUFDeEIsSUFBSSxRQUFRLE1BQU07QUFDZCxVQUFJLENBQUMsbUJBQW1CLFNBQVMsSUFBSTtBQUNqQyxlQUFPLE9BQU8sSUFBSTtBQUN0QixVQUFJLGFBQWEsVUFBVSxJQUFJO0FBQy9CLFVBQUksQ0FBQyxZQUFZO0FBQ2IscUJBQWEsVUFBVSxJQUFJLElBQUksWUFBYSxNQUFNO0FBQzlDLHlCQUFlLElBQUksTUFBTSxpQ0FBaUMsSUFBSSxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDO0FBQUEsUUFDdEY7QUFBQSxNQUNKO0FBQ0EsYUFBTztBQUFBLElBQ1g7QUFBQSxFQUNKO0FBQ0Esa0JBQWdCLFdBQVcsTUFBTTtBQUU3QixRQUFJLFNBQVM7QUFDYixRQUFJLEVBQUUsa0JBQWtCLFlBQVk7QUFDaEMsZUFBUyxNQUFNLE9BQU8sV0FBVyxHQUFHLElBQUk7QUFBQSxJQUM1QztBQUNBLFFBQUksQ0FBQztBQUNEO0FBQ0osYUFBUztBQUNULFVBQU0sZ0JBQWdCLElBQUksTUFBTSxRQUFRLG1CQUFtQjtBQUMzRCxxQ0FBaUMsSUFBSSxlQUFlLE1BQU07QUFFMUQsMEJBQXNCLElBQUksZUFBZSxPQUFPLE1BQU0sQ0FBQztBQUN2RCxXQUFPLFFBQVE7QUFDWCxZQUFNO0FBRU4sZUFBUyxPQUFPLGVBQWUsSUFBSSxhQUFhLEtBQUssT0FBTyxTQUFTO0FBQ3JFLHFCQUFlLE9BQU8sYUFBYTtBQUFBLElBQ3ZDO0FBQUEsRUFDSjtBQUNBLFdBQVMsZUFBZSxRQUFRLE1BQU07QUFDbEMsV0FBUyxTQUFTLE9BQU8saUJBQ3JCLGNBQWMsUUFBUSxDQUFDLFVBQVUsZ0JBQWdCLFNBQVMsQ0FBQyxLQUMxRCxTQUFTLGFBQWEsY0FBYyxRQUFRLENBQUMsVUFBVSxjQUFjLENBQUM7QUFBQSxFQUMvRTtBQUNBLGVBQWEsQ0FBQyxjQUFjO0FBQUEsSUFDeEIsR0FBRztBQUFBLElBQ0gsSUFBSSxRQUFRLE1BQU0sVUFBVTtBQUN4QixVQUFJLGVBQWUsUUFBUSxJQUFJO0FBQzNCLGVBQU87QUFDWCxhQUFPLFNBQVMsSUFBSSxRQUFRLE1BQU0sUUFBUTtBQUFBLElBQzlDO0FBQUEsSUFDQSxJQUFJLFFBQVEsTUFBTTtBQUNkLGFBQU8sZUFBZSxRQUFRLElBQUksS0FBSyxTQUFTLElBQUksUUFBUSxJQUFJO0FBQUEsSUFDcEU7QUFBQSxFQUNKLEVBQUU7OztBQ3hTSyxXQUFTLFNBQVMsT0FBMkI7QUFDbEQsVUFBTSxPQUFtQixDQUFDO0FBQzFCLFFBQUksTUFBZ0IsQ0FBQztBQUNyQixRQUFJLFFBQVE7QUFDWixRQUFJLFNBQVM7QUFDYixVQUFNLElBQUksTUFBTSxRQUFRLE1BQU0sRUFBRTtBQUNoQyxhQUFTLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLO0FBQ2pDLFlBQU0sSUFBSSxFQUFFLENBQUM7QUFDYixVQUFJLFFBQVE7QUFDVixZQUFJLE1BQU0sS0FBSztBQUNiLGNBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxLQUFLO0FBQ3BCLHFCQUFTO0FBQ1Q7QUFBQSxVQUNGLE1BQU8sVUFBUztBQUFBLFFBQ2xCLE1BQU8sVUFBUztBQUFBLE1BQ2xCLFdBQVcsTUFBTSxJQUFLLFVBQVM7QUFBQSxlQUN0QixNQUFNLEtBQUs7QUFDbEIsWUFBSSxLQUFLLEtBQUs7QUFDZCxnQkFBUTtBQUFBLE1BQ1YsV0FBVyxNQUFNLFFBQVEsTUFBTSxNQUFNO0FBQ25DLFlBQUksTUFBTSxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sS0FBTTtBQUNyQyxZQUFJLEtBQUssS0FBSztBQUNkLGFBQUssS0FBSyxHQUFHO0FBQ2IsY0FBTSxDQUFDO0FBQ1AsZ0JBQVE7QUFBQSxNQUNWLE1BQU8sVUFBUztBQUFBLElBQ2xCO0FBQ0EsUUFBSSxTQUFTLElBQUksUUFBUTtBQUN2QixVQUFJLEtBQUssS0FBSztBQUNkLFdBQUssS0FBSyxHQUFHO0FBQUEsSUFDZjtBQUNBLFdBQU8sS0FBSyxPQUFPLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFDbkQ7QUFHTyxXQUFTLFdBQVcsT0FBbUQ7QUFDNUUsVUFBTSxDQUFDLFFBQVEsR0FBRyxJQUFJLElBQUksU0FBUyxLQUFLO0FBQ3hDLFFBQUksQ0FBQyxPQUFRLFFBQU8sQ0FBQztBQUNyQixVQUFNLEtBQUssT0FBTyxRQUFRLGdCQUFnQjtBQUMxQyxVQUFNLEtBQUssT0FBTyxRQUFRLGFBQWE7QUFDdkMsUUFBSSxLQUFLLEVBQUcsT0FBTSxJQUFJLE1BQU0sa0NBQWtDO0FBQzlELFdBQU8sS0FBSyxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLEVBQUUsR0FBRyxNQUFNLE1BQU0sSUFBSyxFQUFFLEVBQUUsS0FBSyxLQUFNLEdBQUcsRUFBRTtBQUFBLEVBQ3JHOzs7QUMvQk8sV0FBUyxPQUFPLE9BQU8sZUFBZ0M7QUFDNUQsV0FBTyxPQUFtQixNQUFNLEdBQUc7QUFBQSxNQUNqQyxRQUFRLElBQUksWUFBWTtBQUN0QixZQUFJLGFBQWEsR0FBRztBQUNsQixhQUFHLGtCQUFrQixTQUFTLEVBQUUsU0FBUyxLQUFLLENBQUM7QUFDL0MsZ0JBQU0sU0FBUyxHQUFHLGtCQUFrQixVQUFVLEVBQUUsU0FBUyxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQ3BGLGlCQUFPLFlBQVksVUFBVSxRQUFRO0FBQ3JDLGFBQUcsa0JBQWtCLFdBQVcsRUFBRSxTQUFTLFNBQVMsQ0FBQztBQUFBLFFBQ3ZEO0FBQ0EsWUFBSSxhQUFhLEVBQUcsSUFBRyxrQkFBa0IsYUFBYSxFQUFFLFNBQVMsU0FBUyxDQUFDO0FBQUEsTUFDN0U7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRU8sTUFBTSxhQUFhLENBQUMsTUFBYyxFQUFFLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxFQUFFLFlBQVk7QUFFekUsTUFBTSxZQUFZLENBQUMsWUFBa0MsRUFBRSxRQUFRLE9BQU8sR0FBRyxNQUFNLEdBQUcsUUFBUSxPQUFPLFdBQVcsRUFBRTtBQUU5RyxNQUFNLGNBQWMsQ0FBQyxNQUFvQixFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUU7QUF1Q3ZFLGlCQUFzQixZQUFZLElBQVksT0FBNkQ7QUFDekcsVUFBTSxLQUFLLEdBQUcsWUFBWSxXQUFXLFdBQVc7QUFDaEQsUUFBSSxJQUFJO0FBQ1IsZUFBVyxLQUFLLE9BQU87QUFDckIsVUFBSSxDQUFDLEdBQUcsT0FBUTtBQUNoQixZQUFNLFNBQVMsV0FBVyxFQUFFLE1BQU07QUFDbEMsVUFBSSxDQUFDLE9BQVE7QUFDYixZQUFNLFdBQVksTUFBTSxHQUFHLE1BQU0sSUFBSSxNQUFNLEtBQU0sVUFBVSxNQUFNO0FBQ2pFLFlBQU0sR0FBRyxNQUFNLElBQUksRUFBRSxHQUFHLFVBQVUsUUFBUSxNQUFNLFVBQVUsRUFBRSxRQUFRLFNBQVMsU0FBUyxDQUFDO0FBQ3ZGO0FBQUEsSUFDRjtBQUNBLFVBQU0sR0FBRztBQUNULFdBQU87QUFBQSxFQUNUO0FBR0EsaUJBQXNCLGFBQWEsSUFBNkI7QUFDOUQsVUFBTSxTQUFTLE1BQU0sR0FBRyxPQUFPLFFBQVE7QUFDdkMsVUFBTSxRQUFrQixDQUFDO0FBQ3pCLGVBQVcsS0FBSyxPQUFRLE9BQU0sS0FBSyxLQUFLLFVBQVUsRUFBRSxHQUFHLEdBQUcsTUFBTyxNQUFNLEdBQUcsSUFBSSxTQUFTLEVBQUUsTUFBTSxLQUFNLEtBQUssQ0FBQyxDQUFDO0FBQzVHLFdBQU8sTUFBTSxLQUFLLElBQUksS0FBSyxNQUFNLFNBQVMsT0FBTztBQUFBLEVBQ25EO0FBRUEsaUJBQXNCLGNBQWMsSUFBNkI7QUFDL0QsVUFBTSxVQUFVLE1BQU0sR0FBRyxPQUFPLFNBQVM7QUFDekMsV0FBTyxRQUFRLElBQUksQ0FBQyxNQUFNLEtBQUssVUFBVSxFQUFFLEdBQUcsR0FBRyxPQUFPLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEtBQUssSUFBSSxLQUFLLFFBQVEsU0FBUyxPQUFPO0FBQUEsRUFDbkg7OztBQy9GQTtBQUFBLElBQ0UsU0FBVztBQUFBLElBQ1gsV0FBYTtBQUFBLE1BQ1g7QUFBQSxRQUNFLElBQU07QUFBQSxRQUNOLE1BQVE7QUFBQSxNQUNWO0FBQUEsTUFDQTtBQUFBLFFBQ0UsSUFBTTtBQUFBLFFBQ04sTUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBQUEsSUFDQSxTQUFXO0FBQUEsTUFDVCxRQUFVO0FBQUEsUUFDUjtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsTUFDQSxVQUFZLENBQUM7QUFBQSxJQUNmO0FBQUEsSUFDQSxZQUFjO0FBQUEsTUFDWixNQUFRO0FBQUEsTUFDUixNQUFRO0FBQUEsSUFDVjtBQUFBLElBQ0EsUUFBVTtBQUFBLE1BQ1IsSUFBTTtBQUFBLE1BQ04sTUFBUTtBQUFBLE1BQ1IsV0FBYTtBQUFBLElBQ2Y7QUFBQSxFQUNGOzs7QUN6Qk8sTUFBTSxZQUFZO0FBRWxCLE1BQU0sbUJBQTZCO0FBQUEsSUFDeEMsUUFBUTtBQUFBLElBQ1IsT0FBTztBQUFBLElBQ1AsWUFBWSxFQUFFLEdBQUcsVUFBVSxXQUFXO0FBQUEsSUFDdEMsU0FBUyxFQUFFLFNBQVMsTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNLE1BQU0sS0FBSztBQUFBLElBQzdELGtCQUFrQjtBQUFBLElBQ2xCLGlCQUFpQjtBQUFBLElBQ2pCLGtCQUFrQixDQUFDLGlCQUFpQixlQUFlO0FBQUEsSUFDbkQsYUFBYTtBQUFBLEVBQ2Y7QUFFQSxpQkFBc0IsZUFBa0M7QUFDdEQsVUFBTSxFQUFFLFNBQVMsSUFBSSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksVUFBVTtBQUM5RCxVQUFNLElBQUssWUFBWSxDQUFDO0FBRXhCLFVBQU0sUUFBUSxFQUFFLGtCQUFrQixVQUFVLFVBQVUsRUFBRSxhQUFhO0FBQ3JFLFdBQU87QUFBQSxNQUNMLEdBQUc7QUFBQSxNQUNILEdBQUc7QUFBQSxNQUNILFlBQVksRUFBRSxHQUFHLGlCQUFpQixZQUFZLEdBQUcsTUFBTTtBQUFBLE1BQ3ZELFNBQVMsRUFBRSxHQUFHLGlCQUFpQixTQUFTLEdBQUcsRUFBRSxRQUFRO0FBQUEsSUFDdkQ7QUFBQSxFQUNGO0FBRUEsaUJBQXNCLGFBQWEsR0FBNEI7QUFDN0QsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsVUFBVSxFQUFFLEdBQUcsR0FBRyxlQUFlLFVBQVUsUUFBUSxFQUFFLENBQUM7QUFBQSxFQUN6RjtBQUVPLE1BQU0sUUFBUSxPQUFNLG9CQUFJLEtBQUssR0FBRSxtQkFBbUIsT0FBTztBQUV6RCxNQUFNLGFBQWEsT0FBYyxFQUFFLE1BQU0sTUFBTSxHQUFHLFFBQVEsR0FBRyxRQUFRLEdBQUcsV0FBVyxFQUFFLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxFQUFFLEVBQUU7QUFFeEgsaUJBQXNCLFlBQTRCO0FBQ2hELFVBQU0sRUFBRSxNQUFNLElBQUksTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLE9BQU87QUFDeEQsVUFBTSxJQUFJO0FBQ1YsV0FBTyxLQUFLLEVBQUUsU0FBUyxNQUFNLElBQUksSUFBSSxXQUFXO0FBQUEsRUFDbEQ7OztBQ3BDQSxNQUFNLElBQUksQ0FBMkMsT0FBZSxTQUFTLGVBQWUsRUFBRTtBQUM5RixNQUFNLE1BQU0sT0FBTztBQUVuQixXQUFTLE9BQU8sSUFBWSxLQUFhLEtBQUssTUFBTTtBQUNsRCxVQUFNLElBQUksRUFBRSxFQUFFO0FBQ2QsTUFBRSxjQUFjO0FBQ2hCLE1BQUUsWUFBWSxVQUFVLEtBQUssT0FBTyxLQUFLO0FBQUEsRUFDM0M7QUFFQSxpQkFBZSxPQUFPO0FBQ3BCLFVBQU0sSUFBSSxNQUFNLGFBQWE7QUFDN0IsTUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFO0FBQ3RCLE1BQXFCLE9BQU8sRUFBRSxRQUFRLEVBQUU7QUFDeEMsTUFBRSxRQUFRLEVBQUUsUUFBUSxPQUFPLEVBQUUsZ0JBQWdCO0FBQzdDLE1BQUUsT0FBTyxFQUFFLFFBQVEsT0FBTyxFQUFFLFdBQVcsSUFBSTtBQUMzQyxNQUFFLE9BQU8sRUFBRSxRQUFRLE9BQU8sRUFBRSxXQUFXLElBQUk7QUFDM0MsTUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFLFFBQVE7QUFDbkMsTUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLFFBQVE7QUFDaEMsTUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLFFBQVE7QUFDaEMsTUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLFFBQVE7QUFDaEMsTUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFO0FBQ3pCLE1BQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxpQkFBaUIsS0FBSyxJQUFJO0FBQ2pELE1BQUUsYUFBYSxFQUFFLFVBQVUsRUFBRTtBQUFBLEVBQy9CO0FBRUEsSUFBRSxNQUFNLEVBQUUsaUJBQWlCLFNBQVMsWUFBWTtBQUM5QyxVQUFNLE9BQU8sT0FBTyxFQUFFLE9BQU8sRUFBRSxLQUFLO0FBQ3BDLFVBQU0sT0FBTyxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUs7QUFDcEMsUUFBSSxFQUFFLFFBQVEsS0FBSyxRQUFRLEtBQUssUUFBUSxNQUFPLFFBQU8sT0FBTyxjQUFjLDJDQUE0QixLQUFLO0FBQzVHLFVBQU0sSUFBSSxNQUFNLGFBQWE7QUFDN0IsVUFBTSxhQUFhO0FBQUEsTUFDakIsR0FBRztBQUFBLE1BQ0gsUUFBUSxFQUFFLFFBQVEsRUFBRSxNQUFNLEtBQUs7QUFBQSxNQUMvQixPQUFPLEVBQXFCLE9BQU8sRUFBRTtBQUFBLE1BQ3JDLGtCQUFrQixPQUFPLEVBQUUsUUFBUSxFQUFFLEtBQUssS0FBSztBQUFBLE1BQy9DLFlBQVksRUFBRSxNQUFNLEtBQUs7QUFBQSxNQUN6QixTQUFTLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxTQUFTLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVMsTUFBTSxFQUFFLFFBQVEsRUFBRSxRQUFRO0FBQUEsTUFDNUgsaUJBQWlCLEVBQUUsU0FBUyxFQUFFO0FBQUEsTUFDOUIsYUFBYSxFQUFFLGFBQWEsRUFBRTtBQUFBLE1BQzlCLGtCQUFrQixFQUFFLFNBQVMsRUFBRSxNQUFNLE1BQU0sR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUUsT0FBTyxPQUFPO0FBQUEsSUFDckYsQ0FBQztBQUNELFdBQU8sY0FBYyxPQUFPO0FBQUEsRUFDOUIsQ0FBQztBQUVELGlCQUFlLFNBQVMsT0FBNEM7QUFDbEUsVUFBTSxJQUFJLE1BQU0sWUFBWSxNQUFNLEtBQUssS0FBSztBQUM1QyxXQUFPLGNBQWMsWUFBWSxDQUFDLFdBQVc7QUFDN0MsVUFBTTtBQUFBLEVBQ1I7QUFFQSxJQUFFLFlBQVksRUFBRSxpQkFBaUIsU0FBUyxZQUFZO0FBQ3BELFFBQUk7QUFDRixZQUFNLE9BQU8sS0FBSyxNQUFNLEVBQXVCLFVBQVUsRUFBRSxLQUFLO0FBQ2hFLFVBQUksQ0FBQyxNQUFNLFFBQVEsSUFBSSxFQUFHLE9BQU0sSUFBSSxNQUFNLHVCQUF1QjtBQUNqRSxZQUFNLFNBQVMsSUFBSTtBQUFBLElBQ3JCLFNBQVMsR0FBRztBQUNWLGFBQU8sY0FBZSxFQUFZLFNBQVMsS0FBSztBQUFBLElBQ2xEO0FBQUEsRUFDRixDQUFDO0FBRUQsSUFBRSxTQUFTLEVBQUUsaUJBQWlCLFVBQVUsWUFBWTtBQUNsRCxVQUFNLE9BQU8sRUFBRSxTQUFTLEVBQUUsUUFBUSxDQUFDO0FBQ25DLFFBQUksQ0FBQyxLQUFNO0FBQ1gsUUFBSTtBQUNGLFlBQU0sU0FBUyxXQUFXLE1BQU0sS0FBSyxLQUFLLENBQUMsQ0FBQztBQUFBLElBQzlDLFNBQVMsR0FBRztBQUNWLGFBQU8sY0FBZSxFQUFZLFNBQVMsS0FBSztBQUFBLElBQ2xEO0FBQUEsRUFDRixDQUFDO0FBRUQsV0FBUyxTQUFTLE1BQWMsTUFBYyxPQUFPLHdCQUF3QjtBQUMzRSxVQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7QUFDcEMsTUFBRSxPQUFPLElBQUksZ0JBQWdCLElBQUksS0FBSyxDQUFDLElBQUksR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQ3ZELE1BQUUsV0FBVztBQUNiLE1BQUUsTUFBTTtBQUNSLGVBQVcsTUFBTSxJQUFJLGdCQUFnQixFQUFFLElBQUksR0FBRyxHQUFJO0FBQUEsRUFDcEQ7QUFFQSxJQUFFLGNBQWMsRUFBRSxpQkFBaUIsU0FBUyxZQUFZLFNBQVMsZ0JBQWdCLE1BQU0sYUFBYSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0FBQy9HLElBQUUsZUFBZSxFQUFFLGlCQUFpQixTQUFTLFlBQVksU0FBUyxpQkFBaUIsTUFBTSxjQUFjLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDbEgsSUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsU0FBUyxZQUFZO0FBQ3hELFVBQU0sS0FBSyxNQUFNLE9BQU8scUJBQXFCLEdBQUc7QUFBQSxNQUM5QyxRQUFRLEdBQUc7QUFDVCxVQUFFLGtCQUFrQixZQUFZLEVBQUUsU0FBUyxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQUEsTUFDeEU7QUFBQSxJQUNGLENBQUM7QUFDRCxVQUFNLE1BQU0sTUFBTSxHQUFHLE9BQU8sVUFBVTtBQUN0QyxRQUFJLENBQUMsSUFBSSxPQUFRLFFBQU8sT0FBTyxnQkFBZ0IsMkRBQTJELEtBQUs7QUFDL0csYUFBUyxpQkFBaUIsS0FBSyxVQUFVLEtBQUssTUFBTSxDQUFDLEdBQUcsa0JBQWtCO0FBQzFFLFdBQU8sZ0JBQWdCLEdBQUcsSUFBSSxNQUFNLFlBQVk7QUFBQSxFQUNsRCxDQUFDO0FBRUQsaUJBQWUsUUFBUTtBQUNyQixVQUFNLEtBQUssTUFBTTtBQUNqQixVQUFNLElBQUksTUFBTSxVQUFVO0FBQzFCLFVBQU0sVUFBVSxNQUFNLEdBQUcsT0FBTyxTQUFTO0FBQ3pDLFVBQU0sT0FBb0M7QUFBQSxNQUN4QyxDQUFDLHNCQUFzQixFQUFFLE1BQU07QUFBQSxNQUMvQixDQUFDLHNCQUFzQixFQUFFLE9BQU8sZUFBZSxDQUFDO0FBQUEsTUFDaEQsQ0FBQyw0QkFBNEIsR0FBRyxFQUFFLFVBQVUsSUFBSSxNQUFNLEVBQUUsVUFBVSxJQUFJLE1BQU0sRUFBRSxVQUFVLElBQUksRUFBRTtBQUFBLE1BQzlGLENBQUMsMkJBQTJCLE1BQU0sR0FBRyxNQUFNLE9BQU8sQ0FBQztBQUFBLE1BQ25ELENBQUMsVUFBVSxNQUFNLEdBQUcsTUFBTSxRQUFRLENBQUM7QUFBQSxNQUNuQyxDQUFDLG9CQUFvQixNQUFNLEdBQUcsTUFBTSxXQUFXLENBQUM7QUFBQSxNQUNoRCxDQUFDLDRCQUE0QixHQUFHLFFBQVEsTUFBTSxNQUFNLFFBQVEsT0FBTyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFO0FBQUEsSUFDOUY7QUFDQSxVQUFNLElBQUksRUFBRSxPQUFPO0FBQ25CLE1BQUU7QUFBQSxNQUNBLEdBQUcsS0FBSyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUN0QixjQUFNLEtBQUssU0FBUyxjQUFjLElBQUk7QUFDdEMsY0FBTSxJQUFJLFNBQVMsY0FBYyxJQUFJO0FBQ3JDLGNBQU0sSUFBSSxTQUFTLGNBQWMsSUFBSTtBQUNyQyxVQUFFLGNBQWM7QUFDaEIsVUFBRSxjQUFjLE9BQU8sQ0FBQztBQUN4QixXQUFHLE9BQU8sR0FBRyxDQUFDO0FBQ2QsZUFBTztBQUFBLE1BQ1QsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBRUEsSUFBRSxTQUFTLEVBQUUsaUJBQWlCLFNBQVMsS0FBSztBQUM1QyxPQUFLO0FBQ0wsUUFBTTsiLAogICJuYW1lcyI6IFsidGFyZ2V0Il0KfQo=
