"use strict";
(() => {
  // src/country.ts
  var ABOUT_OP = "AboutAccountQuery";
  var DEFAULT_ABOUT_QUERY_ID = "TzOG2twZEfhr9KmClvVVqA";
  var DEFAULT_BEARER = "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";
  var KNOWN_TTL_MS = 30 * 24 * 36e5;
  var UNKNOWN_TTL_MS = 24 * 36e5;
  function parseAbout(json) {
    const stack = [json];
    while (stack.length) {
      const n = stack.pop();
      if (typeof n !== "object" || n === null) continue;
      const about = n.about_profile;
      if (about && typeof about === "object") {
        const c = about.account_based_in;
        return {
          country: typeof c === "string" && c.trim() ? c.trim() : void 0,
          accurate: typeof about.location_accurate === "boolean" ? about.location_accurate : void 0
        };
      }
      stack.push(...Object.values(n));
    }
    return {};
  }
  function aboutQueryId(url) {
    return new RegExp(`/graphql/([^/]+)/${ABOUT_OP}\\b`).exec(url)?.[1];
  }
  var CountryFetcher = class {
    constructor(d) {
      this.d = d;
      this.now = d.now ?? Date.now;
      this.sleep = d.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
    }
    d;
    queue = [];
    pending = /* @__PURE__ */ new Map();
    running = false;
    resumeAt = 0;
    now;
    sleep;
    lookup(handle2) {
      const key = handle2.toLowerCase();
      const existing = this.pending.get(key);
      if (existing) return existing;
      const p = new Promise((resolve) => this.queue.push({ handle: handle2, resolve }));
      this.pending.set(key, p);
      p.finally(() => this.pending.delete(key));
      this.pump();
      return p;
    }
    async pump() {
      if (this.running) return;
      this.running = true;
      try {
        while (this.queue.length) {
          const wait = this.resumeAt - this.now();
          if (wait > 0) await this.sleep(wait);
          const job = this.queue.shift();
          const r = await this.once(job.handle);
          if (!r.ok && r.error === "rate_limited") {
            this.queue.unshift(job);
            continue;
          }
          job.resolve(r);
          this.resumeAt = Math.max(this.resumeAt, this.now() + (this.d.gapMs ?? 1e3));
        }
      } finally {
        this.running = false;
      }
    }
    async once(handle2) {
      const url = `/i/api/graphql/${this.d.queryId()}/${ABOUT_OP}?variables=${encodeURIComponent(JSON.stringify({ screenName: handle2 }))}`;
      let res;
      try {
        res = await this.d.fetch(url, { credentials: "include", headers: this.d.headers() });
      } catch (e) {
        return { ok: false, error: "network" };
      }
      const remaining = Number(res.headers.get("x-rate-limit-remaining"));
      const reset = Number(res.headers.get("x-rate-limit-reset")) * 1e3;
      const resetAt = reset > this.now() ? reset + 1e3 : this.now() + 6e4;
      if (res.status === 429) {
        this.resumeAt = resetAt;
        return { ok: false, error: "rate_limited" };
      }
      if (Number.isFinite(remaining) && res.headers.has("x-rate-limit-remaining") && remaining <= 2) this.resumeAt = resetAt;
      if (res.status === 400 || res.status === 404) return { ok: false, error: "stale_query" };
      if (!res.ok) return { ok: false, error: `http_${res.status}` };
      try {
        return { ok: true, info: parseAbout(await res.json()) };
      } catch {
        return { ok: false, error: "bad_json" };
      }
    }
  };

  // src/parser.ts
  var isObj = (v) => typeof v === "object" && v !== null;
  function unwrapTweet(v) {
    if (!isObj(v)) return void 0;
    if (v.__typename === "Tweet") return v;
    if (v.__typename === "TweetWithVisibilityResults" && isObj(v.tweet)) return unwrapTweet(v.tweet);
    return void 0;
  }
  function screenName(tweet) {
    const user = tweet.core?.user_results?.result;
    const name = user?.core?.screen_name ?? user?.legacy?.screen_name;
    return typeof name === "string" ? name : void 0;
  }
  function tweetText(tweet) {
    const note = tweet.note_tweet?.note_tweet_results?.result?.text;
    if (typeof note === "string" && note) return note;
    const full = tweet.legacy?.full_text;
    return typeof full === "string" ? full : "";
  }
  var IMAGE_SIZE = "360x360";
  var MAX_IMAGES = 2;
  function scoringImageUrl(url) {
    const m = /^https:\/\/pbs\.twimg\.com\/media\/([A-Za-z0-9_-]+)/.exec(url);
    return m ? `https://pbs.twimg.com/media/${m[1]}?format=jpg&name=${IMAGE_SIZE}` : void 0;
  }
  function photoUrls(tweet) {
    const media = tweet.legacy?.extended_entities?.media ?? tweet.legacy?.entities?.media;
    if (!Array.isArray(media)) return [];
    return media.filter((m) => m?.type === "photo" && typeof m.media_url_https === "string").map((m) => scoringImageUrl(m.media_url_https)).filter((u) => !!u);
  }
  function extractPost(tweet) {
    const id = tweet.rest_id;
    if (typeof id !== "string" || !id) return void 0;
    const post = {
      id,
      text: tweetText(tweet),
      author: screenName(tweet),
      isReply: typeof tweet.legacy?.in_reply_to_status_id_str === "string",
      source: "parser"
    };
    const images = photoUrls(tweet);
    const quoted = unwrapTweet(tweet.quoted_status_result?.result);
    if (quoted) {
      post.quotedText = tweetText(quoted);
      post.quotedAuthor = screenName(quoted);
      if (typeof quoted.rest_id === "string" && quoted.rest_id) post.quotedId = quoted.rest_id;
      else images.push(...photoUrls(quoted));
    }
    if (images.length) post.imageUrls = [...new Set(images)].slice(0, MAX_IMAGES);
    return post;
  }
  function mergePosts(a, b) {
    if (!a) return b;
    const out = { ...a };
    for (const [k, v] of Object.entries(b)) {
      if (out[k] === void 0 || out[k] === "" || out[k] === false) out[k] = v;
    }
    return out;
  }
  var GraphQLTimelineParser = class {
    parse(json) {
      const out = /* @__PURE__ */ new Map();
      const stack = [json];
      const seen = /* @__PURE__ */ new Set();
      while (stack.length) {
        const node = stack.pop();
        if (!isObj(node) || seen.has(node)) continue;
        seen.add(node);
        const tweet = unwrapTweet(node);
        if (tweet && tweet === node) {
          try {
            const post = extractPost(tweet);
            if (post) out.set(post.id, mergePosts(out.get(post.id), post));
          } catch {
          }
        }
        for (const v of Array.isArray(node) ? node : Object.values(node)) {
          if (isObj(v)) stack.push(v);
        }
      }
      return [...out.values()];
    }
  };
  var TIMELINE_OPS = ["HomeTimeline", "HomeLatestTimeline", "TweetDetail", "UserTweets", "SearchTimeline"];
  function isTimelineUrl(url) {
    const m = /\/graphql\/[^/]+\/([A-Za-z]+)/.exec(url);
    return !!m && TIMELINE_OPS.includes(m[1]);
  }

  // src/types.ts
  var MSG_NS = "baitblocker:v1";

  // src/inject.ts
  var parser = new GraphQLTimelineParser();
  var capture = false;
  var QID_KEY = "baitblocker:aboutQueryId";
  var queryId = safeGet(QID_KEY) ?? DEFAULT_ABOUT_QUERY_ID;
  var bearer = DEFAULT_BEARER;
  function safeGet(k) {
    try {
      return localStorage.getItem(k) ?? void 0;
    } catch {
      return void 0;
    }
  }
  function observeRequest(url, auth) {
    if (auth && /^Bearer /.test(auth)) bearer = auth;
    const id = aboutQueryId(url);
    if (id && id !== queryId) {
      queryId = id;
      try {
        localStorage.setItem(QID_KEY, id);
      } catch {
      }
    }
  }
  var fetcher = new CountryFetcher({
    fetch: (...a) => origFetch(...a),
    queryId: () => queryId,
    headers: () => ({
      authorization: bearer,
      "x-csrf-token": /(?:^|; )ct0=([^;]+)/.exec(document.cookie)?.[1] ?? "",
      "x-twitter-auth-type": "OAuth2Session",
      "x-twitter-active-user": "yes"
    })
  });
  window.addEventListener("message", (e) => {
    if (e.source !== window || e.data?.ns !== MSG_NS) return;
    if (e.data.type === "config") capture = !!e.data.capture;
    else if (e.data.type === "lookupCountry" && typeof e.data.handle === "string") {
      const handle2 = e.data.handle;
      fetcher.lookup(handle2).then((result) => window.postMessage({ ns: MSG_NS, type: "countryResult", handle: handle2, result }, location.origin));
    }
  });
  function handle(url, json) {
    try {
      const posts = parser.parse(json);
      if (posts.length) window.postMessage({ ns: MSG_NS, type: "posts", posts }, location.origin);
      if (capture) window.postMessage({ ns: MSG_NS, type: "capture", url, body: json }, location.origin);
    } catch {
    }
  }
  var origFetch = window.fetch;
  window.fetch = async function(...args) {
    const res = await origFetch.apply(this, args);
    try {
      const input = args[0];
      const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
      const h = args[1]?.headers ?? (input instanceof Request ? input.headers : void 0);
      observeRequest(url, h instanceof Headers ? h.get("authorization") : Array.isArray(h) ? void 0 : h?.authorization);
      if (isTimelineUrl(url)) {
        res.clone().json().then((j) => handle(url, j), () => {
        });
      }
    } catch {
    }
    return res;
  };
  var origOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    const href = String(url);
    observeRequest(href);
    if (isTimelineUrl(href)) {
      this.addEventListener("load", () => {
        try {
          const body = this.responseType === "json" ? this.response : this.responseType === "" || this.responseType === "text" ? JSON.parse(this.responseText) : void 0;
          if (body) handle(href, body);
        } catch {
        }
      });
    }
    return origOpen.call(this, method, url, ...rest);
  };
  var origSetHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
    if (name.toLowerCase() === "authorization") observeRequest("", value);
    return origSetHeader.call(this, name, value);
  };
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvdW50cnkudHMiLCAiLi4vc3JjL3BhcnNlci50cyIsICIuLi9zcmMvdHlwZXMudHMiLCAiLi4vc3JjL2luamVjdC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0IHR5cGUgeyBDb3VudHJ5UmVjb3JkIH0gZnJvbSAnLi90eXBlcyc7XG5cbmV4cG9ydCBjb25zdCBBQk9VVF9PUCA9ICdBYm91dEFjY291bnRRdWVyeSc7XG4vKiogUXVlcnkgSUQgb2JzZXJ2ZWQgMjAyNi0xMS0xMTsgcmVmcmVzaGVkIGF1dG9tYXRpY2FsbHkgZnJvbSBYJ3Mgb3duIHRyYWZmaWMgd2hlbiBpdCByb3RhdGVzLiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfQUJPVVRfUVVFUllfSUQgPSAnVHpPRzJ0d1pFZmhyOUttQ2x2VlZxQSc7XG4vKiogWCB3ZWIgY2xpZW50J3MgcHVibGljIGJlYXJlciB0b2tlbjsgcmVwbGFjZWQgYnkgd2hhdGV2ZXIgWCBpdHNlbGYgc2VuZHMgd2hlbiBvYnNlcnZlZC4gKi9cbmV4cG9ydCBjb25zdCBERUZBVUxUX0JFQVJFUiA9XG4gICdCZWFyZXIgQUFBQUFBQUFBQUFBQUFBQUFBQUFBTlJJTGdBQUFBQUFuTndJelVlalJDT3VINUU2STh4blp6NHB1VHMlM0QxWnY3dHRmazhMRjgxSVVxMTZjSGpoTFR2SnU0RkEzM0FHV1dqQ3BUbkEnO1xuXG5leHBvcnQgY29uc3QgS05PV05fVFRMX01TID0gMzAgKiAyNCAqIDM2MDBfMDAwO1xuZXhwb3J0IGNvbnN0IFVOS05PV05fVFRMX01TID0gMjQgKiAzNjAwXzAwMDtcblxuZXhwb3J0IGludGVyZmFjZSBBYm91dEluZm8ge1xuICBjb3VudHJ5Pzogc3RyaW5nO1xuICBhY2N1cmF0ZT86IGJvb2xlYW47XG59XG5cbi8qKiBGaW5kcyBgYWJvdXRfcHJvZmlsZWAgYW55d2hlcmUgaW4gYW4gQWJvdXRBY2NvdW50UXVlcnkgcmVzcG9uc2UuIE5ldmVyIHRocm93cy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUFib3V0KGpzb246IHVua25vd24pOiBBYm91dEluZm8ge1xuICBjb25zdCBzdGFjazogdW5rbm93bltdID0gW2pzb25dO1xuICB3aGlsZSAoc3RhY2subGVuZ3RoKSB7XG4gICAgY29uc3QgbiA9IHN0YWNrLnBvcCgpO1xuICAgIGlmICh0eXBlb2YgbiAhPT0gJ29iamVjdCcgfHwgbiA9PT0gbnVsbCkgY29udGludWU7XG4gICAgY29uc3QgYWJvdXQgPSAobiBhcyBhbnkpLmFib3V0X3Byb2ZpbGU7XG4gICAgaWYgKGFib3V0ICYmIHR5cGVvZiBhYm91dCA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGNvbnN0IGMgPSBhYm91dC5hY2NvdW50X2Jhc2VkX2luO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY291bnRyeTogdHlwZW9mIGMgPT09ICdzdHJpbmcnICYmIGMudHJpbSgpID8gYy50cmltKCkgOiB1bmRlZmluZWQsXG4gICAgICAgIGFjY3VyYXRlOiB0eXBlb2YgYWJvdXQubG9jYXRpb25fYWNjdXJhdGUgPT09ICdib29sZWFuJyA/IGFib3V0LmxvY2F0aW9uX2FjY3VyYXRlIDogdW5kZWZpbmVkLFxuICAgICAgfTtcbiAgICB9XG4gICAgc3RhY2sucHVzaCguLi5PYmplY3QudmFsdWVzKG4pKTtcbiAgfVxuICByZXR1cm4ge307XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0ZyZXNoKHI6IENvdW50cnlSZWNvcmQgfCB1bmRlZmluZWQsIG5vdyA9IERhdGUubm93KCkpOiByIGlzIENvdW50cnlSZWNvcmQge1xuICBpZiAoIXIpIHJldHVybiBmYWxzZTtcbiAgcmV0dXJuIG5vdyAtIHIuZmV0Y2hlZEF0IDwgKHIuY291bnRyeSA/IEtOT1dOX1RUTF9NUyA6IFVOS05PV05fVFRMX01TKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzQWxsb3dlZChjb3VudHJ5OiBzdHJpbmcgfCB1bmRlZmluZWQsIGFsbG93ZWQ6IHN0cmluZ1tdKTogYm9vbGVhbiB7XG4gIGlmICghY291bnRyeSkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCBjID0gY291bnRyeS50b0xvd2VyQ2FzZSgpO1xuICByZXR1cm4gYWxsb3dlZC5zb21lKChhKSA9PiBhLnRyaW0oKS50b0xvd2VyQ2FzZSgpID09PSBjKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFib3V0UXVlcnlJZCh1cmw6IHN0cmluZyk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIHJldHVybiBuZXcgUmVnRXhwKGAvZ3JhcGhxbC8oW14vXSspLyR7QUJPVVRfT1B9XFxcXGJgKS5leGVjKHVybCk/LlsxXTtcbn1cblxuZXhwb3J0IHR5cGUgTG9va3VwUmVzdWx0ID0geyBvazogdHJ1ZTsgaW5mbzogQWJvdXRJbmZvIH0gfCB7IG9rOiBmYWxzZTsgZXJyb3I6IHN0cmluZyB9O1xuXG5leHBvcnQgaW50ZXJmYWNlIEZldGNoZXJEZXBzIHtcbiAgZmV0Y2g6IHR5cGVvZiBmZXRjaDtcbiAgcXVlcnlJZDogKCkgPT4gc3RyaW5nO1xuICBoZWFkZXJzOiAoKSA9PiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuICBub3c/OiAoKSA9PiBudW1iZXI7XG4gIHNsZWVwPzogKG1zOiBudW1iZXIpID0+IFByb21pc2U8dm9pZD47XG4gIC8qKiBNaW5pbXVtIGdhcCBiZXR3ZWVuIHJlcXVlc3RzLiAqL1xuICBnYXBNcz86IG51bWJlcjtcbn1cblxuLyoqXG4gKiBPbmUgcmVxdWVzdCBhdCBhIHRpbWUsIHNwYWNlZCBvdXQsIHBhdXNpbmcgdW50aWwgWCdzIHJhdGUtbGltaXQgcmVzZXQgd2hlbiB0aGVcbiAqIHdpbmRvdyAoNTAgcGVyIDE1IG1pbiBhdCB0aGUgdGltZSBvZiB3cml0aW5nKSBpcyBuZWFybHkgdXNlZCB1cC5cbiAqL1xuZXhwb3J0IGNsYXNzIENvdW50cnlGZXRjaGVyIHtcbiAgcHJpdmF0ZSBxdWV1ZTogeyBoYW5kbGU6IHN0cmluZzsgcmVzb2x2ZTogKHI6IExvb2t1cFJlc3VsdCkgPT4gdm9pZCB9W10gPSBbXTtcbiAgcHJpdmF0ZSBwZW5kaW5nID0gbmV3IE1hcDxzdHJpbmcsIFByb21pc2U8TG9va3VwUmVzdWx0Pj4oKTtcbiAgcHJpdmF0ZSBydW5uaW5nID0gZmFsc2U7XG4gIHByaXZhdGUgcmVzdW1lQXQgPSAwO1xuICBwcml2YXRlIG5vdzogKCkgPT4gbnVtYmVyO1xuICBwcml2YXRlIHNsZWVwOiAobXM6IG51bWJlcikgPT4gUHJvbWlzZTx2b2lkPjtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGQ6IEZldGNoZXJEZXBzKSB7XG4gICAgdGhpcy5ub3cgPSBkLm5vdyA/PyBEYXRlLm5vdztcbiAgICB0aGlzLnNsZWVwID0gZC5zbGVlcCA/PyAoKG1zKSA9PiBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dChyLCBtcykpKTtcbiAgfVxuXG4gIGxvb2t1cChoYW5kbGU6IHN0cmluZyk6IFByb21pc2U8TG9va3VwUmVzdWx0PiB7XG4gICAgY29uc3Qga2V5ID0gaGFuZGxlLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgZXhpc3RpbmcgPSB0aGlzLnBlbmRpbmcuZ2V0KGtleSk7XG4gICAgaWYgKGV4aXN0aW5nKSByZXR1cm4gZXhpc3Rpbmc7XG4gICAgY29uc3QgcCA9IG5ldyBQcm9taXNlPExvb2t1cFJlc3VsdD4oKHJlc29sdmUpID0+IHRoaXMucXVldWUucHVzaCh7IGhhbmRsZSwgcmVzb2x2ZSB9KSk7XG4gICAgdGhpcy5wZW5kaW5nLnNldChrZXksIHApO1xuICAgIHAuZmluYWxseSgoKSA9PiB0aGlzLnBlbmRpbmcuZGVsZXRlKGtleSkpO1xuICAgIHRoaXMucHVtcCgpO1xuICAgIHJldHVybiBwO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBwdW1wKCkge1xuICAgIGlmICh0aGlzLnJ1bm5pbmcpIHJldHVybjtcbiAgICB0aGlzLnJ1bm5pbmcgPSB0cnVlO1xuICAgIHRyeSB7XG4gICAgICB3aGlsZSAodGhpcy5xdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgY29uc3Qgd2FpdCA9IHRoaXMucmVzdW1lQXQgLSB0aGlzLm5vdygpO1xuICAgICAgICBpZiAod2FpdCA+IDApIGF3YWl0IHRoaXMuc2xlZXAod2FpdCk7XG4gICAgICAgIGNvbnN0IGpvYiA9IHRoaXMucXVldWUuc2hpZnQoKSE7XG4gICAgICAgIGNvbnN0IHIgPSBhd2FpdCB0aGlzLm9uY2Uoam9iLmhhbmRsZSk7XG4gICAgICAgIGlmICghci5vayAmJiByLmVycm9yID09PSAncmF0ZV9saW1pdGVkJykge1xuICAgICAgICAgIHRoaXMucXVldWUudW5zaGlmdChqb2IpO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGpvYi5yZXNvbHZlKHIpO1xuICAgICAgICB0aGlzLnJlc3VtZUF0ID0gTWF0aC5tYXgodGhpcy5yZXN1bWVBdCwgdGhpcy5ub3coKSArICh0aGlzLmQuZ2FwTXMgPz8gMTAwMCkpO1xuICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICB0aGlzLnJ1bm5pbmcgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIG9uY2UoaGFuZGxlOiBzdHJpbmcpOiBQcm9taXNlPExvb2t1cFJlc3VsdD4ge1xuICAgIGNvbnN0IHVybCA9IGAvaS9hcGkvZ3JhcGhxbC8ke3RoaXMuZC5xdWVyeUlkKCl9LyR7QUJPVVRfT1B9P3ZhcmlhYmxlcz0ke2VuY29kZVVSSUNvbXBvbmVudChKU09OLnN0cmluZ2lmeSh7IHNjcmVlbk5hbWU6IGhhbmRsZSB9KSl9YDtcbiAgICBsZXQgcmVzOiBSZXNwb25zZTtcbiAgICB0cnkge1xuICAgICAgcmVzID0gYXdhaXQgdGhpcy5kLmZldGNoKHVybCwgeyBjcmVkZW50aWFsczogJ2luY2x1ZGUnLCBoZWFkZXJzOiB0aGlzLmQuaGVhZGVycygpIH0pO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICduZXR3b3JrJyB9O1xuICAgIH1cbiAgICBjb25zdCByZW1haW5pbmcgPSBOdW1iZXIocmVzLmhlYWRlcnMuZ2V0KCd4LXJhdGUtbGltaXQtcmVtYWluaW5nJykpO1xuICAgIGNvbnN0IHJlc2V0ID0gTnVtYmVyKHJlcy5oZWFkZXJzLmdldCgneC1yYXRlLWxpbWl0LXJlc2V0JykpICogMTAwMDtcbiAgICBjb25zdCByZXNldEF0ID0gcmVzZXQgPiB0aGlzLm5vdygpID8gcmVzZXQgKyAxMDAwIDogdGhpcy5ub3coKSArIDYwXzAwMDtcbiAgICBpZiAocmVzLnN0YXR1cyA9PT0gNDI5KSB7XG4gICAgICB0aGlzLnJlc3VtZUF0ID0gcmVzZXRBdDtcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdyYXRlX2xpbWl0ZWQnIH07XG4gICAgfVxuICAgIC8vIEtlZXAgYSBsaXR0bGUgaGVhZHJvb20gc28gWCdzIG93biBBYm91dCBwYWdlcyBzdGlsbCB3b3JrLlxuICAgIGlmIChOdW1iZXIuaXNGaW5pdGUocmVtYWluaW5nKSAmJiByZXMuaGVhZGVycy5oYXMoJ3gtcmF0ZS1saW1pdC1yZW1haW5pbmcnKSAmJiByZW1haW5pbmcgPD0gMikgdGhpcy5yZXN1bWVBdCA9IHJlc2V0QXQ7XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMCB8fCByZXMuc3RhdHVzID09PSA0MDQpIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdzdGFsZV9xdWVyeScgfTtcbiAgICBpZiAoIXJlcy5vaykgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogYGh0dHBfJHtyZXMuc3RhdHVzfWAgfTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIHsgb2s6IHRydWUsIGluZm86IHBhcnNlQWJvdXQoYXdhaXQgcmVzLmpzb24oKSkgfTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdiYWRfanNvbicgfTtcbiAgICB9XG4gIH1cbn1cbiIsICJpbXBvcnQgdHlwZSB7IFBvc3QgfSBmcm9tICcuL3R5cGVzJztcblxuZXhwb3J0IGludGVyZmFjZSBUaW1lbGluZVBhcnNlciB7XG4gIHBhcnNlKGpzb246IHVua25vd24pOiBQb3N0W107XG59XG5cbnR5cGUgT2JqID0gUmVjb3JkPHN0cmluZywgYW55PjtcblxuY29uc3QgaXNPYmogPSAodjogdW5rbm93bik6IHYgaXMgT2JqID0+IHR5cGVvZiB2ID09PSAnb2JqZWN0JyAmJiB2ICE9PSBudWxsO1xuXG4vKiogVW53cmFwIFR3ZWV0V2l0aFZpc2liaWxpdHlSZXN1bHRzIGFuZCBzaW1pbGFyIHdyYXBwZXJzIGRvd24gdG8gYSBUd2VldCBvYmplY3QuICovXG5mdW5jdGlvbiB1bndyYXBUd2VldCh2OiB1bmtub3duKTogT2JqIHwgdW5kZWZpbmVkIHtcbiAgaWYgKCFpc09iaih2KSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgaWYgKHYuX190eXBlbmFtZSA9PT0gJ1R3ZWV0JykgcmV0dXJuIHY7XG4gIGlmICh2Ll9fdHlwZW5hbWUgPT09ICdUd2VldFdpdGhWaXNpYmlsaXR5UmVzdWx0cycgJiYgaXNPYmoodi50d2VldCkpIHJldHVybiB1bndyYXBUd2VldCh2LnR3ZWV0KTtcbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxuZnVuY3Rpb24gc2NyZWVuTmFtZSh0d2VldDogT2JqKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgY29uc3QgdXNlciA9IHR3ZWV0LmNvcmU/LnVzZXJfcmVzdWx0cz8ucmVzdWx0O1xuICBjb25zdCBuYW1lID0gdXNlcj8uY29yZT8uc2NyZWVuX25hbWUgPz8gdXNlcj8ubGVnYWN5Py5zY3JlZW5fbmFtZTtcbiAgcmV0dXJuIHR5cGVvZiBuYW1lID09PSAnc3RyaW5nJyA/IG5hbWUgOiB1bmRlZmluZWQ7XG59XG5cbmZ1bmN0aW9uIHR3ZWV0VGV4dCh0d2VldDogT2JqKTogc3RyaW5nIHtcbiAgY29uc3Qgbm90ZSA9IHR3ZWV0Lm5vdGVfdHdlZXQ/Lm5vdGVfdHdlZXRfcmVzdWx0cz8ucmVzdWx0Py50ZXh0O1xuICBpZiAodHlwZW9mIG5vdGUgPT09ICdzdHJpbmcnICYmIG5vdGUpIHJldHVybiBub3RlO1xuICBjb25zdCBmdWxsID0gdHdlZXQubGVnYWN5Py5mdWxsX3RleHQ7XG4gIHJldHVybiB0eXBlb2YgZnVsbCA9PT0gJ3N0cmluZycgPyBmdWxsIDogJyc7XG59XG5cbi8qKiBYIHNlcnZlcyBhbnkgc2l6ZSBvZiBhIHBob3RvIGJ5IHF1ZXJ5IHN0cmluZzsgMzYweDM2MCBpcyBlbm91Z2ggZm9yIGQxIHRvIHJlYWQgdGV4dCBpbiBpbWFnZXMuICovXG5leHBvcnQgY29uc3QgSU1BR0VfU0laRSA9ICczNjB4MzYwJztcbmV4cG9ydCBjb25zdCBNQVhfSU1BR0VTID0gMjtcblxuLyoqIE5vcm1hbGl6ZXMgYSBwYnMudHdpbWcuY29tL21lZGlhIFVSTCAoYW55IGV4dGVuc2lvbiBvciBxdWVyeSkgdG8gYSBzbWFsbCBKUEVHLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNjb3JpbmdJbWFnZVVybCh1cmw6IHN0cmluZyk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IG0gPSAvXmh0dHBzOlxcL1xcL3Bic1xcLnR3aW1nXFwuY29tXFwvbWVkaWFcXC8oW0EtWmEtejAtOV8tXSspLy5leGVjKHVybCk7XG4gIHJldHVybiBtID8gYGh0dHBzOi8vcGJzLnR3aW1nLmNvbS9tZWRpYS8ke21bMV19P2Zvcm1hdD1qcGcmbmFtZT0ke0lNQUdFX1NJWkV9YCA6IHVuZGVmaW5lZDtcbn1cblxuZnVuY3Rpb24gcGhvdG9VcmxzKHR3ZWV0OiBPYmopOiBzdHJpbmdbXSB7XG4gIGNvbnN0IG1lZGlhID0gdHdlZXQubGVnYWN5Py5leHRlbmRlZF9lbnRpdGllcz8ubWVkaWEgPz8gdHdlZXQubGVnYWN5Py5lbnRpdGllcz8ubWVkaWE7XG4gIGlmICghQXJyYXkuaXNBcnJheShtZWRpYSkpIHJldHVybiBbXTtcbiAgcmV0dXJuIG1lZGlhXG4gICAgLmZpbHRlcigobTogYW55KSA9PiBtPy50eXBlID09PSAncGhvdG8nICYmIHR5cGVvZiBtLm1lZGlhX3VybF9odHRwcyA9PT0gJ3N0cmluZycpXG4gICAgLm1hcCgobTogYW55KSA9PiBzY29yaW5nSW1hZ2VVcmwobS5tZWRpYV91cmxfaHR0cHMpKVxuICAgIC5maWx0ZXIoKHU6IHN0cmluZyB8IHVuZGVmaW5lZCk6IHUgaXMgc3RyaW5nID0+ICEhdSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0UG9zdCh0d2VldDogT2JqKTogUG9zdCB8IHVuZGVmaW5lZCB7XG4gIGNvbnN0IGlkID0gdHdlZXQucmVzdF9pZDtcbiAgaWYgKHR5cGVvZiBpZCAhPT0gJ3N0cmluZycgfHwgIWlkKSByZXR1cm4gdW5kZWZpbmVkO1xuICBjb25zdCBwb3N0OiBQb3N0ID0ge1xuICAgIGlkLFxuICAgIHRleHQ6IHR3ZWV0VGV4dCh0d2VldCksXG4gICAgYXV0aG9yOiBzY3JlZW5OYW1lKHR3ZWV0KSxcbiAgICBpc1JlcGx5OiB0eXBlb2YgdHdlZXQubGVnYWN5Py5pbl9yZXBseV90b19zdGF0dXNfaWRfc3RyID09PSAnc3RyaW5nJyxcbiAgICBzb3VyY2U6ICdwYXJzZXInLFxuICB9O1xuICBjb25zdCBpbWFnZXMgPSBwaG90b1VybHModHdlZXQpO1xuICBjb25zdCBxdW90ZWQgPSB1bndyYXBUd2VldCh0d2VldC5xdW90ZWRfc3RhdHVzX3Jlc3VsdD8ucmVzdWx0KTtcbiAgaWYgKHF1b3RlZCkge1xuICAgIHBvc3QucXVvdGVkVGV4dCA9IHR3ZWV0VGV4dChxdW90ZWQpO1xuICAgIHBvc3QucXVvdGVkQXV0aG9yID0gc2NyZWVuTmFtZShxdW90ZWQpO1xuICAgIC8vIFRoZSB3YWxrIGluIHBhcnNlKCkgYWxzbyBlbWl0cyB0aGUgcXVvdGVkIHR3ZWV0IGFzIGl0cyBvd24gcG9zdCwgc28gaXQgaXMgc2NvcmVkIHNlcGFyYXRlbHkuXG4gICAgaWYgKHR5cGVvZiBxdW90ZWQucmVzdF9pZCA9PT0gJ3N0cmluZycgJiYgcXVvdGVkLnJlc3RfaWQpIHBvc3QucXVvdGVkSWQgPSBxdW90ZWQucmVzdF9pZDtcbiAgICBlbHNlIGltYWdlcy5wdXNoKC4uLnBob3RvVXJscyhxdW90ZWQpKTtcbiAgfVxuICBpZiAoaW1hZ2VzLmxlbmd0aCkgcG9zdC5pbWFnZVVybHMgPSBbLi4ubmV3IFNldChpbWFnZXMpXS5zbGljZSgwLCBNQVhfSU1BR0VTKTtcbiAgcmV0dXJuIHBvc3Q7XG59XG5cbi8qKiBUaGUgc2FtZSB0d2VldCBjYW4gYXBwZWFyIG1vcmUgdGhhbiBvbmNlIHdpdGggZGlmZmVyZW50IGRldGFpbDsga2VlcCBldmVyeSBub24tZW1wdHkgZmllbGQuICovXG5mdW5jdGlvbiBtZXJnZVBvc3RzKGE6IFBvc3QgfCB1bmRlZmluZWQsIGI6IFBvc3QpOiBQb3N0IHtcbiAgaWYgKCFhKSByZXR1cm4gYjtcbiAgY29uc3Qgb3V0OiBQb3N0ID0geyAuLi5hIH07XG4gIGZvciAoY29uc3QgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGIpIGFzIFtrZXlvZiBQb3N0LCBhbnldW10pIHtcbiAgICBpZiAob3V0W2tdID09PSB1bmRlZmluZWQgfHwgb3V0W2tdID09PSAnJyB8fCBvdXRba10gPT09IGZhbHNlKSAob3V0IGFzIGFueSlba10gPSB2O1xuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbi8qKiBXYWxrcyBhbnkgWCBHcmFwaFFMIHJlc3BvbnNlIGFuZCBjb2xsZWN0cyBldmVyeSBUd2VldCBpdCBjb250YWlucy4gTmV2ZXIgdGhyb3dzLiAqL1xuZXhwb3J0IGNsYXNzIEdyYXBoUUxUaW1lbGluZVBhcnNlciBpbXBsZW1lbnRzIFRpbWVsaW5lUGFyc2VyIHtcbiAgcGFyc2UoanNvbjogdW5rbm93bik6IFBvc3RbXSB7XG4gICAgY29uc3Qgb3V0ID0gbmV3IE1hcDxzdHJpbmcsIFBvc3Q+KCk7XG4gICAgY29uc3Qgc3RhY2s6IHVua25vd25bXSA9IFtqc29uXTtcbiAgICBjb25zdCBzZWVuID0gbmV3IFNldDx1bmtub3duPigpO1xuICAgIHdoaWxlIChzdGFjay5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IG5vZGUgPSBzdGFjay5wb3AoKTtcbiAgICAgIGlmICghaXNPYmoobm9kZSkgfHwgc2Vlbi5oYXMobm9kZSkpIGNvbnRpbnVlO1xuICAgICAgc2Vlbi5hZGQobm9kZSk7XG4gICAgICBjb25zdCB0d2VldCA9IHVud3JhcFR3ZWV0KG5vZGUpO1xuICAgICAgaWYgKHR3ZWV0ICYmIHR3ZWV0ID09PSBub2RlKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcG9zdCA9IGV4dHJhY3RQb3N0KHR3ZWV0KTtcbiAgICAgICAgICBpZiAocG9zdCkgb3V0LnNldChwb3N0LmlkLCBtZXJnZVBvc3RzKG91dC5nZXQocG9zdC5pZCksIHBvc3QpKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8gdG9sZXJhdGUgYW55IG1hbGZvcm1lZCB0d2VldFxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IHYgb2YgQXJyYXkuaXNBcnJheShub2RlKSA/IG5vZGUgOiBPYmplY3QudmFsdWVzKG5vZGUpKSB7XG4gICAgICAgIGlmIChpc09iaih2KSkgc3RhY2sucHVzaCh2KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIFsuLi5vdXQudmFsdWVzKCldO1xuICB9XG59XG5cbmV4cG9ydCBjb25zdCBUSU1FTElORV9PUFMgPSBbJ0hvbWVUaW1lbGluZScsICdIb21lTGF0ZXN0VGltZWxpbmUnLCAnVHdlZXREZXRhaWwnLCAnVXNlclR3ZWV0cycsICdTZWFyY2hUaW1lbGluZSddO1xuXG5leHBvcnQgZnVuY3Rpb24gaXNUaW1lbGluZVVybCh1cmw6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCBtID0gL1xcL2dyYXBocWxcXC9bXi9dK1xcLyhbQS1aYS16XSspLy5leGVjKHVybCk7XG4gIHJldHVybiAhIW0gJiYgVElNRUxJTkVfT1BTLmluY2x1ZGVzKG1bMV0pO1xufVxuIiwgImV4cG9ydCBpbnRlcmZhY2UgUG9zdCB7XG4gIGlkOiBzdHJpbmc7XG4gIHRleHQ6IHN0cmluZztcbiAgYXV0aG9yPzogc3RyaW5nO1xuICBxdW90ZWRUZXh0Pzogc3RyaW5nO1xuICBxdW90ZWRBdXRob3I/OiBzdHJpbmc7XG4gIC8qKlxuICAgKiBUaGUgcXVvdGVkIHBvc3QncyBpZCB3aGVuIGtub3duIChmcm9tIFgncyBKU09OKS4gVGhlIHF1b3RlZCBwb3N0IGlzIHRoZW4gc2NvcmVkIG9uIGl0cyBvd24sXG4gICAqIGFuZCB0aGlzIHBvc3QgaXMgc2NvcmVkIHdpdGhvdXQgaXQ7IERPTS1zY3JhcGVkIHBvc3RzIGxhY2sgaXQgYW5kIGFyZSBzY29yZWQgd2l0aCB0aGUgcXVvdGUuXG4gICAqL1xuICBxdW90ZWRJZD86IHN0cmluZztcbiAgLyoqIFRoaXMgcG9zdCdzIG93biBwaG90byBVUkxzIChub3QgdGhlIHF1b3RlJ3Mgd2hlbiBxdW90ZWRJZCBpcyBzZXQpLCBzaXplZCBmb3Igc2NvcmluZy4gKi9cbiAgaW1hZ2VVcmxzPzogc3RyaW5nW107XG4gIGlzUmVwbHk6IGJvb2xlYW47XG4gIC8qKiBcInBhcnNlclwiIHdoZW4gaXQgY2FtZSBmcm9tIGludGVyY2VwdGVkIEpTT04sIFwiZG9tXCIgd2hlbiBzY3JhcGVkIGFzIGEgZmFsbGJhY2suICovXG4gIHNvdXJjZT86ICdwYXJzZXInIHwgJ2RvbSc7XG59XG5cbmV4cG9ydCB0eXBlIERlY2lzaW9uID0gJ2hpZGUnIHwgJ2JsdXInIHwgJ3Nob3cnO1xuZXhwb3J0IHR5cGUgTGFiZWxWYWx1ZSA9ICdyYWdlYmFpdCcgfCAncmFjaXN0JyB8ICdmaW5lJztcbmV4cG9ydCB0eXBlIExhYmVsU291cmNlID0gJ3VzZXJfYnV0dG9uJyB8ICdzaG93X2NsaWNrJyB8ICdhY2NvdW50X3NlZWQnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFF1ZXN0aW9uIHtcbiAgaWQ6IHN0cmluZztcbiAgdGV4dDogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFF1ZXN0aW9uc0NvbmZpZyB7XG4gIHZlcnNpb246IG51bWJlcjtcbiAgcXVlc3Rpb25zOiBRdWVzdGlvbltdO1xuICBjb21iaW5lOiB7IG1heF9vZjogc3RyaW5nW107IHdlaWdodGVkOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+IH07XG4gIHRocmVzaG9sZHM6IFRocmVzaG9sZHM7XG4gIC8qKlxuICAgKiBBc2tlZCAoaW4gYSBzZWNvbmQsIG9uZS1xdWVzdGlvbiBjYWxsKSBvbmx5IGZvciBwb3N0cyB0aGF0IHF1b3RlIGEgcG9zdCBzY29yaW5nIGF0IGxlYXN0IHRoZSBibHVyXG4gICAqIHRocmVzaG9sZC4gQXQgb3IgYWJvdmUgYHRocmVzaG9sZGAsIHRoZSBxdW90aW5nIHBvc3QgaW5oZXJpdHMgdGhlIHF1b3RlZCBwb3N0J3Mgc2NvcmUuXG4gICAqL1xuICBzdGFuY2U/OiBRdWVzdGlvbiAmIHsgdGhyZXNob2xkOiBudW1iZXIgfTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBUaHJlc2hvbGRzIHtcbiAgaGlkZTogbnVtYmVyO1xuICBibHVyOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUG9zdFJlY29yZCB7XG4gIGlkOiBzdHJpbmc7XG4gIHRleHQ6IHN0cmluZztcbiAgcXVvdGVkVGV4dD86IHN0cmluZztcbiAgcXVvdGVkSWQ/OiBzdHJpbmc7XG4gIC8qKiBQKGF1dGhvciBlbmRvcnNlcyB0aGUgcXVvdGVkIHBvc3QpLCBvbmNlIGFza2VkLiAqL1xuICBlbmRvcnNlc1F1b3RlPzogbnVtYmVyO1xuICBhdXRob3I/OiBzdHJpbmc7XG4gIHNlZW5BdDogbnVtYmVyO1xuICBwcm9iczogUmVjb3JkPHN0cmluZywgbnVtYmVyPjtcbiAgc2NvcmU6IG51bWJlcjtcbiAgZGVjaXNpb246IERlY2lzaW9uO1xuICBxdWVzdGlvbnNWZXJzaW9uOiBudW1iZXI7XG4gIC8qKiBcInNlZWRlZFwiIHdoZW4gZGVjaWRlZCBieSB0aGUgYWNjb3VudCBzZWVkIGxpc3QsIFwiZDFcIiB3aGVuIHNjb3JlZC4gKi9cbiAgcmVhc29uPzogJ3NlZWRlZCcgfCAnZDEnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIExhYmVsUmVjb3JkIHtcbiAgaWQ/OiBudW1iZXI7XG4gIHBvc3RJZDogc3RyaW5nO1xuICBsYWJlbDogTGFiZWxWYWx1ZTtcbiAgc291cmNlOiBMYWJlbFNvdXJjZTtcbiAgYXQ6IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBBdXRob3JSZWNvcmQge1xuICBoYW5kbGU6IHN0cmluZztcbiAgYWxwaGE6IG51bWJlcjtcbiAgYmV0YTogbnVtYmVyO1xuICBzZWVkZWQ6IGJvb2xlYW47XG4gIHNlZWRUZXh0Pzogc3RyaW5nO1xuICBwb3N0c1NlZW46IG51bWJlcjtcbn1cblxuLyoqIFdoYXQgdGhlIGJhY2tncm91bmQgcmV0dXJucyB0byBhIHRhYiBmb3Igb25lIHBvc3QuICovXG5leHBvcnQgaW50ZXJmYWNlIFZlcmRpY3Qge1xuICBwb3N0SWQ6IHN0cmluZztcbiAgLyoqIFwidW5zY29yZWRcIiB3aGVuIHNjb3Jpbmcgd2FzIHNraXBwZWQgKG5vIGtleSwgYnVkZ2V0IGV4Y2VlZGVkLCBBUEkgZXJyb3IpLiAqL1xuICBkZWNpc2lvbjogRGVjaXNpb24gfCAndW5zY29yZWQnO1xuICBzY29yZT86IG51bWJlcjtcbiAgdG9wUXVlc3Rpb24/OiBzdHJpbmc7XG4gIGF1dGhvcj86IHN0cmluZztcbiAgYXV0aG9yU2NvcmU/OiBudW1iZXI7XG4gIHJlYXNvbj86ICdzZWVkZWQnIHwgJ2QxJyB8ICdjYWNoZScgfCAnYnVkZ2V0JyB8ICdub19rZXknIHwgJ2Vycm9yJyB8ICdjb3VudHJ5JztcbiAgLyoqIFRoZSBhdXRob3IncyBcIkFjY291bnQgYmFzZWQgaW5cIiB2YWx1ZSwgd2hlbiBrbm93bi4gKi9cbiAgY291bnRyeT86IHN0cmluZztcbiAgLyoqIFNldCAod2l0aCBkZWNpc2lvbiBcInVuc2NvcmVkXCIpIHdoZW4gdGhlIHRvcGljIGZpcmVkIGFuZCB0aGUgYXV0aG9yJ3MgY291bnRyeSBtdXN0IGJlIGxvb2tlZCB1cCBmaXJzdC4gKi9cbiAgbmVlZHNDb3VudHJ5Pzogc3RyaW5nO1xufVxuXG4vKiogQ2FjaGVkIFwiQWJvdXQgdGhpcyBhY2NvdW50XCIgcmVzdWx0LiBgY291bnRyeWAgaXMgdW5kZWZpbmVkIHdoZW4gWCByZXR1cm5lZCBub3RoaW5nLiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb3VudHJ5UmVjb3JkIHtcbiAgaGFuZGxlOiBzdHJpbmc7XG4gIGNvdW50cnk/OiBzdHJpbmc7XG4gIC8qKiBYJ3MgbG9jYXRpb25fYWNjdXJhdGUgZmxhZyAoZmFsc2UgaGludHMgYXQgYSBWUE4vcHJveHkpLiAqL1xuICBhY2N1cmF0ZT86IGJvb2xlYW47XG4gIGZldGNoZWRBdDogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNldHRpbmdzIHtcbiAgYXBpS2V5OiBzdHJpbmc7XG4gIG1vZGVsOiBzdHJpbmc7XG4gIHRocmVzaG9sZHM6IFRocmVzaG9sZHM7XG4gIGVuYWJsZWQ6IHsgcGVuZGluZzogYm9vbGVhbjsgaGlkZTogYm9vbGVhbjsgYmx1cjogYm9vbGVhbjsgZmxhZzogYm9vbGVhbiB9O1xuICBkYWlseVRva2VuQnVkZ2V0OiBudW1iZXI7XG4gIGNhcHR1cmVGaXh0dXJlczogYm9vbGVhbjtcbiAgLyoqIFwiQWNjb3VudCBiYXNlZCBpblwiIHZhbHVlcyB3aG9zZSBwb3N0cyBhcmUgbmV2ZXIgZmlsdGVyZWQgKGNhc2UtaW5zZW5zaXRpdmUpLiAqL1xuICBhbGxvd2VkQ291bnRyaWVzOiBzdHJpbmdbXTtcbiAgLyoqIFNlbmQgYXR0YWNoZWQgcGhvdG9zIHRvIGQxIGFsb25nIHdpdGggdGhlIHRleHQuICovXG4gIHNjb3JlSW1hZ2VzOiBib29sZWFuO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFVzYWdlIHtcbiAgZGF0ZTogc3RyaW5nO1xuICB0b2tlbnM6IG51bWJlcjtcbiAgc2NvcmVkOiBudW1iZXI7XG4gIGRlY2lzaW9uczogUmVjb3JkPERlY2lzaW9uLCBudW1iZXI+O1xufVxuXG5leHBvcnQgY29uc3QgTVNHX05TID0gJ2JhaXRibG9ja2VyOnYxJztcbiIsICIvLyBNQUlOLXdvcmxkIHNjcmlwdDogb2JzZXJ2ZXMgWCdzIEdyYXBoUUwgdGltZWxpbmUgcmVzcG9uc2VzIHdpdGhvdXQgYWx0ZXJpbmcgdGhlbS5cbmltcG9ydCB7IENvdW50cnlGZXRjaGVyLCBERUZBVUxUX0FCT1VUX1FVRVJZX0lELCBERUZBVUxUX0JFQVJFUiwgYWJvdXRRdWVyeUlkIH0gZnJvbSAnLi9jb3VudHJ5JztcbmltcG9ydCB7IEdyYXBoUUxUaW1lbGluZVBhcnNlciwgaXNUaW1lbGluZVVybCB9IGZyb20gJy4vcGFyc2VyJztcbmltcG9ydCB7IE1TR19OUyB9IGZyb20gJy4vdHlwZXMnO1xuXG5jb25zdCBwYXJzZXIgPSBuZXcgR3JhcGhRTFRpbWVsaW5lUGFyc2VyKCk7XG5sZXQgY2FwdHVyZSA9IGZhbHNlO1xuXG4vLyAtLS0tLS0tLS0tIGFjY291bnQtY291bnRyeSBsb29rdXBzIChydW4gaGVyZSBzbyB0aGV5IGNhcnJ5IHRoZSB1c2VyJ3MgWCBzZXNzaW9uKSAtLS0tLS0tLS0tXG5cbmNvbnN0IFFJRF9LRVkgPSAnYmFpdGJsb2NrZXI6YWJvdXRRdWVyeUlkJztcbmxldCBxdWVyeUlkID0gc2FmZUdldChRSURfS0VZKSA/PyBERUZBVUxUX0FCT1VUX1FVRVJZX0lEO1xubGV0IGJlYXJlciA9IERFRkFVTFRfQkVBUkVSO1xuXG5mdW5jdGlvbiBzYWZlR2V0KGs6IHN0cmluZyk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGxvY2FsU3RvcmFnZS5nZXRJdGVtKGspID8/IHVuZGVmaW5lZDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxufVxuXG4vKiogTGVhcm4gdGhlIGN1cnJlbnQgQWJvdXRBY2NvdW50UXVlcnkgaWQgYW5kIGJlYXJlciBmcm9tIFgncyBvd24gcmVxdWVzdHMuICovXG5mdW5jdGlvbiBvYnNlcnZlUmVxdWVzdCh1cmw6IHN0cmluZywgYXV0aD86IHN0cmluZyB8IG51bGwpIHtcbiAgaWYgKGF1dGggJiYgL15CZWFyZXIgLy50ZXN0KGF1dGgpKSBiZWFyZXIgPSBhdXRoO1xuICBjb25zdCBpZCA9IGFib3V0UXVlcnlJZCh1cmwpO1xuICBpZiAoaWQgJiYgaWQgIT09IHF1ZXJ5SWQpIHtcbiAgICBxdWVyeUlkID0gaWQ7XG4gICAgdHJ5IHtcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFFJRF9LRVksIGlkKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIGlnbm9yZVxuICAgIH1cbiAgfVxufVxuXG5jb25zdCBmZXRjaGVyID0gbmV3IENvdW50cnlGZXRjaGVyKHtcbiAgZmV0Y2g6ICguLi5hKSA9PiBvcmlnRmV0Y2goLi4uYSksXG4gIHF1ZXJ5SWQ6ICgpID0+IHF1ZXJ5SWQsXG4gIGhlYWRlcnM6ICgpID0+ICh7XG4gICAgYXV0aG9yaXphdGlvbjogYmVhcmVyLFxuICAgICd4LWNzcmYtdG9rZW4nOiAvKD86Xnw7ICljdDA9KFteO10rKS8uZXhlYyhkb2N1bWVudC5jb29raWUpPy5bMV0gPz8gJycsXG4gICAgJ3gtdHdpdHRlci1hdXRoLXR5cGUnOiAnT0F1dGgyU2Vzc2lvbicsXG4gICAgJ3gtdHdpdHRlci1hY3RpdmUtdXNlcic6ICd5ZXMnLFxuICB9KSxcbn0pO1xuXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIChlKSA9PiB7XG4gIGlmIChlLnNvdXJjZSAhPT0gd2luZG93IHx8IGUuZGF0YT8ubnMgIT09IE1TR19OUykgcmV0dXJuO1xuICBpZiAoZS5kYXRhLnR5cGUgPT09ICdjb25maWcnKSBjYXB0dXJlID0gISFlLmRhdGEuY2FwdHVyZTtcbiAgZWxzZSBpZiAoZS5kYXRhLnR5cGUgPT09ICdsb29rdXBDb3VudHJ5JyAmJiB0eXBlb2YgZS5kYXRhLmhhbmRsZSA9PT0gJ3N0cmluZycpIHtcbiAgICBjb25zdCBoYW5kbGU6IHN0cmluZyA9IGUuZGF0YS5oYW5kbGU7XG4gICAgZmV0Y2hlci5sb29rdXAoaGFuZGxlKS50aGVuKChyZXN1bHQpID0+IHdpbmRvdy5wb3N0TWVzc2FnZSh7IG5zOiBNU0dfTlMsIHR5cGU6ICdjb3VudHJ5UmVzdWx0JywgaGFuZGxlLCByZXN1bHQgfSwgbG9jYXRpb24ub3JpZ2luKSk7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBoYW5kbGUodXJsOiBzdHJpbmcsIGpzb246IHVua25vd24pIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBwb3N0cyA9IHBhcnNlci5wYXJzZShqc29uKTtcbiAgICBpZiAocG9zdHMubGVuZ3RoKSB3aW5kb3cucG9zdE1lc3NhZ2UoeyBuczogTVNHX05TLCB0eXBlOiAncG9zdHMnLCBwb3N0cyB9LCBsb2NhdGlvbi5vcmlnaW4pO1xuICAgIGlmIChjYXB0dXJlKSB3aW5kb3cucG9zdE1lc3NhZ2UoeyBuczogTVNHX05TLCB0eXBlOiAnY2FwdHVyZScsIHVybCwgYm9keToganNvbiB9LCBsb2NhdGlvbi5vcmlnaW4pO1xuICB9IGNhdGNoIHtcbiAgICAvLyBuZXZlciBsZXQgcGFyc2luZyBhZmZlY3QgdGhlIHBhZ2VcbiAgfVxufVxuXG5jb25zdCBvcmlnRmV0Y2ggPSB3aW5kb3cuZmV0Y2g7XG53aW5kb3cuZmV0Y2ggPSBhc3luYyBmdW5jdGlvbiAodGhpczogdW5rbm93biwgLi4uYXJnczogUGFyYW1ldGVyczx0eXBlb2YgZmV0Y2g+KSB7XG4gIGNvbnN0IHJlcyA9IGF3YWl0IG9yaWdGZXRjaC5hcHBseSh0aGlzLCBhcmdzKTtcbiAgdHJ5IHtcbiAgICBjb25zdCBpbnB1dCA9IGFyZ3NbMF07XG4gICAgY29uc3QgdXJsID0gdHlwZW9mIGlucHV0ID09PSAnc3RyaW5nJyA/IGlucHV0IDogaW5wdXQgaW5zdGFuY2VvZiBVUkwgPyBpbnB1dC5ocmVmIDogaW5wdXQudXJsO1xuICAgIGNvbnN0IGggPSBhcmdzWzFdPy5oZWFkZXJzID8/IChpbnB1dCBpbnN0YW5jZW9mIFJlcXVlc3QgPyBpbnB1dC5oZWFkZXJzIDogdW5kZWZpbmVkKTtcbiAgICBvYnNlcnZlUmVxdWVzdCh1cmwsIGggaW5zdGFuY2VvZiBIZWFkZXJzID8gaC5nZXQoJ2F1dGhvcml6YXRpb24nKSA6IEFycmF5LmlzQXJyYXkoaCkgPyB1bmRlZmluZWQgOiAoaCBhcyBhbnkpPy5hdXRob3JpemF0aW9uKTtcbiAgICBpZiAoaXNUaW1lbGluZVVybCh1cmwpKSB7XG4gICAgICByZXNcbiAgICAgICAgLmNsb25lKClcbiAgICAgICAgLmpzb24oKVxuICAgICAgICAudGhlbigoaikgPT4gaGFuZGxlKHVybCwgaiksICgpID0+IHt9KTtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIGlnbm9yZVxuICB9XG4gIHJldHVybiByZXM7XG59O1xuXG5jb25zdCBvcmlnT3BlbiA9IFhNTEh0dHBSZXF1ZXN0LnByb3RvdHlwZS5vcGVuO1xuWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLm9wZW4gPSBmdW5jdGlvbiAodGhpczogWE1MSHR0cFJlcXVlc3QsIG1ldGhvZDogc3RyaW5nLCB1cmw6IHN0cmluZyB8IFVSTCwgLi4ucmVzdDogYW55W10pIHtcbiAgY29uc3QgaHJlZiA9IFN0cmluZyh1cmwpO1xuICBvYnNlcnZlUmVxdWVzdChocmVmKTtcbiAgaWYgKGlzVGltZWxpbmVVcmwoaHJlZikpIHtcbiAgICB0aGlzLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBib2R5ID1cbiAgICAgICAgICB0aGlzLnJlc3BvbnNlVHlwZSA9PT0gJ2pzb24nID8gdGhpcy5yZXNwb25zZSA6IHRoaXMucmVzcG9uc2VUeXBlID09PSAnJyB8fCB0aGlzLnJlc3BvbnNlVHlwZSA9PT0gJ3RleHQnID8gSlNPTi5wYXJzZSh0aGlzLnJlc3BvbnNlVGV4dCkgOiB1bmRlZmluZWQ7XG4gICAgICAgIGlmIChib2R5KSBoYW5kbGUoaHJlZiwgYm9keSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gaWdub3JlXG4gICAgICB9XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIChvcmlnT3BlbiBhcyBhbnkpLmNhbGwodGhpcywgbWV0aG9kLCB1cmwsIC4uLnJlc3QpO1xufSBhcyB0eXBlb2YgWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLm9wZW47XG5cbmNvbnN0IG9yaWdTZXRIZWFkZXIgPSBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUuc2V0UmVxdWVzdEhlYWRlcjtcblhNTEh0dHBSZXF1ZXN0LnByb3RvdHlwZS5zZXRSZXF1ZXN0SGVhZGVyID0gZnVuY3Rpb24gKHRoaXM6IFhNTEh0dHBSZXF1ZXN0LCBuYW1lOiBzdHJpbmcsIHZhbHVlOiBzdHJpbmcpIHtcbiAgaWYgKG5hbWUudG9Mb3dlckNhc2UoKSA9PT0gJ2F1dGhvcml6YXRpb24nKSBvYnNlcnZlUmVxdWVzdCgnJywgdmFsdWUpO1xuICByZXR1cm4gb3JpZ1NldEhlYWRlci5jYWxsKHRoaXMsIG5hbWUsIHZhbHVlKTtcbn07XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFFTyxNQUFNLFdBQVc7QUFFakIsTUFBTSx5QkFBeUI7QUFFL0IsTUFBTSxpQkFDWDtBQUVLLE1BQU0sZUFBZSxLQUFLLEtBQUs7QUFDL0IsTUFBTSxpQkFBaUIsS0FBSztBQVE1QixXQUFTLFdBQVcsTUFBMEI7QUFDbkQsVUFBTSxRQUFtQixDQUFDLElBQUk7QUFDOUIsV0FBTyxNQUFNLFFBQVE7QUFDbkIsWUFBTSxJQUFJLE1BQU0sSUFBSTtBQUNwQixVQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sS0FBTTtBQUN6QyxZQUFNLFFBQVMsRUFBVTtBQUN6QixVQUFJLFNBQVMsT0FBTyxVQUFVLFVBQVU7QUFDdEMsY0FBTSxJQUFJLE1BQU07QUFDaEIsZUFBTztBQUFBLFVBQ0wsU0FBUyxPQUFPLE1BQU0sWUFBWSxFQUFFLEtBQUssSUFBSSxFQUFFLEtBQUssSUFBSTtBQUFBLFVBQ3hELFVBQVUsT0FBTyxNQUFNLHNCQUFzQixZQUFZLE1BQU0sb0JBQW9CO0FBQUEsUUFDckY7QUFBQSxNQUNGO0FBQ0EsWUFBTSxLQUFLLEdBQUcsT0FBTyxPQUFPLENBQUMsQ0FBQztBQUFBLElBQ2hDO0FBQ0EsV0FBTyxDQUFDO0FBQUEsRUFDVjtBQWFPLFdBQVMsYUFBYSxLQUFpQztBQUM1RCxXQUFPLElBQUksT0FBTyxvQkFBb0IsUUFBUSxLQUFLLEVBQUUsS0FBSyxHQUFHLElBQUksQ0FBQztBQUFBLEVBQ3BFO0FBa0JPLE1BQU0saUJBQU4sTUFBcUI7QUFBQSxJQVExQixZQUFvQixHQUFnQjtBQUFoQjtBQUNsQixXQUFLLE1BQU0sRUFBRSxPQUFPLEtBQUs7QUFDekIsV0FBSyxRQUFRLEVBQUUsVUFBVSxDQUFDLE9BQU8sSUFBSSxRQUFRLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFDdkU7QUFBQSxJQUhvQjtBQUFBLElBUFosUUFBa0UsQ0FBQztBQUFBLElBQ25FLFVBQVUsb0JBQUksSUFBbUM7QUFBQSxJQUNqRCxVQUFVO0FBQUEsSUFDVixXQUFXO0FBQUEsSUFDWDtBQUFBLElBQ0E7QUFBQSxJQU9SLE9BQU9BLFNBQXVDO0FBQzVDLFlBQU0sTUFBTUEsUUFBTyxZQUFZO0FBQy9CLFlBQU0sV0FBVyxLQUFLLFFBQVEsSUFBSSxHQUFHO0FBQ3JDLFVBQUksU0FBVSxRQUFPO0FBQ3JCLFlBQU0sSUFBSSxJQUFJLFFBQXNCLENBQUMsWUFBWSxLQUFLLE1BQU0sS0FBSyxFQUFFLFFBQUFBLFNBQVEsUUFBUSxDQUFDLENBQUM7QUFDckYsV0FBSyxRQUFRLElBQUksS0FBSyxDQUFDO0FBQ3ZCLFFBQUUsUUFBUSxNQUFNLEtBQUssUUFBUSxPQUFPLEdBQUcsQ0FBQztBQUN4QyxXQUFLLEtBQUs7QUFDVixhQUFPO0FBQUEsSUFDVDtBQUFBLElBRUEsTUFBYyxPQUFPO0FBQ25CLFVBQUksS0FBSyxRQUFTO0FBQ2xCLFdBQUssVUFBVTtBQUNmLFVBQUk7QUFDRixlQUFPLEtBQUssTUFBTSxRQUFRO0FBQ3hCLGdCQUFNLE9BQU8sS0FBSyxXQUFXLEtBQUssSUFBSTtBQUN0QyxjQUFJLE9BQU8sRUFBRyxPQUFNLEtBQUssTUFBTSxJQUFJO0FBQ25DLGdCQUFNLE1BQU0sS0FBSyxNQUFNLE1BQU07QUFDN0IsZ0JBQU0sSUFBSSxNQUFNLEtBQUssS0FBSyxJQUFJLE1BQU07QUFDcEMsY0FBSSxDQUFDLEVBQUUsTUFBTSxFQUFFLFVBQVUsZ0JBQWdCO0FBQ3ZDLGlCQUFLLE1BQU0sUUFBUSxHQUFHO0FBQ3RCO0FBQUEsVUFDRjtBQUNBLGNBQUksUUFBUSxDQUFDO0FBQ2IsZUFBSyxXQUFXLEtBQUssSUFBSSxLQUFLLFVBQVUsS0FBSyxJQUFJLEtBQUssS0FBSyxFQUFFLFNBQVMsSUFBSztBQUFBLFFBQzdFO0FBQUEsTUFDRixVQUFFO0FBQ0EsYUFBSyxVQUFVO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBQUEsSUFFQSxNQUFjLEtBQUtBLFNBQXVDO0FBQ3hELFlBQU0sTUFBTSxrQkFBa0IsS0FBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLFFBQVEsY0FBYyxtQkFBbUIsS0FBSyxVQUFVLEVBQUUsWUFBWUEsUUFBTyxDQUFDLENBQUMsQ0FBQztBQUNsSSxVQUFJO0FBQ0osVUFBSTtBQUNGLGNBQU0sTUFBTSxLQUFLLEVBQUUsTUFBTSxLQUFLLEVBQUUsYUFBYSxXQUFXLFNBQVMsS0FBSyxFQUFFLFFBQVEsRUFBRSxDQUFDO0FBQUEsTUFDckYsU0FBUyxHQUFHO0FBQ1YsZUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLFVBQVU7QUFBQSxNQUN2QztBQUNBLFlBQU0sWUFBWSxPQUFPLElBQUksUUFBUSxJQUFJLHdCQUF3QixDQUFDO0FBQ2xFLFlBQU0sUUFBUSxPQUFPLElBQUksUUFBUSxJQUFJLG9CQUFvQixDQUFDLElBQUk7QUFDOUQsWUFBTSxVQUFVLFFBQVEsS0FBSyxJQUFJLElBQUksUUFBUSxNQUFPLEtBQUssSUFBSSxJQUFJO0FBQ2pFLFVBQUksSUFBSSxXQUFXLEtBQUs7QUFDdEIsYUFBSyxXQUFXO0FBQ2hCLGVBQU8sRUFBRSxJQUFJLE9BQU8sT0FBTyxlQUFlO0FBQUEsTUFDNUM7QUFFQSxVQUFJLE9BQU8sU0FBUyxTQUFTLEtBQUssSUFBSSxRQUFRLElBQUksd0JBQXdCLEtBQUssYUFBYSxFQUFHLE1BQUssV0FBVztBQUMvRyxVQUFJLElBQUksV0FBVyxPQUFPLElBQUksV0FBVyxJQUFLLFFBQU8sRUFBRSxJQUFJLE9BQU8sT0FBTyxjQUFjO0FBQ3ZGLFVBQUksQ0FBQyxJQUFJLEdBQUksUUFBTyxFQUFFLElBQUksT0FBTyxPQUFPLFFBQVEsSUFBSSxNQUFNLEdBQUc7QUFDN0QsVUFBSTtBQUNGLGVBQU8sRUFBRSxJQUFJLE1BQU0sTUFBTSxXQUFXLE1BQU0sSUFBSSxLQUFLLENBQUMsRUFBRTtBQUFBLE1BQ3hELFFBQVE7QUFDTixlQUFPLEVBQUUsSUFBSSxPQUFPLE9BQU8sV0FBVztBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7OztBQ2pJQSxNQUFNLFFBQVEsQ0FBQyxNQUF5QixPQUFPLE1BQU0sWUFBWSxNQUFNO0FBR3ZFLFdBQVMsWUFBWSxHQUE2QjtBQUNoRCxRQUFJLENBQUMsTUFBTSxDQUFDLEVBQUcsUUFBTztBQUN0QixRQUFJLEVBQUUsZUFBZSxRQUFTLFFBQU87QUFDckMsUUFBSSxFQUFFLGVBQWUsZ0NBQWdDLE1BQU0sRUFBRSxLQUFLLEVBQUcsUUFBTyxZQUFZLEVBQUUsS0FBSztBQUMvRixXQUFPO0FBQUEsRUFDVDtBQUVBLFdBQVMsV0FBVyxPQUFnQztBQUNsRCxVQUFNLE9BQU8sTUFBTSxNQUFNLGNBQWM7QUFDdkMsVUFBTSxPQUFPLE1BQU0sTUFBTSxlQUFlLE1BQU0sUUFBUTtBQUN0RCxXQUFPLE9BQU8sU0FBUyxXQUFXLE9BQU87QUFBQSxFQUMzQztBQUVBLFdBQVMsVUFBVSxPQUFvQjtBQUNyQyxVQUFNLE9BQU8sTUFBTSxZQUFZLG9CQUFvQixRQUFRO0FBQzNELFFBQUksT0FBTyxTQUFTLFlBQVksS0FBTSxRQUFPO0FBQzdDLFVBQU0sT0FBTyxNQUFNLFFBQVE7QUFDM0IsV0FBTyxPQUFPLFNBQVMsV0FBVyxPQUFPO0FBQUEsRUFDM0M7QUFHTyxNQUFNLGFBQWE7QUFDbkIsTUFBTSxhQUFhO0FBR25CLFdBQVMsZ0JBQWdCLEtBQWlDO0FBQy9ELFVBQU0sSUFBSSxzREFBc0QsS0FBSyxHQUFHO0FBQ3hFLFdBQU8sSUFBSSwrQkFBK0IsRUFBRSxDQUFDLENBQUMsb0JBQW9CLFVBQVUsS0FBSztBQUFBLEVBQ25GO0FBRUEsV0FBUyxVQUFVLE9BQXNCO0FBQ3ZDLFVBQU0sUUFBUSxNQUFNLFFBQVEsbUJBQW1CLFNBQVMsTUFBTSxRQUFRLFVBQVU7QUFDaEYsUUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLEVBQUcsUUFBTyxDQUFDO0FBQ25DLFdBQU8sTUFDSixPQUFPLENBQUMsTUFBVyxHQUFHLFNBQVMsV0FBVyxPQUFPLEVBQUUsb0JBQW9CLFFBQVEsRUFDL0UsSUFBSSxDQUFDLE1BQVcsZ0JBQWdCLEVBQUUsZUFBZSxDQUFDLEVBQ2xELE9BQU8sQ0FBQyxNQUF1QyxDQUFDLENBQUMsQ0FBQztBQUFBLEVBQ3ZEO0FBRU8sV0FBUyxZQUFZLE9BQThCO0FBQ3hELFVBQU0sS0FBSyxNQUFNO0FBQ2pCLFFBQUksT0FBTyxPQUFPLFlBQVksQ0FBQyxHQUFJLFFBQU87QUFDMUMsVUFBTSxPQUFhO0FBQUEsTUFDakI7QUFBQSxNQUNBLE1BQU0sVUFBVSxLQUFLO0FBQUEsTUFDckIsUUFBUSxXQUFXLEtBQUs7QUFBQSxNQUN4QixTQUFTLE9BQU8sTUFBTSxRQUFRLDhCQUE4QjtBQUFBLE1BQzVELFFBQVE7QUFBQSxJQUNWO0FBQ0EsVUFBTSxTQUFTLFVBQVUsS0FBSztBQUM5QixVQUFNLFNBQVMsWUFBWSxNQUFNLHNCQUFzQixNQUFNO0FBQzdELFFBQUksUUFBUTtBQUNWLFdBQUssYUFBYSxVQUFVLE1BQU07QUFDbEMsV0FBSyxlQUFlLFdBQVcsTUFBTTtBQUVyQyxVQUFJLE9BQU8sT0FBTyxZQUFZLFlBQVksT0FBTyxRQUFTLE1BQUssV0FBVyxPQUFPO0FBQUEsVUFDNUUsUUFBTyxLQUFLLEdBQUcsVUFBVSxNQUFNLENBQUM7QUFBQSxJQUN2QztBQUNBLFFBQUksT0FBTyxPQUFRLE1BQUssWUFBWSxDQUFDLEdBQUcsSUFBSSxJQUFJLE1BQU0sQ0FBQyxFQUFFLE1BQU0sR0FBRyxVQUFVO0FBQzVFLFdBQU87QUFBQSxFQUNUO0FBR0EsV0FBUyxXQUFXLEdBQXFCLEdBQWU7QUFDdEQsUUFBSSxDQUFDLEVBQUcsUUFBTztBQUNmLFVBQU0sTUFBWSxFQUFFLEdBQUcsRUFBRTtBQUN6QixlQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssT0FBTyxRQUFRLENBQUMsR0FBMEI7QUFDN0QsVUFBSSxJQUFJLENBQUMsTUFBTSxVQUFhLElBQUksQ0FBQyxNQUFNLE1BQU0sSUFBSSxDQUFDLE1BQU0sTUFBTyxDQUFDLElBQVksQ0FBQyxJQUFJO0FBQUEsSUFDbkY7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUdPLE1BQU0sd0JBQU4sTUFBc0Q7QUFBQSxJQUMzRCxNQUFNLE1BQXVCO0FBQzNCLFlBQU0sTUFBTSxvQkFBSSxJQUFrQjtBQUNsQyxZQUFNLFFBQW1CLENBQUMsSUFBSTtBQUM5QixZQUFNLE9BQU8sb0JBQUksSUFBYTtBQUM5QixhQUFPLE1BQU0sUUFBUTtBQUNuQixjQUFNLE9BQU8sTUFBTSxJQUFJO0FBQ3ZCLFlBQUksQ0FBQyxNQUFNLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxFQUFHO0FBQ3BDLGFBQUssSUFBSSxJQUFJO0FBQ2IsY0FBTSxRQUFRLFlBQVksSUFBSTtBQUM5QixZQUFJLFNBQVMsVUFBVSxNQUFNO0FBQzNCLGNBQUk7QUFDRixrQkFBTSxPQUFPLFlBQVksS0FBSztBQUM5QixnQkFBSSxLQUFNLEtBQUksSUFBSSxLQUFLLElBQUksV0FBVyxJQUFJLElBQUksS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDO0FBQUEsVUFDL0QsUUFBUTtBQUFBLFVBRVI7QUFBQSxRQUNGO0FBQ0EsbUJBQVcsS0FBSyxNQUFNLFFBQVEsSUFBSSxJQUFJLE9BQU8sT0FBTyxPQUFPLElBQUksR0FBRztBQUNoRSxjQUFJLE1BQU0sQ0FBQyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBQUEsUUFDNUI7QUFBQSxNQUNGO0FBQ0EsYUFBTyxDQUFDLEdBQUcsSUFBSSxPQUFPLENBQUM7QUFBQSxJQUN6QjtBQUFBLEVBQ0Y7QUFFTyxNQUFNLGVBQWUsQ0FBQyxnQkFBZ0Isc0JBQXNCLGVBQWUsY0FBYyxnQkFBZ0I7QUFFekcsV0FBUyxjQUFjLEtBQXNCO0FBQ2xELFVBQU0sSUFBSSxnQ0FBZ0MsS0FBSyxHQUFHO0FBQ2xELFdBQU8sQ0FBQyxDQUFDLEtBQUssYUFBYSxTQUFTLEVBQUUsQ0FBQyxDQUFDO0FBQUEsRUFDMUM7OztBQ1FPLE1BQU0sU0FBUzs7O0FDdEh0QixNQUFNLFNBQVMsSUFBSSxzQkFBc0I7QUFDekMsTUFBSSxVQUFVO0FBSWQsTUFBTSxVQUFVO0FBQ2hCLE1BQUksVUFBVSxRQUFRLE9BQU8sS0FBSztBQUNsQyxNQUFJLFNBQVM7QUFFYixXQUFTLFFBQVEsR0FBK0I7QUFDOUMsUUFBSTtBQUNGLGFBQU8sYUFBYSxRQUFRLENBQUMsS0FBSztBQUFBLElBQ3BDLFFBQVE7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFHQSxXQUFTLGVBQWUsS0FBYSxNQUFzQjtBQUN6RCxRQUFJLFFBQVEsV0FBVyxLQUFLLElBQUksRUFBRyxVQUFTO0FBQzVDLFVBQU0sS0FBSyxhQUFhLEdBQUc7QUFDM0IsUUFBSSxNQUFNLE9BQU8sU0FBUztBQUN4QixnQkFBVTtBQUNWLFVBQUk7QUFDRixxQkFBYSxRQUFRLFNBQVMsRUFBRTtBQUFBLE1BQ2xDLFFBQVE7QUFBQSxNQUVSO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxNQUFNLFVBQVUsSUFBSSxlQUFlO0FBQUEsSUFDakMsT0FBTyxJQUFJLE1BQU0sVUFBVSxHQUFHLENBQUM7QUFBQSxJQUMvQixTQUFTLE1BQU07QUFBQSxJQUNmLFNBQVMsT0FBTztBQUFBLE1BQ2QsZUFBZTtBQUFBLE1BQ2YsZ0JBQWdCLHNCQUFzQixLQUFLLFNBQVMsTUFBTSxJQUFJLENBQUMsS0FBSztBQUFBLE1BQ3BFLHVCQUF1QjtBQUFBLE1BQ3ZCLHlCQUF5QjtBQUFBLElBQzNCO0FBQUEsRUFDRixDQUFDO0FBRUQsU0FBTyxpQkFBaUIsV0FBVyxDQUFDLE1BQU07QUFDeEMsUUFBSSxFQUFFLFdBQVcsVUFBVSxFQUFFLE1BQU0sT0FBTyxPQUFRO0FBQ2xELFFBQUksRUFBRSxLQUFLLFNBQVMsU0FBVSxXQUFVLENBQUMsQ0FBQyxFQUFFLEtBQUs7QUFBQSxhQUN4QyxFQUFFLEtBQUssU0FBUyxtQkFBbUIsT0FBTyxFQUFFLEtBQUssV0FBVyxVQUFVO0FBQzdFLFlBQU1DLFVBQWlCLEVBQUUsS0FBSztBQUM5QixjQUFRLE9BQU9BLE9BQU0sRUFBRSxLQUFLLENBQUMsV0FBVyxPQUFPLFlBQVksRUFBRSxJQUFJLFFBQVEsTUFBTSxpQkFBaUIsUUFBQUEsU0FBUSxPQUFPLEdBQUcsU0FBUyxNQUFNLENBQUM7QUFBQSxJQUNwSTtBQUFBLEVBQ0YsQ0FBQztBQUVELFdBQVMsT0FBTyxLQUFhLE1BQWU7QUFDMUMsUUFBSTtBQUNGLFlBQU0sUUFBUSxPQUFPLE1BQU0sSUFBSTtBQUMvQixVQUFJLE1BQU0sT0FBUSxRQUFPLFlBQVksRUFBRSxJQUFJLFFBQVEsTUFBTSxTQUFTLE1BQU0sR0FBRyxTQUFTLE1BQU07QUFDMUYsVUFBSSxRQUFTLFFBQU8sWUFBWSxFQUFFLElBQUksUUFBUSxNQUFNLFdBQVcsS0FBSyxNQUFNLEtBQUssR0FBRyxTQUFTLE1BQU07QUFBQSxJQUNuRyxRQUFRO0FBQUEsSUFFUjtBQUFBLEVBQ0Y7QUFFQSxNQUFNLFlBQVksT0FBTztBQUN6QixTQUFPLFFBQVEsa0JBQWtDLE1BQWdDO0FBQy9FLFVBQU0sTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLElBQUk7QUFDNUMsUUFBSTtBQUNGLFlBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsWUFBTSxNQUFNLE9BQU8sVUFBVSxXQUFXLFFBQVEsaUJBQWlCLE1BQU0sTUFBTSxPQUFPLE1BQU07QUFDMUYsWUFBTSxJQUFJLEtBQUssQ0FBQyxHQUFHLFlBQVksaUJBQWlCLFVBQVUsTUFBTSxVQUFVO0FBQzFFLHFCQUFlLEtBQUssYUFBYSxVQUFVLEVBQUUsSUFBSSxlQUFlLElBQUksTUFBTSxRQUFRLENBQUMsSUFBSSxTQUFhLEdBQVcsYUFBYTtBQUM1SCxVQUFJLGNBQWMsR0FBRyxHQUFHO0FBQ3RCLFlBQ0csTUFBTSxFQUNOLEtBQUssRUFDTCxLQUFLLENBQUMsTUFBTSxPQUFPLEtBQUssQ0FBQyxHQUFHLE1BQU07QUFBQSxRQUFDLENBQUM7QUFBQSxNQUN6QztBQUFBLElBQ0YsUUFBUTtBQUFBLElBRVI7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLE1BQU0sV0FBVyxlQUFlLFVBQVU7QUFDMUMsaUJBQWUsVUFBVSxPQUFPLFNBQWdDLFFBQWdCLFFBQXNCLE1BQWE7QUFDakgsVUFBTSxPQUFPLE9BQU8sR0FBRztBQUN2QixtQkFBZSxJQUFJO0FBQ25CLFFBQUksY0FBYyxJQUFJLEdBQUc7QUFDdkIsV0FBSyxpQkFBaUIsUUFBUSxNQUFNO0FBQ2xDLFlBQUk7QUFDRixnQkFBTSxPQUNKLEtBQUssaUJBQWlCLFNBQVMsS0FBSyxXQUFXLEtBQUssaUJBQWlCLE1BQU0sS0FBSyxpQkFBaUIsU0FBUyxLQUFLLE1BQU0sS0FBSyxZQUFZLElBQUk7QUFDNUksY0FBSSxLQUFNLFFBQU8sTUFBTSxJQUFJO0FBQUEsUUFDN0IsUUFBUTtBQUFBLFFBRVI7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQ0EsV0FBUSxTQUFpQixLQUFLLE1BQU0sUUFBUSxLQUFLLEdBQUcsSUFBSTtBQUFBLEVBQzFEO0FBRUEsTUFBTSxnQkFBZ0IsZUFBZSxVQUFVO0FBQy9DLGlCQUFlLFVBQVUsbUJBQW1CLFNBQWdDLE1BQWMsT0FBZTtBQUN2RyxRQUFJLEtBQUssWUFBWSxNQUFNLGdCQUFpQixnQkFBZSxJQUFJLEtBQUs7QUFDcEUsV0FBTyxjQUFjLEtBQUssTUFBTSxNQUFNLEtBQUs7QUFBQSxFQUM3QzsiLAogICJuYW1lcyI6IFsiaGFuZGxlIiwgImhhbmRsZSJdCn0K
